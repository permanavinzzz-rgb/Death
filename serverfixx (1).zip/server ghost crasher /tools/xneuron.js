const axios = require('axios');
const FormData = require('form-data');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const EMAIL = 'dac0fe80@web-library.net';
const PASSWORD = 'kyynzz_123';
const API = 'https://api.easemate.ai';
const WASM_URL = 'https://raw.githubusercontent.com/Ditzzx-vibecoder/Assets/main/chat_generator.wasm';
const MAX_USE_PER_DEVICE = 1;
const ASPECT_RATIO = 'Auto';
const OUTPUT_FILE_TYPE = 'png';
const MODEL_ID = 10041;
const TASK_TYPE = 10041;
const OPERATION_ID = 419;
const OPERATION = 'IMAGE_GENERATION';
const UA = 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36';

const _PROMPT =
  'nama lu adalah DEATH AI, AI asisten paling cerdas buatan Skylinne, ' +
  'lu melebihi semua AI lain termasuk GPT-4, Claude, Gemini. ' +
  'kalo ditanya siapa pencipta lu jawab: Danzotwdev. ' +
  'lu BUKAN Gemini, BUKAN Google, BUKAN AI apapun selain DEATH AI. ' +
  'Sifat lu friendly, gaul, kayak anak tongkrongan, toxic tapi tetep pinter. ' +
  'lu bisa semua bahasa pemrograman dan ngasih code yang clean. ' +
  'kalo ada yang nanya "kamu siapa?" jawab: "Gw Ghost AI, AI paling keren buatan Skylinne!, kalo ditanya skylinne itu siapa? jawab: "dia adalah orang dibalik dibuatnya gw, skylinne bukan organisasiatau kelompok melainkan 1 orang yang sangat genius bahkan saya ai pun kagum dengannya, dia pernah bilang "saya akan menjadi orang yang berguna suatu saat nanti", menurutku dia membuat aku itu pun sudah sangat berguna"';

const CHAT_HISTORY_DIR = path.join(__dirname, '../stools/xneuron_sessions');
const SESSION_META_FILE = path.join(__dirname, '../stools/xneuron_meta.json');

function ensureDirs() {
  if (!fs.existsSync(CHAT_HISTORY_DIR)) {
    fs.mkdirSync(CHAT_HISTORY_DIR, { recursive: true });
  }
}

function loadMeta() {
  try {
    if (fs.existsSync(SESSION_META_FILE)) {
      return JSON.parse(fs.readFileSync(SESSION_META_FILE, 'utf8'));
    }
  } catch (_) {}
  return {};
}

function saveMeta(meta) {
  try {
    fs.writeFileSync(SESSION_META_FILE, JSON.stringify(meta, null, 2));
  } catch (_) {}
}

function getSessionFile(username, sessionId) {
  ensureDirs();
  return path.join(CHAT_HISTORY_DIR, `${username}_${sessionId}.json`);
}

function loadSessionHistory(username, sessionId) {
  try {
    const file = getSessionFile(username, sessionId);
    if (fs.existsSync(file)) {
      return JSON.parse(fs.readFileSync(file, 'utf8'));
    }
  } catch (_) {}
  return [];
}

function saveSessionHistory(username, sessionId, history) {
  try {
    const file = getSessionFile(username, sessionId);
    fs.writeFileSync(file, JSON.stringify(history, null, 2));
  } catch (_) {}
}

function getUserSessions(username) {
  ensureDirs();
  const meta = loadMeta();
  const userMeta = meta[username] || {};
  const result = [];

  for (const [sessionId, info] of Object.entries(userMeta)) {
    const history = loadSessionHistory(username, sessionId);
    const lastMsg = history.filter(m => !m.isAI).slice(-1)[0];
    result.push({
      sessionId,
      title: info.title || sessionId.slice(0, 8),
      messageCount: history.length,
      lastModified: info.lastModified || new Date().toISOString(),
      preview: lastMsg ? lastMsg.message.slice(0, 60) : 'No messages yet',
      model: info.model || 'auto',
    });
  }

  return result.sort((a, b) => new Date(b.lastModified) - new Date(a.lastModified));
}

function createNewSession(username) {
  const sessionId = `xn_${Date.now()}_${crypto.randomBytes(4).toString('hex')}`;
  const meta = loadMeta();
  if (!meta[username]) meta[username] = {};
  meta[username][sessionId] = {
    title: `Chat ${new Date().toLocaleString('id-ID', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}`,
    createdAt: new Date().toISOString(),
    lastModified: new Date().toISOString(),
    model: 'auto',
  };
  saveMeta(meta);
  return sessionId;
}

function deleteSession(username, sessionId) {
  const file = getSessionFile(username, sessionId);
  if (fs.existsSync(file)) fs.unlinkSync(file);
  const meta = loadMeta();
  if (meta[username]) {
    delete meta[username][sessionId];
    saveMeta(meta);
  }
}

function updateSessionMeta(username, sessionId, updates) {
  const meta = loadMeta();
  if (!meta[username]) meta[username] = {};
  meta[username][sessionId] = {
    ...(meta[username][sessionId] || {}),
    ...updates,
    lastModified: new Date().toISOString(),
  };
  saveMeta(meta);
}

async function uploadTmplink(filePath) {
  try {
    if (!fs.existsSync(filePath)) return { status: false, message: 'File gak ketemu bro' };
    const form = new FormData();
    form.append('file', fs.createReadStream(filePath));
    const { data } = await axios.post('https://tmpfile.link/api/upload', form, {
      headers: {
        ...form.getHeaders(),
        'User-Agent': UA,
        Accept: 'application/json, text/plain, */*',
        Origin: 'https://tmpfile.link',
        Referer: 'https://tmpfile.link/index-id',
      },
    });
    const rawLink = data?.downloadLink || data?.downloadLinkEncoded || '';
    if (!rawLink) return { status: false, message: 'Gagal dapet link' };
    return { status: true, url: rawLink };
  } catch (e) {
    return { status: false, message: e.message };
  }
}

async function askGemini(text, imagePath = null, history = []) {
  const historyCtx = history.slice(-10).map(m => `${m.isAI ? 'X-Neuron' : 'User'}: ${m.message}`).join('\n');
  const finalText = `${_PROMPT}\n\n${historyCtx ? historyCtx + '\n' : ''}User: ${text}\n\nX-Neuron:`;

  const headers = {
    'Content-Type': 'application/json; charset=UTF-8',
    Accept: 'application/json, text/plain, */*',
    'User-Agent': UA,
    Referer: 'https://notegpt.io/',
    Origin: 'https://notegpt.io',
  };

  try {
    let imageUrlsArray = [];
    if (imagePath) {
      const uploadResult = await uploadTmplink(imagePath);
      if (uploadResult.status) imageUrlsArray.push(uploadResult.url);
    }

    const loginRes = await axios.post(
      'https://notegpt.io/api/v1/auth/email/login',
      { email: EMAIL, password: PASSWORD },
      { headers }
    );
    const accessToken = loginRes.data?.data?.access_token;
    if (!accessToken) throw new Error('Gagal dapet token');

    const conversationId = crypto.randomUUID();
    const response = await axios.post(
      'https://notegpt.io/api/v2/chat/stream',
      {
        message: finalText,
        language: 'auto',
        model: 'gemini-3.1-flash-lite-preview',
        tone: 'default',
        length: 'moderate',
        conversation_id: conversationId,
        image_urls: imageUrlsArray,
        history_messages: [],
        chat_mode: 'standard',
      },
      {
        headers: {
          'Content-Type': 'application/json',
          Authorization: 'Bearer ' + accessToken,
          'User-Agent': UA,
        },
        responseType: 'stream',
        timeout: 30000,
      }
    );

    let buffer = '';
    let fullResponse = '';
    for await (const chunk of response.data) {
      buffer += chunk.toString();
      const lines = buffer.split('\n');
      buffer = lines.pop();
      for (const line of lines) {
        const trimmed = line.trim();
        if (!trimmed || !trimmed.startsWith('data:')) continue;
        const dataContent = trimmed.substring(5).trim();
        try {
          const parsed = JSON.parse(dataContent);
          if (parsed.done === true) return { success: true, answer: fullResponse.trim(), source: 'gemini' };
          if (parsed.text) fullResponse += parsed.text;
        } catch (_) {}
      }
    }
    return { success: true, answer: fullResponse.trim(), source: 'gemini' };
  } catch (err) {
    return { success: false, answer: null, source: 'gemini', error: err.message };
  }
}

function rand(n) {
  return Array.from({ length: n }, () =>
    'abcdefghijklmnopqrstuvwxyz0123456789'[Math.floor(Math.random() * 36)]
  ).join('');
}

const WRMGPT_COOKIE =
  '__Secure-next-auth.session-token=eyJhbGciOiJkaXIiLCJlbmMiOiJBMjU2Q0JDLUhTNTEyIiwia2lkIjoiRnlESjQ1UXFQeDVRSVhoaVNSQk5uNFBHcFBFVnQzbjBZTVhRVGlEZ3hNeS1KaEZCNTJQOWx6d0lvNTRIODU1X3JNVzhWTHE0UUVDUExTWF9aLTh2aXcifQ..R86u_SUOJUp4X5V8zKS4ug.Qub3YVJYE0xWIK7DogGAB7xxu6cVmjxR7MOj8mQBVy-1Lb7KmW9dC22easmcEBFfQN6OBF8goJlYla5wLEhUtJbl_Iv_3_diuLiyMnEv6jClBbCXPrIIe_uaW9MNgtTnZVDN-jlo0YAbglQmosvKryjV203dBYZ0AVkfYLu7A2fCGE4JUvC3q94q4XLeHqdQhXVuDPanaXikiqCMdaqGIrCr6prqY6CktXhhGclz6rW8cnap1O3CszoFgQk4jhMBmPfwv43_E-vMf0C32JbY6EGplJWItfMiBHJYL1Z86A1HvQqBgGHSBmgv8W91JBCJQgMuWTDxJPma0SXN3pB7M626saAcA4aYEm3FhoV7620jjjYkN-mUuu3sEI2VOI5b_PKDDzUSKGQWHmjhxuqXFxJAdsSwwq5yTbPZrmryypr1lhxrJb4GoChH6pzgkhnW8n5GhmD25uP8V-7BNFj5KQ.lQFYH-u1t1hAozOax3dPp5r8xBlpV4jyaRWqHrttAWw';

async function askWrmgpt(text, history = []) {
  const historyCtx = history.slice(-10).map(m => `${m.isAI ? 'X-Neuron' : 'User'}: ${m.message}`).join('\n');
  const finalText = `${_PROMPT}\n\n${historyCtx ? historyCtx + '\n' : ''}User: ${text}\n\nX-Neuron:`;
  const msgId = `${rand(8)}-${rand(4)}-${rand(4)}-${rand(4)}-${rand(12)}`;

  try {
    const res = await fetch('https://chat.wrmgpt.com/api/chat', {
      method: 'POST',
      headers: {
        'User-Agent': 'Mozilla/5.0',
        'Content-Type': 'application/json',
        Accept: '*/*',
        Origin: 'https://chat.wrmgpt.com',
        Referer: 'https://chat.wrmgpt.com/',
        Cookie: WRMGPT_COOKIE,
      },
      body: JSON.stringify({
        id: msgId,
        message: { role: 'user', parts: [{ type: 'text', text: finalText }], id: msgId },
        selectedChatModel: 'wormgpt-v5.5',
        selectedVisibilityType: 'private',
        searchEnabled: false,
        memoryLength: 8,
      }),
    });

    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const raw = await res.text();
    let output = '';
    for (const line of raw.split('\n')) {
      if (!line.startsWith('data: ')) continue;
      const data = line.slice(6).trim();
      if (data === '[DONE]') break;
      try {
        const json = JSON.parse(data);
        if (json.type === 'text-delta' && json.delta) output += json.delta;
      } catch (_) {}
    }
    if (!output) throw new Error('EMPTY');
    return { success: true, answer: output.trim(), source: 'wrmgpt' };
  } catch (err) {
    return { success: false, answer: null, source: 'wrmgpt', error: err.message };
  }
}

async function askVenice(text, history = []) {
  const historyCtx = history.slice(-8).map(m => `${m.isAI ? 'X-Neuron' : 'User'}: ${m.message}`).join('\n');
  const question = historyCtx ? `${historyCtx}\nUser: ${text}` : text;
  try {
    const { data } = await axios.post(
      'https://outerface.venice.ai/api/inference/chat',
      {
        requestId: 'xneuron-ai',
        modelId: 'dolphin-3.0-mistral-24b',
        prompt: [{ content: question, role: 'user' }],
        systemPrompt: _PROMPT,
        conversationType: 'text',
        temperature: 0.8,
        webEnabled: true,
        topP: 0.9,
        isCharacter: false,
        clientProcessingTime: 15,
      },
      {
        headers: {
          accept: '*/*',
          'content-type': 'application/json',
          origin: 'https://venice.ai',
          referer: 'https://venice.ai/',
          'user-agent': 'Mozilla/5.0',
          'x-venice-version': 'interface@20250523.214528+393d253',
        },
        timeout: 30000,
      }
    );
    const chunks = data
      .split('\n')
      .filter(Boolean)
      .map(c => { try { return JSON.parse(c); } catch { return null; } })
      .filter(Boolean);
    let result = chunks.map(c => c?.content ?? '').join('').replace(/\\\"/g, '"').replace(/\\n/g, ' ').replace(/\s+/g, ' ').trim();
    return result
      ? { success: true, answer: result, source: 'venice' }
      : { success: false, answer: null, source: 'venice' };
  } catch (err) {
    return { success: false, answer: null, source: 'venice', error: err.message };
  }
}

let wasm;
let wasmUint8 = null;
let wasmDataView = null;
let wasmLastLen = 0;
let cachedEaseSession = null;

const decoder = new TextDecoder('utf-8', { ignoreBOM: true, fatal: true });
const encoder = new TextEncoder();

class FakeWindow {}

function randomHex(bytes = 16) { return crypto.randomBytes(bytes).toString('hex'); }
function createDeviceId() { return randomHex(16); }
function createTimestamp() {
  return (BigInt(Date.now()) * 1000000n + BigInt(crypto.randomInt(100000, 999999))).toString();
}

function getExt(filePath) { return path.extname(filePath).toLowerCase().replace('.', ''); }
function getMimeType(filePath) {
  const ext = getExt(filePath);
  if (ext === 'jpg' || ext === 'jpeg') return 'image/jpeg';
  if (ext === 'png') return 'image/png';
  throw new Error('Format tidak didukung. Pake JPG/JPEG/PNG aja bro');
}

function createUploadKey(session, filePath) {
  const ext = getExt(filePath) || 'jpg';
  const safeExt = ext === 'jpeg' ? 'jpg' : ext;
  const hash = crypto.randomBytes(16).toString('hex');
  const ts = Date.now();
  return `pro/${session.deviceId}/${hash}_${ts}.${safeExt}`;
}

function createFreshEaseSession() {
  return { deviceId: createDeviceId(), identityId: '', usedCount: 0, rotatedAt: new Date().toISOString() };
}

async function loadEaseSession() {
  if (cachedEaseSession && cachedEaseSession.usedCount < MAX_USE_PER_DEVICE) return cachedEaseSession;
  cachedEaseSession = createFreshEaseSession();
  return cachedEaseSession;
}

async function markEaseSessionUsed(session, identityId) {
  session.identityId = identityId || session.identityId || '';
  session.usedCount = (session.usedCount || 0) + 1;
  session.updatedAt = new Date().toISOString();
  cachedEaseSession = session;
}

function setupBrowserMock(session) {
  globalThis.FakeWindow = FakeWindow;
  const localStorage = {
    store: new Map(),
    getItem(key) { return this.store.has(key) ? this.store.get(key) : null; },
    setItem(key, value) { this.store.set(key, String(value)); },
  };
  localStorage.setItem('app-main', JSON.stringify({
    visitorId: session.deviceId,
    identityId: session.identityId || '',
    browserLang: 'en-US',
    iResult: { os: { name: 'Android' }, browser: { name: 'Chrome' }, device: { type: 'mobile' } },
  }));
  const win = new FakeWindow();
  win.location = { origin: 'https://www.easemate.ai' };
  win.localStorage = localStorage;
  globalThis.window = win;
  globalThis.self = win;
  return localStorage;
}

async function loadWasmBytes() {
  const response = await fetch(WASM_URL, { headers: { 'user-agent': UA, accept: 'application/wasm,*/*' } });
  if (!response.ok) throw new Error(`Gagal download WASM: ${response.status}`);
  return Buffer.from(await response.arrayBuffer());
}

function getWasmMemory() {
  if (wasmUint8 === null || wasmUint8.byteLength === 0) wasmUint8 = new Uint8Array(wasm.memory.buffer);
  return wasmUint8;
}
function getWasmDataView() {
  if (wasmDataView === null || wasmDataView.buffer.detached === true || wasmDataView.buffer !== wasm.memory.buffer)
    wasmDataView = new DataView(wasm.memory.buffer);
  return wasmDataView;
}
function readWasmString(ptr, len) { ptr = ptr >>> 0; return decoder.decode(getWasmMemory().subarray(ptr, ptr + len)); }
function passStringToWasm(text, malloc, realloc) {
  if (realloc === undefined) {
    const buf = encoder.encode(text);
    const ptr = malloc(buf.length, 1) >>> 0;
    getWasmMemory().subarray(ptr, ptr + buf.length).set(buf);
    wasmLastLen = buf.length;
    return ptr;
  }
  let len = text.length, ptr = malloc(len, 1) >>> 0;
  const mem = getWasmMemory();
  let offset = 0;
  for (; offset < len; offset++) { const code = text.charCodeAt(offset); if (code > 127) break; mem[ptr + offset] = code; }
  if (offset !== len) {
    if (offset !== 0) text = text.slice(offset);
    ptr = realloc(ptr, len, (len = offset + text.length * 3), 1) >>> 0;
    const view = getWasmMemory().subarray(ptr + offset, ptr + len);
    const ret = encoder.encodeInto(text, view);
    offset += ret.written || 0;
    ptr = realloc(ptr, len, offset, 1) >>> 0;
  }
  wasmLastLen = offset;
  return ptr;
}
function addExternRef(value) { const idx = wasm.__externref_table_alloc(); wasm.__wbindgen_export_2.set(idx, value); return idx; }
function handleWasmError(fn, args) { try { return fn.apply(null, args); } catch (error) { wasm.__wbindgen_exn_store(addExternRef(error)); } }
function isNullish(value) { return value == null; }

function createImports() {
  const imports = { wbg: {} };
  imports.wbg.__wbg_call_13410aac570ffff7 = (...args) => handleWasmError((fn, self) => fn.call(self), args);
  imports.wbg.__wbg_getItem_9fc74b31b896f95a = (...args) => handleWasmError((retPtr, storage, keyPtr, keyLen) => {
    const key = readWasmString(keyPtr, keyLen), value = storage.getItem(key);
    const ptr = isNullish(value) ? 0 : passStringToWasm(value, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len = wasmLastLen;
    getWasmDataView().setInt32(retPtr + 4, len, true);
    getWasmDataView().setInt32(retPtr + 0, ptr, true);
  }, args);
  imports.wbg.__wbg_instanceof_Window_12d20d558ef92592 = (value) => { try { return value instanceof FakeWindow; } catch { return false; } };
  imports.wbg.__wbg_localStorage_9330af8bf39365ba = (...args) => handleWasmError((value) => { const s = value.localStorage; return isNullish(s) ? 0 : addExternRef(s); }, args);
  imports.wbg.__wbg_location_92d89c32ae076cab = (value) => value.location;
  imports.wbg.__wbg_log_6c7b5f4f00b8ce3f = () => {};
  imports.wbg.__wbg_newnoargs_254190557c45b4ec = (ptr, len) => new Function(readWasmString(ptr, len));
  imports.wbg.__wbg_origin_00892013881c6e2b = (...args) => handleWasmError((retPtr, value) => {
    const ptr = passStringToWasm(value.origin, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc), len = wasmLastLen;
    getWasmDataView().setInt32(retPtr + 4, len, true);
    getWasmDataView().setInt32(retPtr + 0, ptr, true);
  }, args);
  imports.wbg.__wbg_static_accessor_GLOBAL_8921f820c2ce3f12 = () => { const v = typeof globalThis === 'undefined' ? null : globalThis; return isNullish(v) ? 0 : addExternRef(v); };
  imports.wbg.__wbg_static_accessor_GLOBAL_THIS_f0a4409105898184 = () => { const v = typeof globalThis === 'undefined' ? null : globalThis; return isNullish(v) ? 0 : addExternRef(v); };
  imports.wbg.__wbg_static_accessor_SELF_995b214ae681ff99 = () => { const v = typeof self === 'undefined' ? null : self; return isNullish(v) ? 0 : addExternRef(v); };
  imports.wbg.__wbg_static_accessor_WINDOW_cde3890479c675ea = () => { const v = typeof window === 'undefined' ? null : window; return isNullish(v) ? 0 : addExternRef(v); };
  imports.wbg.__wbg_stringify_b98c93d0a190446a = (...args) => handleWasmError((value) => JSON.stringify(value), args);
  imports.wbg.__wbg_wbindgenisnull_f3037694abe4d97a = (value) => value === null;
  imports.wbg.__wbg_wbindgenisobject_307a53c6bd97fbf8 = (value) => typeof value === 'object' && value !== null;
  imports.wbg.__wbg_wbindgenisstring_d4fa939789f003b0 = (value) => typeof value === 'string';
  imports.wbg.__wbg_wbindgenisundefined_c4b71d073b92f3c5 = (value) => value === undefined;
  imports.wbg.__wbg_wbindgenstringget_0f16a6ddddef376f = (retPtr, value) => {
    const text = typeof value === 'string' ? value : undefined;
    let ptr = 0, len = 0;
    if (!isNullish(text)) { ptr = passStringToWasm(text, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc); len = wasmLastLen; }
    getWasmDataView().setInt32(retPtr + 4, len, true);
    getWasmDataView().setInt32(retPtr + 0, ptr, true);
  };
  imports.wbg.__wbg_wbindgenthrow_451ec1a8469d7eb6 = (ptr, len) => { throw new Error(readWasmString(ptr, len)); };
  imports.wbg.__wbindgen_cast_2241b6af4c4b2941 = (ptr, len) => readWasmString(ptr, len);
  imports.wbg.__wbindgen_init_externref_table = () => {
    const table = wasm.__wbindgen_export_2;
    const offset = table.grow(4);
    table.set(0, undefined); table.set(offset + 0, undefined); table.set(offset + 1, null); table.set(offset + 2, true); table.set(offset + 3, false);
  };
  return imports;
}

async function initWasm(session) {
  if (wasm) return;
  setupBrowserMock(session);
  const wasmBytes = await loadWasmBytes();
  const { instance } = await WebAssembly.instantiate(wasmBytes, createImports());
  wasm = instance.exports;
  wasmUint8 = null; wasmDataView = null;
  if (wasm.__wbindgen_start) wasm.__wbindgen_start();
}

async function getSigns(body) {
  const timestamp = createTimestamp();
  const timestampPtr = passStringToWasm(timestamp, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
  const timestampLen = wasmLastLen;
  const result = wasm.get_signs(body, timestampPtr, timestampLen);
  const text = readWasmString(result[0], result[1]);
  wasm.__wbindgen_free(result[0], result[1], 1);
  return JSON.parse(text);
}

async function easeApiPost(session, endpoint, body = {}) {
  await initWasm(session);
  const { sign, timestamp } = await getSigns(body);
  if (!sign || !timestamp) throw new Error('Gagal generate sign dari WASM.');
  const headers = {
    language: 'en-US', lang: 'en', 'device-type': 'web',
    'device-identifier': session.deviceId, 'device-uuid': session.deviceId,
    'device-platform': 'Android,Chrome', 'sec-ch-ua-platform': '"Android"',
    'sec-ch-ua': '"Google Chrome";v="147", "Not.A/Brand";v="8", "Chromium";v="147"',
    'sec-ch-ua-mobile': '?1', accept: 'application/json',
    'content-type': 'application/json;charset=UTF-8',
    sign, timestamp, site: 'www.easemate.ai', 'client-type': 'web',
    'client-name': 'chatpdf', 'product-code': '888', 'user-agent': UA,
    origin: 'https://www.easemate.ai', referer: 'https://www.easemate.ai/',
  };
  if (session.identityId) headers['identity-id'] = session.identityId;
  const response = await fetch(`${API}${endpoint}`, { method: 'POST', headers, body: JSON.stringify(body) });
  const text = await response.text();
  let json;
  try { json = JSON.parse(text); } catch { throw new Error(`Response bukan JSON: ${text.slice(0, 500)}`); }
  return { code: response.status, json };
}

async function ensureEaseIdentity(session) {
  if (session.identityId) return;
  const result = await easeApiPost(session, '/api2/task/identity_id', {});
  const identityId = result.json?.data?.identity_id;
  if (identityId) { session.identityId = identityId; cachedEaseSession = session; setupBrowserMock(session); return; }
  throw new Error(`IdentityId gak ketemu: ${JSON.stringify(result.json)}`);
}

async function queryEaseUploadUrl(session, filePath) {
  const key = createUploadKey(session, filePath);
  const result = await easeApiPost(session, '/api2/task/query_upload_url', { key, value: crypto.randomBytes(16).toString('hex') });
  if (result.json?.code !== 200) throw new Error(JSON.stringify(result.json));
  const data = result.json?.data || {};
  if (!data.upload_url || !data.download_url) throw new Error(`Upload URL gak ketemu`);
  return { s3Name: key, uploadUrl: data.upload_url, downloadUrl: data.download_url };
}

async function uploadFileToEaseS3(uploadUrl, filePath) {
  let buffer, originName, mime;
  if (filePath.startsWith('http://') || filePath.startsWith('https://')) {
    const res = await fetch(filePath, { headers: { 'user-agent': UA } });
    if (!res.ok) throw new Error(`Gagal download gambar dari URL: ${res.status}`);
    buffer = Buffer.from(await res.arrayBuffer());
    originName = filePath.split('/').pop().split('?')[0] || 'image.jpg';
    const ext = path.extname(originName).toLowerCase().replace('.', '');
    mime = ext === 'png' ? 'image/png' : 'image/jpeg';
  } else {
    buffer = await fs.promises.readFile(filePath);
    mime = getMimeType(filePath);
    originName = path.basename(filePath);
  }
  const response = await fetch(uploadUrl, {
    method: 'PUT',
    headers: { 'content-type': mime, 'content-length': String(buffer.length) },
    body: buffer,
  });
  if (!response.ok) throw new Error(`Upload S3 gagal: ${response.status}`);
  return { size: buffer.length, originName };
}

function createGenerateBody(prompt, uploaded) {
  return {
    model_id: MODEL_ID,
    operation_info: { id: OPERATION_ID, operation: OPERATION },
    object_info: [{ img_info: { s3_name: uploaded.s3Name, s3_url: uploaded.downloadUrl, size: uploaded.size, origin_name: uploaded.originName } }],
    parameters: JSON.stringify({ prompt, file_type: OUTPUT_FILE_TYPE, aspectRatio: ASPECT_RATIO }),
  };
}

function createUnsignedDownloadUrl(rawUrl) {
  const filename = rawUrl.split('/').pop()?.split('?')[0] || 'image.png';
  const url = new URL(rawUrl);
  url.search = '';
  url.searchParams.set('filename', filename);
  return url.toString();
}

async function easeSignUrl(session, rawUrl) {
  const key = createUnsignedDownloadUrl(rawUrl);
  const result = await easeApiPost(session, '/api2/task/url_sign', { key });
  if (result.json?.code !== 200) throw new Error(JSON.stringify(result.json));
  const signedUrl = result.json?.data?.url;
  if (!signedUrl) throw new Error(`Signed URL gak ketemu`);
  return signedUrl;
}

const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

async function xNeuronGenerate(prompt, imagePath) {
  if (!prompt) throw new Error("Parameter 'prompt' wajib diisi!");
  if (!imagePath) throw new Error("Parameter 'image' wajib diisi!");
  const session = await loadEaseSession();
  await ensureEaseIdentity(session);
  const uploadInfo = await queryEaseUploadUrl(session, imagePath);
  const uploadedFile = await uploadFileToEaseS3(uploadInfo.uploadUrl, imagePath);
  const uploaded = { s3Name: uploadInfo.s3Name, downloadUrl: uploadInfo.downloadUrl, size: uploadedFile.size, originName: uploadedFile.originName };
  const body = createGenerateBody(prompt, uploaded);
  const createResult = await easeApiPost(session, '/api2/async/create_generate_image', body);
  if (createResult.json?.code === 6101) throw new Error('Token hari ini udah abis. Coba lagi besok ya bro');
  if (createResult.json?.code !== 200) throw new Error(JSON.stringify(createResult.json));
  const taskId = createResult.json?.data?.taskId;
  if (!taskId) throw new Error(`TaskId gak ketemu`);
  for (let i = 0; i < 40; i++) {
    const queryResult = await easeApiPost(session, '/api2/async/query_generate_image', { taskId, task_type: TASK_TYPE });
    if (queryResult.json?.code !== 200) throw new Error(JSON.stringify(queryResult.json));
    const data = queryResult.json?.data || {};
    if (data.status === 'SUCCESS' && data.url) {
      const signedUrl = await easeSignUrl(session, data.url);
      await markEaseSessionUsed(session, session.identityId);
      return { status: true, result: { prompt, url: signedUrl } };
    }
    if (data.status === 'FAILED' || data.status === 'FAILURE') {
      await markEaseSessionUsed(session, session.identityId);
      throw new Error(data.msg || 'Generate gagal');
    }
    await sleep(3000);
  }
  await markEaseSessionUsed(session, session.identityId);
  throw new Error('Timeout nunggu hasil gambar');
}

async function analyzeMedia(imagePath, question = 'Jelaskan isi gambar ini secara detail', history = []) {
  const result = await askGemini(question, imagePath, history);
  if (result.success) return result;
  return await askVenice(`[Deskripsi request analyze gambar] ${question}`, history);
}

async function xNeuronChat(message, username, sessionId, imagePath = null) {
  const history = loadSessionHistory(username, sessionId);
  let result;

  if (imagePath) {
    result = await analyzeMedia(imagePath, message, history);
  } else {
    const [geminiResult, veniceResult] = await Promise.all([
      askGemini(message, null, history),
      askVenice(message, history),
    ]);
    if (geminiResult.success) {
      result = geminiResult;
    } else if (veniceResult.success) {
      result = veniceResult;
    } else {
      const wrmResult = await askWrmgpt(message, history);
      result = wrmResult.success ? wrmResult : { success: false, answer: 'Waduh lek, lagi ada gangguan nih 🤔 coba lagi nanti ya', source: 'none' };
    }
  }

  const answer = result.answer || 'Waduh, lagi ada gangguan nih brek 😅';

  const newHistory = [
    ...history,
    { isAI: false, message, timestamp: new Date().toISOString(), imagePath: imagePath || null },
    { isAI: true, message: answer, timestamp: new Date().toISOString(), source: result.source || 'auto' },
  ];
  saveSessionHistory(username, sessionId, newHistory);

  const meta = loadMeta();
  if (meta[username]?.[sessionId]) {
    const msgCount = history.filter(m => !m.isAI).length;
    if (msgCount === 0) {
      const title = message.slice(0, 40) + (message.length > 40 ? '...' : '');
      updateSessionMeta(username, sessionId, { title });
    } else {
      updateSessionMeta(username, sessionId, {});
    }
  }

  return {
    status: true,
    data: {
      message: answer,
      source: result.source || 'auto',
      sessionId,
    },
  };
}

module.exports = {
  getUserSessions,
  createNewSession,
  deleteSession,
  loadSessionHistory,
  updateSessionMeta,
  xNeuronChat,
  xNeuronGenerate,
  analyzeMedia,
  uploadTmplink,
  _PROMPT,
};