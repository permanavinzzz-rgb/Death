module.exports = {
    OWNER_ID: [8725811713],
    TOKEN: "8660332414:AAGl12FVjVNLJlDfUHAnAVvWmZ1d9KfRb88",
    PORT: process.env.SERVER_PORT || process.env.PORT,
    
    globalBugs: [
    { bug_id: "crash", bug_name: "CRASH INVISIBLE" },
    { bug_id: "invis", bug_name: "FORCE CLOSE INVISIBLE V1" },
    { bug_id: "uy", bug_name: "FORCE CLOSE INVISIBLE V2" },
    { bug_id: "pp", bug_name: "FORCE CLOSE INVISIBLE V3" },
    { bug_id: "fc_ios", bug_name: "FORCE CLOSE IOS ( HANYA UNTUK IPHONE )" }, 
    { bug_id: "iphone", bug_name: "FORCE CLOSE IOS V2 ( HANYA UNTUK IPHONE )" },
  ], 
    
    bugs: [    
    { bug_id: "fcc", bug_name: "FORCE CLOSE INFINITY" },
    { bug_id: "invis", bug_name: "FORCE CLOSE INVISIBLE V1" },
    { bug_id: "uy", bug_name: "FORCE CLOSE INVISIBLE V2" },
    { bug_id: "pp", bug_name: "FORCE CLOSE INVISIBLE V3" },
    { bug_id: "hm", bug_name: "FORCE CLOSE INVISIBLE V4" },
    { bug_id: "fccc", bug_name: "FORCE CLOSE INVISIBLE V5" },
    { bug_id: "fc_ios", bug_name: "FORCE CLOSE IOS ( HANYA UNTUK IPHONE )" },
    { bug_id: "iphone", bug_name: "FORCE CLOSE IOS V2 ( HANYA UNTUK IPHONE )" },
    { bug_id: "fc_click", bug_name: "FORCE CLOSE CLICK" },
    { bug_id: "delayfrezee", bug_name: "FORCE CLOSE X FREZEE" },
    { bug_id: "crash", bug_name: "CRASH INVISIBLE" },
    { bug_id: "blank", bug_name: "BLANK CLICK" },
    { bug_id: "delay", bug_name: "DELAY X CRASH" },
    { bug_id: "waktu", bug_name: "DELAY WAKTU" },
    { bug_id: "frame", bug_name: "FREZEE CHAT" },
    { bug_id: "chat", bug_name: "FREZEE X BLANK" },
    { bug_id: "spam", bug_name: "SPAM CERAMAH" },
    { bug_id: "hard", bug_name: "DELAY HARD INVISIBLE" },
    { bug_id: "fc", bug_name: "CRASH HOME" },
    { bug_id: "ohoh", bug_name: "CRASH X BLANK" },
    { bug_id: "dozer", bug_name: "BLANK X DELAY BULDOZER  (RAWAN KENON)" },
    { bug_id: "stuck", bug_name: "DELAY HARD ANDROID" },
  ],
    
    groupBugs: [
    { bug_id: "fc_gb", bug_name: "FORCE CLOSE CLICK GROUP" },
    { bug_id: "blanks", bug_name: "SUPER HARD BLANK & FREEZE GROUP" },
    { bug_id: "stucklog", bug_name: "BLANK STUCK LOGO X CRASH X FREEZE CLICK HARD GROUP" },
    { bug_id: "delayz", bug_name: "X-DELAY INVISIBLE IN GROUP" },
    { bug_id: "ban", bug_name: "BANZ GROUP FOMO" },
  ],
    
    tqto: [
        {
            name: "Danzotwdev.",
            status: "Developer / Creators Apps", 
            ppUrl: "https://uploader.zenzxz.dpdns.org/uploads/1782529635488.jpeg",
            contac: "t.me/Danzotwdev"
        }
    ],
    
    news: [
    {
        image: "https://files.catbox.moe/dvoca3.png",
        title: "DEATH LUFFY",
        desc: "Selamat Datang Di death Luffy"
    },
    {
        image: "https://files.catbox.moe/k3kyj4.jpg",
        title: "BY Danzotwdev",
        desc: "Dikembangkan Oleh Danzotwdev"
    }
    ],
    
    listDDoS: [
        { ddos_id: "s-gbps", ddos_name: "SYN High GBPS" },
        { ddos_id: "s-pps", ddos_name: "SYN Traffic Flood" },
        { ddos_id: "a-gbps", ddos_name: "ACK High GBPS" },
        { ddos_id: "a-pps", ddos_name: "ACK Traffic Flood" },
        { ddos_id: "icmp", ddos_name: "ICMP Flood" },
        { ddos_id: "udp", ddos_name: "GUDP ( HIGH RISK )" }
    ]
};